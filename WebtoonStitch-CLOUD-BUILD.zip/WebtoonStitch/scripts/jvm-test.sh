#!/usr/bin/env bash
# Compiles and tests the :engine module WITHOUT Gradle/Maven (for offline sandboxes).
# Uses the Kotlin compiler and JUnit jars that ship inside the Gradle distribution.
# On a normal machine just run:  ./gradlew :engine:test
#
# Exit status contract (never 0 unless real tests really ran and all passed):
#   0  compiled, >=1 test executed, 0 failures
#   1  compilation failed, or a test failed, or JUnit itself failed
#   2  nothing to run (no test sources, filter matched nothing, 0 tests executed) or setup problem
#
# Environment: TESTS=<substring filter on class names>  JVM_OPTS=<jvm flags, e.g. -Xmx128m>
#              GRADLE_LIB=<dir with kotlin/junit jars>  OUT=<build dir>
set -uo pipefail   # deliberately NOT -e: every status below is checked explicitly

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
GL="${GRADLE_LIB:-/opt/gradle-8.14.3/lib}"
OUT="${OUT:-/tmp/engine-build}"
KOTLIN_VER=2.0.21

die() { local code="$1"; shift; echo "FAILED: $*" >&2; exit "$code"; }
filtered() { grep -v '^Picked up' "$1" || true; }   # display only; never used for status decisions

for j in kotlin-compiler-embeddable kotlin-stdlib kotlin-script-runtime kotlin-reflect kotlin-daemon-embeddable; do
  [ -f "$GL/$j-$KOTLIN_VER.jar" ] || die 2 "missing $GL/$j-$KOTLIN_VER.jar (set GRADLE_LIB)"
done
HAMCREST="$(ls "$GL"/hamcrest-core-*.jar 2>/dev/null | head -1)"
[ -f "$GL/junit-4.13.2.jar" ] && [ -n "$HAMCREST" ] || die 2 "junit/hamcrest jars not found in $GL"

KCP="$GL/kotlin-compiler-embeddable-$KOTLIN_VER.jar:$GL/kotlin-stdlib-$KOTLIN_VER.jar:$GL/kotlin-script-runtime-$KOTLIN_VER.jar:$GL/kotlin-reflect-$KOTLIN_VER.jar:$GL/kotlin-daemon-embeddable-$KOTLIN_VER.jar:$GL/trove4j-1.0.20200330.jar:$GL/annotations-24.0.1.jar:$GL/kotlinx-coroutines-core-jvm-1.6.4.jar"
STD="$GL/kotlin-stdlib-$KOTLIN_VER.jar"
JUNIT="$GL/junit-4.13.2.jar:$HAMCREST"

MAIN_SRC=(); while IFS= read -r f; do MAIN_SRC+=("$f"); done < <(find "$ROOT/engine/src/main" -name '*.kt' | sort)
TEST_SRC=(); while IFS= read -r f; do TEST_SRC+=("$f"); done < <(find "$ROOT/engine/src/test" -name '*.kt' | sort)
[ "${#MAIN_SRC[@]}" -gt 0 ] || die 2 "no main sources under engine/src/main"
[ "${#TEST_SRC[@]}" -gt 0 ] || die 2 "no test sources under engine/src/test - refusing to report success with zero tests"

rm -rf "$OUT"; mkdir -p "$OUT/main" "$OUT/test" || die 2 "cannot create $OUT"

# compile <label> <outdir> <extra kotlinc args...> -- <sources...>
compile() {
  local label="$1" outdir="$2"; shift 2
  local log="$OUT/$label.log"
  echo "== compile $label (${#@} args) =="
  java -cp "$KCP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -jvm-target 17 -d "$outdir" "$@" >"$log" 2>&1
  local rc=$?
  filtered "$log"
  [ "$rc" -eq 0 ] || die 1 "$label compilation failed (compiler exit status $rc)"
  # belt and braces: a compiler that exited 0 but reported errors, or produced nothing, is still a failure
  ! grep -q ': error:' "$log" || die 1 "$label compilation reported errors"
  [ -n "$(find "$outdir" -name '*.class' -print -quit)" ] || die 1 "$label compilation produced no class files"
}

compile main "$OUT/main" -cp "$STD" "${MAIN_SRC[@]}"
compile test "$OUT/test" -Xfriend-paths="$OUT/main" -cp "$STD:$JUNIT:$OUT/main" "${TEST_SRC[@]}"

CLASSES=()
while IFS= read -r c; do
  if [ -z "${TESTS:-}" ] || [[ "$c" == *"$TESTS"* ]]; then CLASSES+=("$c"); fi
done < <(cd "$OUT/test" && find . -name '*Test.class' | sed 's#^\./##; s#\.class$##; s#/#.#g' | sort)
[ "${#CLASSES[@]}" -gt 0 ] || die 2 "no test classes matched TESTS='${TESTS:-}'"

echo "== run tests: ${CLASSES[*]} =="
RUNLOG="$OUT/junit.log"
# shellcheck disable=SC2086
java ${JVM_OPTS:-} -cp "$STD:$JUNIT:$OUT/main:$OUT/test" org.junit.runner.JUnitCore "${CLASSES[@]}" >"$RUNLOG" 2>&1
RC=$?
filtered "$RUNLOG"
[ "$RC" -eq 0 ] || die 1 "JUnit exit status $RC (test failure or JUnit error)"
! grep -q 'FAILURES!!!' "$RUNLOG" || die 1 "JUnit reported failures"
N="$(sed -n 's/^OK (\([0-9][0-9]*\) tests\{0,1\})$/\1/p' "$RUNLOG" | tail -1)"
[ -n "$N" ] || die 1 "could not find the 'OK (n tests)' line in the JUnit output"
[ "$N" -gt 0 ] || die 2 "0 tests were executed"
echo "SUMMARY: compiled OK, $N tests executed, 0 failures"
exit 0
