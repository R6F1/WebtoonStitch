#!/usr/bin/env bash
# Inspects a built APK. UNTESTED against a real APK (none could be built where this was written).
# Usage: scripts/verify-apk.sh app/build/outputs/apk/debug/app-debug.apk
# Needs the Android SDK build-tools (aapt2, apksigner) via ANDROID_HOME / ANDROID_SDK_ROOT, and unzip.
set -uo pipefail
APK="${1:-}"; [ -f "$APK" ] || { echo "usage: $0 <apk>  (file not found: '$APK')" >&2; exit 2; }
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"; [ -d "$SDK/build-tools" ] || { echo "set ANDROID_HOME to your SDK" >&2; exit 2; }
BT="$(ls -d "$SDK"/build-tools/*/ | sort -V | tail -1)"
AAPT2="$BT/aapt2"; APKSIGNER="$BT/apksigner"
echo "APK:  $(readlink -f "$APK")"; echo "Size: $(stat -c %s "$APK" 2>/dev/null || stat -f %z "$APK") bytes"
BADGING="$("$AAPT2" dump badging "$APK")" || { echo "FAILED: aapt2 could not read the APK" >&2; exit 1; }
echo "$BADGING" | grep -E "^(package:|sdkVersion|minSdkVersion|targetSdkVersion|native-code|application-label:)" 
PKG="$(echo "$BADGING" | sed -n "s/^package: name='\([^']*\)'.*/\1/p")"
PERMS="$(echo "$BADGING" | grep -c '^uses-permission' || true)"
ABIS="$(unzip -Z1 "$APK" | grep '^lib/' | cut -d/ -f2 | sort -u | tr '\n' ' ')"
echo "Native-library ABIs inside APK: ${ABIS:-<none: pure Kotlin/Java, runs on any ABI>}"
echo "Declared permissions: $PERMS"
echo "--- signature ---"; "$APKSIGNER" verify --print-certs "$APK" | head -3 || { echo "FAILED: signature check" >&2; exit 1; }
rc=0
[ "$PKG" = "com.webtoonstitch.app" ] || { echo "FAIL: package id is '$PKG'" >&2; rc=1; }
[ "$PERMS" = "0" ] || { echo "FAIL: APK declares $PERMS permission(s); expected 0 (no INTERNET, no storage)" >&2; rc=1; }
for a in $ABIS; do [ "$a" = "arm64-v8a" ] || { echo "FAIL: unexpected ABI '$a'" >&2; rc=1; }; done
[ "$rc" = 0 ] && echo "VERIFY OK: package=$PKG, ABIs=[${ABIS:-none}], 0 permissions, signed"
exit $rc
