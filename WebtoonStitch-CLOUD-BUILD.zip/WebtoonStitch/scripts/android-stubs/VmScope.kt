package androidx.lifecycle
import kotlinx.coroutines.*
val ViewModel.viewModelScope: CoroutineScope get() = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
