package androidx.lifecycle; import android.app.Application; public class AndroidViewModel extends ViewModel { public AndroidViewModel(Application a){} }
