package android.os; import java.io.*;
public class ParcelFileDescriptor implements Closeable { public FileDescriptor getFileDescriptor(){return null;} public void close() throws IOException {}
 public static class AutoCloseInputStream extends FileInputStream { public AutoCloseInputStream(ParcelFileDescriptor pfd){ super(pfd.getFileDescriptor()); } } }
