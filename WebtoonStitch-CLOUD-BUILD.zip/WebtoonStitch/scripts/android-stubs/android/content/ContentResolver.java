package android.content; import android.net.Uri; import android.database.Cursor; import android.os.ParcelFileDescriptor; import java.io.*;
public abstract class ContentResolver { public abstract Cursor query(Uri u, String[] p, String s, String[] a, String o);
 public abstract InputStream openInputStream(Uri u) throws FileNotFoundException; public abstract OutputStream openOutputStream(Uri u, String mode) throws FileNotFoundException;
 public abstract ParcelFileDescriptor openFileDescriptor(Uri u, String mode) throws FileNotFoundException; public abstract void takePersistableUriPermission(Uri u, int flags); }
