package android.provider; import android.net.Uri; import android.content.ContentResolver; import java.io.FileNotFoundException;
public final class DocumentsContract { public static final class Document { public static final String COLUMN_DOCUMENT_ID="document_id", COLUMN_DISPLAY_NAME="_display_name", COLUMN_MIME_TYPE="mime_type", COLUMN_SIZE="_size", MIME_TYPE_DIR="vnd.android.document/directory"; }
 public static Uri buildDocumentUriUsingTree(Uri t, String id){return null;} public static Uri buildChildDocumentsUriUsingTree(Uri t, String id){return null;}
 public static String getTreeDocumentId(Uri t){return null;} public static Uri createDocument(ContentResolver r, Uri parent, String mime, String name) throws FileNotFoundException {return null;}
 public static Uri renameDocument(ContentResolver r, Uri d, String name) throws FileNotFoundException {return null;}
 public static boolean deleteDocument(ContentResolver r, Uri d) throws FileNotFoundException {return false;} }
