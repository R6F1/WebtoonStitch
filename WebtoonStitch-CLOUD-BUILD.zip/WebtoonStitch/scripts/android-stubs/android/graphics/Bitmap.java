package android.graphics; public class Bitmap { public enum Config { ARGB_8888 } public static Bitmap createBitmap(int[] c,int w,int h,Config cfg){return null;} public int getByteCount(){return 0;} }
