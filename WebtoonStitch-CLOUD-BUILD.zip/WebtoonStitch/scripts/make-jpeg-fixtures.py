#!/usr/bin/env python3
"""Generates the JPEG test fixtures in engine/src/test/resources/jpeg and the golden checksums.

The files are produced by Pillow's libjpeg(-turbo) ENCODER and the checksums by Pillow's libjpeg(-turbo) DECODER, i.e. by
software that is independent of the engine's decoder. The engine tests additionally compare against the JDK's ImageIO.
Run:  python3 scripts/make-jpeg-fixtures.py   (needs Pillow + numpy; only needed to REGENERATE, the outputs are committed)
"""
import hashlib, io, os, struct, zlib
import numpy as np
from PIL import Image, ImageCms

OUT = os.path.join(os.path.dirname(__file__), "..", "engine", "src", "test", "resources")
J = os.path.join(OUT, "jpeg")
os.makedirs(J, exist_ok=True)

def pattern(w, h, seed, mode="RGB"):
    rs = np.random.RandomState(seed)
    y, x = np.mgrid[0:h, 0:w]
    base = np.stack([(x * 255 // max(w - 1, 1)), (y * 255 // max(h - 1, 1)), ((x + y) * 255 // max(w + h - 2, 1))], -1).astype(float)
    edges = ((x // 5 + y // 7) % 2)[..., None] * 90.0           # hard edges stress chroma upsampling + high-frequency DCT terms
    noise = rs.randint(-25, 26, (h, w, 3))
    a = np.clip(base * 0.6 + edges + noise, 0, 255).astype(np.uint8)
    im = Image.fromarray(a, "RGB")
    return im.convert("L") if mode == "L" else im

gold = []
def emit(name, im, **kw):
    b = io.BytesIO(); im.save(b, "JPEG", **kw); data = b.getvalue()
    open(os.path.join(J, name), "wb").write(data)
    d = Image.open(io.BytesIO(data)); d.load()
    gold.append((name, d.mode, d.width, d.height, hashlib.sha256(d.tobytes()).hexdigest()))
    return data

for (w, h) in [(1, 1), (2, 2), (3, 5), (15, 17), (16, 16), (17, 33), (64, 48), (101, 67)]:
    im = pattern(w, h, w * 1000 + h)
    emit(f"s420_{w}x{h}.jpg", im, quality=90, subsampling=2)
    emit(f"s422_{w}x{h}.jpg", im, quality=90, subsampling=1)
    emit(f"s444_{w}x{h}.jpg", im, quality=90, subsampling=0)
    emit(f"gray_{w}x{h}.jpg", im.convert("L"), quality=90)
im = pattern(130, 90, 7)
emit("q100_420.jpg", im, quality=100, subsampling=2)
emit("q5_420.jpg", im, quality=5, subsampling=2)
emit("optimized_420.jpg", im, quality=85, subsampling=2, optimize=True)
emit("restart_420.jpg", im, quality=85, subsampling=2, restart_marker_blocks=3)
emit("restart_444.jpg", im, quality=85, subsampling=0, restart_marker_rows=1)

# --- files that must be REJECTED (not decoded) -------------------------------------------------------------------
open(os.path.join(J, "reject_progressive.jpg"), "wb").write(
    (lambda b: (im.save(b, "JPEG", quality=85, progressive=True), b.getvalue())[1])(io.BytesIO()))
open(os.path.join(J, "reject_cmyk.jpg"), "wb").write(
    (lambda b: (im.convert("CMYK").save(b, "JPEG", quality=85), b.getvalue())[1])(io.BytesIO()))
exif = Image.Exif(); exif[0x0112] = 6
open(os.path.join(J, "reject_exif_orientation6.jpg"), "wb").write(
    (lambda b: (im.save(b, "JPEG", quality=85, exif=exif), b.getvalue())[1])(io.BytesIO()))
# a file whose EXIF says "normal" must still be accepted:
exif1 = Image.Exif(); exif1[0x0112] = 1
emit("exif_orientation1_420.jpg", im, quality=85, subsampling=2, exif=exif1)

# --- embedded ICC profile (Pillow's built-in sRGB profile) -----------------------------------------------------
prof = ImageCms.ImageCmsProfile(ImageCms.createProfile("sRGB")).tobytes()
open(os.path.join(J, "profile.icc"), "wb").write(prof)
emit("icc_srgb_420.jpg", im, quality=85, subsampling=2, icc_profile=prof)

with open(os.path.join(J, "golden.txt"), "w") as f:
    f.write("# name  PIL-mode  width  height  sha256(raw samples decoded by Pillow/libjpeg-turbo)\n")
    for g in gold: f.write(" ".join(map(str, g)) + "\n")
print(len(gold), "fixtures written to", J)

# --- golden checksums of the two user-provided sample files (engine/src/test/resources/samples) -------------------
S = os.path.join(OUT, "samples")
if os.path.exists(os.path.join(S, "doesnt_load.png")):
    with open(os.path.join(S, "golden.txt"), "w") as f:
        f.write("# name  PIL-mode  width  height  sha256(raw samples decoded by Pillow)\n")
        for n in ("itloads.png", "doesnt_load.png"):
            d = Image.open(os.path.join(S, n)); d.load(); d = d.convert("RGB")
            f.write(f"{n} RGB {d.width} {d.height} {hashlib.sha256(d.tobytes()).hexdigest()}\n")
    print(open(os.path.join(S, "golden.txt")).read())

# --- privacy fixtures: sources that are FULL of identifying metadata (engine/src/test/resources/privacy) -----------------
# Every identifying string contains a unique "TOKEN-..." so the tests can prove it does not appear anywhere in an output PNG.
import struct
P = os.path.join(OUT, "privacy"); os.makedirs(P, exist_ok=True)
T = dict(author="TOKEN-AUTHOR-4471", copyright="TOKEN-COPYRIGHT-8812", software="TOKEN-SOFTWARE-2290", make="TOKEN-MAKE-5530",
         model="TOKEN-MODEL-1187", desc="TOKEN-DESC-6642", comment="TOKEN-COMMENT-9031", xmp="TOKEN-XMP-3318",
         iptc="TOKEN-IPTC-7724", gps="TOKEN-GPS-4409", date="2019:03:07 21:14:55", owner="TOKEN-OWNER-1523")
open(os.path.join(P, "tokens.txt"), "w").write("\n".join(v for k, v in T.items() if v.startswith("TOKEN")) + "\n")
pim = pattern(96, 70, 99)

def segment(marker, payload): return b"\xff" + bytes([marker]) + struct.pack(">H", len(payload) + 2) + payload

exif = Image.Exif()
exif[0x010F] = T["make"]; exif[0x0110] = T["model"]; exif[0x0131] = T["software"]; exif[0x0132] = T["date"]
exif[0x013B] = T["author"]; exif[0x8298] = T["copyright"]; exif[0x010E] = T["desc"]; exif[0x0112] = 1
ex = exif.get_ifd(0x8769); ex[0x9003] = T["date"]; ex[0xA430] = T["owner"]; ex[0xA431] = "TOKEN-SERIAL-6619"
gps = exif.get_ifd(0x8825); gps[1] = "N"; gps[2] = (23.0, 48.0, 15.0); gps[3] = "E"; gps[4] = (90.0, 24.0, 55.0); gps[29] = "2019:03:07"
prof = open(os.path.join(J, "profile.icc"), "rb").read()
b = io.BytesIO(); pim.save(b, "JPEG", quality=90, subsampling=2, exif=exif, comment=T["comment"].encode(), icc_profile=prof)
data = b.getvalue()
xmp = (b'<?xpacket begin="" id="W5M0MpCehiHzreSzNTczkc9d"?><x:xmpmeta xmlns:x="adobe:ns:meta/"><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">'
       b'<rdf:Description xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:creator>' + T["xmp"].encode() + b'</dc:creator></rdf:Description></rdf:RDF></x:xmpmeta><?xpacket end="w"?>')
iptc_ds = b"\x1c\x02\x78" + struct.pack(">H", len(T["iptc"])) + T["iptc"].encode()          # record 2, dataset 120 (caption)
bim = b"8BIM" + struct.pack(">H", 0x0404) + b"\x00\x00" + struct.pack(">I", len(iptc_ds)) + iptc_ds + (b"\x00" if len(iptc_ds) % 2 else b"")
extra = segment(0xE1, b"http://ns.adobe.com/xap/1.0/\x00" + xmp) + segment(0xED, b"Photoshop 3.0\x00" + bim) + segment(0xFE, b"also a comment " + T["comment"].encode())
assert data[2:4] == b"\xff\xe0"; l = struct.unpack(">H", data[4:6])[0]
data = data[:4 + l] + extra + data[4 + l:]
open(os.path.join(P, "meta.jpg"), "wb").write(data)
d = Image.open(io.BytesIO(data)); d.load()
gold2 = [("meta.jpg", d.mode, d.width, d.height, hashlib.sha256(d.convert("RGB").tobytes()).hexdigest())]

ti = {315: T["author"], 33432: T["copyright"], 305: T["software"], 306: T["date"], 270: T["desc"], 271: T["make"], 272: T["model"],
      700: xmp, 33723: iptc_ds, 285: "TOKEN-PAGENAME-3301", 269: "TOKEN-DOCNAME-9987", 316: "TOKEN-HOST-2214"}
pim.save(os.path.join(P, "meta.tif"), "TIFF", compression=None, tiffinfo=ti, icc_profile=prof)
d = Image.open(os.path.join(P, "meta.tif")); d.load()
gold2.append(("meta.tif", d.mode, d.width, d.height, hashlib.sha256(d.convert("RGB").tobytes()).hexdigest()))
with open(os.path.join(P, "golden.txt"), "w") as f:
    f.write("# name PIL-mode width height sha256(RGB samples decoded by Pillow)\n")
    for g in gold2: f.write(" ".join(map(str, g)) + "\n")
open(os.path.join(P, "tokens.txt"), "a").write("TOKEN-SERIAL-6619\nTOKEN-PAGENAME-3301\nTOKEN-DOCNAME-9987\nTOKEN-HOST-2214\n")
