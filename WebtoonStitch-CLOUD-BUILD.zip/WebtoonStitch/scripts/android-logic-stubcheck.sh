#!/usr/bin/env bash
# Static sanity check of the NON-UI Android code (SAF adapters, thumbnail cache, ViewModels) against hand-written stubs of the
# few Android/AndroidX APIs they use. This is NOT an Android build: it proves type/import/nullability consistency only.
# Compose UI files and resources are not covered. Needs the engine classes built by scripts/jvm-test.sh (OUT, default /tmp/engine-build).
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
GL="${GRADLE_LIB:-/opt/gradle-8.14.3/lib}"; OUT="${OUT:-/tmp/engine-build}"
STUBS="${STUBS:-$ROOT/scripts/android-stubs}"; WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
[ -d "$OUT/main/com/webtoonstitch/engine" ] || { echo "FAILED: engine classes not found in $OUT/main (run scripts/jvm-test.sh first)" >&2; exit 2; }
mkdir -p "$WORK/stubs"
javac -d "$WORK/stubs" $(find "$STUBS" -name '*.java') >"$WORK/javac.log" 2>&1 || { grep -v '^Picked up' "$WORK/javac.log"; echo "FAILED: stub compilation" >&2; exit 2; }
V=2.0.21
KCP="$GL/kotlin-compiler-embeddable-$V.jar:$GL/kotlin-stdlib-$V.jar:$GL/kotlin-script-runtime-$V.jar:$GL/kotlin-reflect-$V.jar:$GL/kotlin-daemon-embeddable-$V.jar:$GL/trove4j-1.0.20200330.jar:$GL/annotations-24.0.1.jar:$GL/kotlinx-coroutines-core-jvm-1.6.4.jar"
APP="$ROOT/app/src/main/kotlin/com/webtoonstitch/app"
java -cp "$KCP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -jvm-target 17 \
  -cp "$GL/kotlin-stdlib-$V.jar:$GL/kotlinx-coroutines-core-jvm-1.6.4.jar:$OUT/main:$WORK/stubs" -d "$WORK/out" \
  "$STUBS/VmScope.kt" "$APP/saf/Saf.kt" "$APP/ThumbnailCache.kt" "$APP/vm/StitchViewModel.kt" "$APP/vm/TiffViewModel.kt" "$APP/saf/SafRenameFolder.kt" "$APP/vm/RenameViewModel.kt" >"$WORK/kc.log" 2>&1
RC=$?
grep -v '^Picked up' "$WORK/kc.log" || true
[ "$RC" -eq 0 ] || { echo "FAILED: Kotlin compile of Android logic layer (exit $RC)" >&2; exit 1; }
! grep -q ': error:' "$WORK/kc.log" || { echo "FAILED: errors reported" >&2; exit 1; }
N=$(find "$WORK/out" -name '*.class' | wc -l); [ "$N" -gt 0 ] || { echo "FAILED: no classes produced" >&2; exit 1; }
echo "STUB CHECK OK: $N classes compiled (types/imports consistent against STUBS - not a real Android build)"
