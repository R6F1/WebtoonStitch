# Webtoon Stitch

Android app with exactly two tools, derived in spirit from [ImageToolbox](https://github.com/T8RIN/ImageToolbox) (Apache-2.0; see `NOTICE`, `LICENSE`):

1. **Image Stitching** - join same-width PNG/TIFF panels top-to-bottom into one gapless PNG (max 12,000 px combined height, natural filename order, output named `first-last.png`).
2. **TIFF to PNG** - convert single-page TIFF files to PNG, same name, pixel-identical.

Principle: *preserve the original image; never degrade silently.* Anything that cannot be preserved exactly is rejected with a reason.

## Status - what has and has not been checked

| Level | Status | What it covers |
|---|---|---|
| **Engine tests EXECUTED** | **done** (JDK 21, JVM) | 102 tests in `:engine` (73 earlier + 15 JPEG + 13 privacy + 1 large JPEG that self-skips under the default heap) and 4 large-input tests under a 128 MB heap, all passing. Details below. |
| **Android source STATICALLY REVIEWED** | **done, by reading + partial tooling** | Whole `:app` module and Gradle files read through; version compatibility checked against official docs; non-UI Android code compiled against *hand-written stubs*; a script checked Compose files for missing imports. This is **not** compilation. |
| **Android build / device** | **partly verified by the project owner, not by the build environment** | The owner built earlier versions through GitHub Actions and ran them on a phone (TIFF conversion worked; the JPEG-saved-as-.png case was found that way). This sandbox itself has never been able to run Gradle/AGP (its network policy blocks `dl.google.com`, `maven.google.com`, `repo.maven.apache.org`, `plugins.gradle.org`, `services.gradle.org`). The newest Compose UI code - scroll-direction auto-hide, compact bars, the fixed 3-column Stitch grid, the filename-only TIFF list, multi-page TIFF screens - has NOT been built or run yet; expect to fix small compile errors on the first build. |
| **DEVICE TESTING** | **PENDING** | Never run on a device or emulator: SAF providers, thumbnails, rotation, memory and speed on real hardware are all untested. |

No APK has been built.

**About "arm64-v8a only":** `abiFilters += "arm64-v8a"` removes native libraries of other ABIs (some AndroidX libraries ship `.so` files for several ABIs). The app's own code is pure Kotlin/Java and has no native code, so the APK is not otherwise ABI-restricted. `scripts/verify-apk.sh` lists the ABIs actually inside the finished APK and fails if any other than arm64-v8a is present.

**No local Android Studio?** `.github/workflows/build-apk.yml` builds the debug APK in GitHub Actions and attaches it as a downloadable artifact (untested).

## Layout
| Module | What | Android dependency |
|---|---|---|
| `:engine` | Streaming PNG reader/writer, TIFF decoder, stitcher, verification, natural sort, selection rules, job runners (atomic output) | **none** (pure Kotlin/JVM) |
| `:app` | Compose UI, in-app folder picker, Storage Access Framework adapters, ViewModels | yes |

Why a new engine instead of reusing ImageToolbox's: its stitcher and TIFF path go through Android `Bitmap` (8-bit, premultiplied alpha, whole image in RAM) plus resize/scale options. That cannot keep 16-bit data or exact alpha, and cannot stream.

## Atomic output (no partial file can look finished)
Every output (stitched PNG or converted TIFF) goes through the same steps (`Jobs.kt`):
1. create `<final name>.webtoonstitch.part` (a name that is never an image) in the output folder;
2. stream the PNG into it;
3. re-read the whole file and compare it sample-by-sample with the sources;
4. last cancel point, then re-check that the final name is still free (never overwrite; otherwise `name (1).png`);
5. **rename** to the final name. Only now does a finished file exist.

Failure, cancellation, full storage, corrupt read-back or out-of-memory delete the `.part` file. If the **process is killed**, at worst a `.part` file stays behind; it is deleted at the start of the next job (only names containing `.webtoonstitch.part`; other files are never touched). If the storage provider cannot rename, the job fails with a message and keeps nothing - it never falls back to writing the final name directly or to copy-and-delete.
The Android implementation (`SafOutputFolder`) uses `DocumentsContract.createDocument` (MIME `application/octet-stream`, so providers do not append `.png`) and `DocumentsContract.renameDocument`. The system `ExternalStorageProvider` supports rename; some cloud providers may not, and will then be refused with a clear message.

## TIFF Orientation 2-8: memory limitation
* Orientation 1 (normal, top-left) is **streamed** - memory is about one row regardless of image size.
* Orientations 2-8 (mirrored/rotated) cannot be done row by row, because the first output row depends on the *last* input rows. They are applied **exactly** (no resampling) by holding the complete raster in memory:
  `memory needed ≈ width × height × bytes-per-pixel` (e.g. 690×12000 RGB 8-bit ≈ 25 MB; 4096×12000 RGB 16-bit ≈ 281 MB).
* If that exceeds about 70 % of the app's maximum heap, the file is **rejected when it is opened** (so the picker refuses it at selection time, before any output exists) with a message that states the needed and available memory. There is deliberately **no downsampling or other lossy fallback**.
* Orientation 2-8 with samples below 8 bits is rejected (bit-level moves are not implemented).
* Workaround: re-save the TIFF with Orientation = top-left, or use a device with more memory.

## Build (on your machine)
Requires Android Studio (or JDK 17+ and the Android SDK platform 35).
```
./gradlew :engine:test                 # engine tests
./gradlew :engine:largeInputTest       # ~375 MB of pixels inside a 128 MB heap
./gradlew :app:assembleDebug           # -> app/build/outputs/apk/debug/app-debug.apk
./scripts/verify-apk.sh app/build/outputs/apk/debug/app-debug.apk   # package id, ABIs, permissions, signature (untested)
./gradlew :app:assembleRelease         # signed with the debug key; use your own signing config to distribute
```
### Toolchain (checked against official documentation)
| Component | Version | Evidence |
|---|---|---|
| Gradle (wrapper) | 8.11.1 | AGP 8.7 requires >= 8.9; Kotlin 2.1.20 is "fully compatible with Gradle 7.6.3 through 8.11" (kotlinlang.org *What's new in Kotlin 2.1.20*) |
| Android Gradle Plugin | 8.7.3 | needs Gradle >= 8.9, JDK >= 17, supports up to API 35 (developer.android.com *AGP 8.7.0 release notes*) |
| Kotlin + Compose compiler plugin | 2.1.20 | as above |
| JDK | 17 or newer (Android Studio's bundled JDK 21 is fine) | Gradle runs on Java 21 since 8.5 (docs.gradle.org *compatibility*) |
| compileSdk / targetSdk / minSdk | 35 / 35 / 24 | API 35 is AGP 8.7's maximum; minSdk 24 as in ImageToolbox |
| Compose BOM | 2025.04.00 | listed on the official BOM mapping page; the exact artifact versions it maps to could **not** be read from the fetched page |
| activity-compose 1.10.1, lifecycle-viewmodel-compose 2.8.7, coroutines 1.10.1 | pinned | chosen as an April-2025 era set; per-library minimum compileSdk/AGP was **not** individually verified. If Gradle's `checkAarMetadata` complains, either raise compileSdk (needs a newer AGP) or lower the offending library version |

Not verified: whether Kotlin 2.1.20 officially lists AGP 8.7.x (the page I could read gave no AGP range). If Android Studio proposes upgrading AGP/Gradle/Kotlin together, accepting that is fine; this project uses no deprecated plugin APIs that I know of.

Offline JVM-only runners (no Gradle): `scripts/jvm-test.sh` (engine tests; exits 0 only if >= 1 test ran and none failed; 1 = compile/test failure; 2 = nothing to run) and `scripts/android-logic-stubcheck.sh` (stub-based type check of the non-UI Android code).

## What the engine tests cover (executed)
Expected values come from the JDK's own ImageIO PNG/TIFF codecs or hand-computed pixels, not only from this code.
* **PNG**: every colour type x bit depth round-trips byte-exact; independent ImageIO decode agrees (8-bit RGBA, 16-bit gray, 16-bit RGB); corrupt/truncated/interlaced files are rejected.
* **TIFF**: 50 ImageIO-encoded files (gray8, gray16, rgb8, rgba8, rgb16 x None/LZW/Deflate/ZLib/PackBits x smooth/noise) and 56 hand-built combinations (big/little endian x compression x predictor x 8/16-bit x 1/3 channels), WhiteIsZero at 1/2/4/8/16-bit, palette, alpha, all 8 orientations, ICC byte-for-byte, unsupported-format rejections, truncated/corrupt input.
* **Stitching**: the 690 x (4000+3500+4500) = 690 x 12000 example, 16-bit gray/RGB/RGBA, natural order, width/height/format/colour-profile limits, cancellation, one-sample tamper detection, missing/duplicated rows.
* **Atomic output & stability**: final name never visible during write/verify; simulated process kill leaves only a `.part` file and the next run cleans it; cancel after verification but before publish; provider without rename; name taken while working; full storage; corrupted read-back; deleted source; per-file TIFF failures. No partial or unverified output is ever left under a final name.
* **Memory**: 375 MB of pixel data stitched and 281 MB single-strip TIFFs converted within a 128 MB heap (peak used < 15 MB); too-large oriented TIFF rejected cleanly at open.
* **Mutation checks**: deliberately broken LZW / byte-swap / temp-cleanup / re-check / cancel-point code is caught by the suite.
* **Test harness self-test**: `scripts/jvm-test.sh` was run against injected compile errors, failing tests, a crashing test class, empty test sets and a filter that matches nothing - all give a non-zero exit. (Note: JUnit counts assumption-skipped tests as executed; the 3 large-input tests skip themselves under the default heap.)

* **JPEG (new)** - tested with the two sample files from the bug report (`engine/src/test/resources/samples/`: `itloads.png` = real PNG, `doesnt_load.png` = JPEG data with a `.png` name) and 39 Pillow-generated fixtures (4:4:4 / 4:2:2 / 4:2:0 / gray, odd sizes from 1x1, restart intervals, quality 5-100, ICC, EXIF-orientation-1). Every decoded pixel of every file is compared with (1) the JDK's ImageIO decoder and (2) SHA-256 checksums of Pillow/libjpeg-turbo decodes: **all bit-identical**. The stitched PNG is read back with ImageIO and compared with the decoded JPEG, including row positions when several files are combined. Mutation checks (one-level rounding changes in the IDCT, the upsampler and the colour conversion) are caught. 2 x 1000x6000 JPEGs stitch within a 128 MB heap (about 5 MB above baseline) and match ImageIO row by row.

## Privacy-safe metadata policy
An output PNG contains **only**: `IHDR`, colour-management chunks (`iCCP` / `sRGB` / `gAMA` / `cHRM` / `cICP`), `PLTE`, `tRNS`, `IDAT`, `IEND` - nothing else.
Never copied from PNG, JPEG or TIFF sources: EXIF (camera, GPS, dates, serial numbers), XMP, IPTC/Photoshop data, author / owner / copyright fields,
software names, comments and descriptions (tEXt/zTXt/iTXt, JPEG COM, TIFF tags), `tIME`, `pHYs`, thumbnails, unknown or private chunks, and any bytes after IEND.
Kept, because colours would otherwise be interpreted differently: the ICC profile / sRGB / gamma / chromaticity information, plus palette and transparency where the pixel format needs them.
* Enforced in three independent places: the readers only collect the chunks above; `PngWriter` refuses to write any other chunk; and `PngPrivacy.audit` re-reads the FINISHED file chunk by chunk (types, order, checksums, nothing after IEND, colour chunks identical to the source's) as part of verification, before the file is published. The audit is not optional (it also runs when pixel verification is switched off). A failure deletes the temporary file and nothing is kept.
* Pixels are never touched: rows pass through byte for byte, and the pixel verification still compares every row.
* The ICC profile bytes are carried over unchanged. Only the free-text profile NAME in the iCCP header (taken from the source file) is replaced by the neutral "ICC Profile". Texts *inside* a profile (its description / copyright line, e.g. "Copyright 1999 Adobe Systems" in Adobe RGB) are part of the profile and are kept: they describe the colour space, not you or your device.
* The file system's own "date modified" of the output file is set by Android when the file is created; it is not PNG metadata and not controlled by the engine. The file NAME (first-last.png) is derived from your input file names, as specified.
* No network access, analytics or telemetry exists in the app: the manifest declares no permissions (the build script `scripts/verify-apk.sh` fails if an APK declares any).
* Tests (`MetadataPrivacyTest`, 13): sources carrying EVERY kind of chunk above (plus bytes after IEND), a JPEG with EXIF/GPS/XMP/IPTC/COM/ICC, a TIFF with author/copyright/software/description/XMP/IPTC tags, all stuffed with unique `TOKEN-...` strings; outputs are checked by an independent chunk parser written in the test (exact chunk list, no forbidden chunk, none of the tokens anywhere in the bytes), pixels are compared with ImageIO and Pillow, 8/16-bit, alpha, palette+tRNS, 1-bit, sRGB/gAMA/cHRM/iCCP are kept, and the audit itself is shown to reject every metadata chunk type in either position, data after IEND, and wrong colour profiles. Mutation checks: a writer that smuggles a chunk, a non-neutral profile name, a missing after-IEND check and a skipped audit are all caught. (A fifth mutation - letting the audit accept unknown chunk types - is not caught because a second rule in the audit rejects such a chunk anyway; that redundancy is intentional.)

## Mass PNG Rename (Phase 1)
Home screen -> "Mass PNG Rename". Renames PNG files **in place** (same folder) - a pure file rename, not a conversion.
* **Recognition**: two whole-name patterns. *Numeric ranges* `<start>-<end>[ (n)].png`, e.g. `001-008 (1).png`, `9-17.png`, `009-017 (2).PNG` (a single `(n)` duplicate suffix is ignored, `start <= end` is required). *Standalone numbers* `<digits>.png`, e.g. `116.png`, `001.png`, `000146.png`. Leading zeros are fine and the extension is case-insensitive for both. Anything else (`cover.png`, `image-final.png`, `notes 001-008.png`, `008-001.png`, `.jpg` ...) is listed as *skipped* and never touched.
* **Order and names**: all range files first, sorted by range start, then end, then natural name; then all standalone files, sorted by numeric value (then natural name). Selection order, dates and sizes are ignored. Numbered `001.png`, `002.png` ... from 1 on every run (4+ digits only if more than 999 files). Files with the same range / the same number (`1.png` and `001.png`) each get their own number and a note in the preview. Example: `001-009, 010-018, 019-027, 146, 116` -> `001, 002, 003` for the ranges, `116.png` -> `004.png`, `146.png` -> `005.png`.
* **Preview and confirmation**: tick files -> "Preview rename" shows old -> new names, the skipped files, destination conflicts and the counts. Nothing is renamed until "Rename N file(s)" is pressed. The folder is re-read right before the run; if it changed, the new preview is shown instead of renaming.
* **Safety**: if any destination name is already used by a file that is *not* part of the rename (case-insensitive) nothing is renamed. A destination that is the current name of another *selected* file (e.g. renaming `002.png, 116.png` to `001.png, 002.png`) is allowed, because every selected file is first moved to a temporary name. Renames go through unique temporary names (phase 1: all originals -> temporary, phase 2: temporary -> final) so selected files can never collide. Any failure undoes everything in reverse order; files that could not be restored are reported with their current names. Nothing is deleted or overwritten. The Android adapter reads the display name back after every rename and treats a provider-chosen different name as a failure.
* **Integrity**: only `DocumentsContract.renameDocument` (metadata) is used; file bytes are never opened, decoded or copied, no thumbnails are made.
* **Limits**: works on the files directly inside the chosen folder (no subfolder browsing); requires the storage provider to support rename (a provider that does not will fail on the first rename with nothing changed); the SAF adapter and the screens have not been compiled or run here (the engine logic is tested with real file renames).

## Picker screen (Compose UI - NOT compiled or run in the build environment)
* **Drag-select**: long-press an image, then drag across others to select them (long-press an already selected image to deselect by dragging). The grid scrolls by itself near the top/bottom edge. A normal swipe still scrolls, a tap still toggles. The touched images are applied together, in touch order, with the normal rules; for stitching the first rejection (12,000 px limit, width or colour-profile mismatch) stops the batch and is explained, images before it stay selected.
* **Auto-hiding UI (scroll direction)**: scrolling DOWN hides the whole UI (top bar, summary/progress panel, action buttons); scrolling UP (even a few millimetres) or reaching the top brings it back with a quick (~0.15 s) animation. Nothing is left behind: the grid is never padded or resized; at rest the first/last row are kept clear of the bars by spacer items inside the grid that scroll away with the content. A drag-selection also hides the UI and shows it again when it ends. A starting job shows it once, after which it follows the scroll direction like normal (scroll up to reach Cancel).
* **Compact UI**: one ~44 dp top row (back, title + folder, up, folder) and a two-line bottom panel (summary + capacity bar, then output / Change / Clear / primary action). Touch targets are >= 40 dp.
* **Stitch layout**: always exactly 3 columns (the 2|3 switch and its saved preference were removed). Previews are display-only bitmaps (320 px longest side); originals are never resized, cropped, padded or re-encoded for display.
* **TIFF layout**: a compact one-column, filename-only list (no thumbnails, no previews, no column options). Tap / long-press-drag selection, the per-file status line (Waiting / Converting / Done / Failed), conversion controls and progress are unchanged.
* **Scrolling performance** (display only, never affects output): previews are rendered by the engine's streaming sampler (no full-size Bitmap), cached in a 40 MB LRU, requested only after a 50 ms delay so fast flings cost nothing, and cancelled when the cell leaves the screen (a running decode stops within ~32 rows); known failures are not retried on every scroll. Cell lists are memoised, tap/drag lookups are O(1), drag hit-testing uses the grid's layout info instead of per-cell position callbacks. A PNG preview still has to inflate the whole file (PNG cannot be decoded at reduced size), so very large PNGs remain the slowest thumbnails; JPEG reduced-size decoding was NOT added.
* **Immersive full screen**: status and navigation bars are hidden; swiping from the screen edge shows them briefly. Re-applied whenever the app regains focus (after dialogs or the folder picker; on some Android versions the bars can flash while a dialog is open). Content keeps clear of a camera cut-out.
* A thumbnail that cannot be rendered now says "No preview: <reason>" instead of staying blank, so a failure is not mistaken for "still loading".
* All of this is display only; it does not touch image decoding, stitching or output.

## Supported inputs
* **PNG**: all colour types/depths, non-interlaced. Colour chunks (iCCP, sRGB, gAMA, cHRM, cICP), palette and tRNS are preserved.
* **TIFF** (classic, single page, striped, chunky): gray 1/2/4/8/16, RGB 8/16, palette 1-8 (only if the 16-bit colour map is exactly 8-bit representable), +1 *unassociated* alpha (gray+alpha, RGBA); None / LZW / Deflate / PackBits; predictor 2 (8/16-bit); ICC profile; Orientation 1-8 (see above).
* **JPEG** (detected by its first bytes, whatever the file is called - e.g. "JPEG (saved as .png)"): baseline / extended-sequential, 8-bit, Huffman, grayscale or YCbCr 4:4:4 / 4:2:2 / 4:2:0, restart markers, embedded ICC profile (carried into the PNG). Decoded by the engine's own streaming decoder, which reproduces the libjpeg reference arithmetic (islow IDCT, fancy chroma upsampling, fixed-point YCbCr->RGB). The output PNG stores exactly those decoded 8-bit values: no resize/crop/interpolation, no re-compression, no colour conversion. **A JPEG is already lossy: the PNG cannot restore what JPEG compression discarded, it only adds nothing further.**
* **Multi-page TIFF** (TIFF to PNG tool): every page (image directory in the file's main chain) becomes its own lossless PNG with that page's own size, bit depth, colour type, alpha and ICC profile; pages are never merged or flattened. Names: single-page `a.tif` -> `a.png`; multi-page `a_p001.png`, `a_p002.png` ... (at least 3 digits); an existing file or another output with the same name gets ` (1)`, ` (2)` ... A page that cannot be preserved exactly (e.g. CMYK) fails alone with its page number; the other pages still convert. The preview shows page 1. Stitching still accepts single-page TIFF only.
* **Rejected with a reason**: BigTIFF, tiled, planar, CMYK/Lab/YCbCr, JPEG/CCITT/other compression *inside TIFF*, float or signed samples, 12-bit etc., premultiplied alpha, unmarked extra channel, ICC profile not matching the colour model, interlaced PNG, WebP/other unknown formats, progressive / arithmetic / 12-bit / CMYK / RGB-stored JPEG, unusual JPEG subsampling, JPEG with an EXIF rotation flag (orientation 2-8), truncated JPEG, mixed width / bit depth / colour type / colour profile in one stitch.

## Known limitations
* **JPEG decoding is not unique.** Different decoders can differ by a few levels. The engine matches libjpeg (ImageIO, libjpeg-turbo) bit for bit on all tested files; another decoder (e.g. Android's `BitmapFactory`, a phone gallery, Photoshop) may show values that differ slightly from this PNG. That is a property of JPEG, not a loss introduced by the app.
* **Colour profiles are never mixed silently.** A PNG tagged with a profile (the sample `itloads.png` is Adobe RGB (1998)) and an untagged JPEG are reported as a colour-profile mismatch and not combined: the same numbers mean different colours under different profiles. Untagged PNGs and untagged JPEGs stitch together normally.
* JPEG has no checksum: flipped bits inside the compressed data usually decode to wrong pixels without any error (truncation, impossible codes and bad restart markers ARE detected and rejected). PNG inputs do carry checksums.
* Progressive JPEG is not supported yet (rejected with a message, never approximated).
* Not carried over: PNG text/pHYs/eXIf chunks and TIFF resolution/EXIF/XMP/other tags (pixel data and colour information are).
* ICC profile name in the output PNG is always "ICC Profile" (profile bytes are identical).
* Stitching needs identical pixel format for all images (no silent promotion 8->16-bit etc.).
* Jobs run in the ViewModel with the screen kept on; they are not a foreground service. If Android kills the process, the job stops; only a `.part` file can remain (see above) and it is cleaned up on the next job.
* The picker browses a folder you grant through the system folder dialog (no storage permissions, no INTERNET permission). On Android 11+ the system does not allow granting a storage root or the Downloads folder itself - pick a sub-folder. Default output is the folder of the first selected image; "Change" picks another.
* Speed on real devices is unmeasured (pure-Kotlin PNG filtering + zlib).
