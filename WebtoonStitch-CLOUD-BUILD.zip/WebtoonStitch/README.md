# Webtoon Stitch

Android app with exactly two tools, derived in spirit from [ImageToolbox](https://github.com/T8RIN/ImageToolbox) (Apache-2.0; see `NOTICE`, `LICENSE`):

1. **Image Stitching** - join same-width PNG/TIFF panels top-to-bottom into one gapless PNG (max 12,000 px combined height, natural filename order, output named `first-last.png`).
2. **TIFF to PNG** - convert single-page TIFF files to PNG, same name, pixel-identical.

Principle: *preserve the original image; never degrade silently.* Anything that cannot be preserved exactly is rejected with a reason.

## Status - what has and has not been checked

| Level | Status | What it covers |
|---|---|---|
| **Engine tests EXECUTED** | **done** (JDK 21, JVM) | 73 tests in `:engine` + 3 large-input tests under a 128 MB heap, all passing. Details below. |
| **Android source STATICALLY REVIEWED** | **done, by reading + partial tooling** | Whole `:app` module and Gradle files read through; version compatibility checked against official docs; non-UI Android code compiled against *hand-written stubs*; a script checked Compose files for missing imports. This is **not** compilation. |
| **Android COMPILATION** | **PENDING** | Never compiled: no Android SDK was available. Expect to fix small errors on the first build, especially in the Compose UI files. |
| **DEVICE TESTING** | **PENDING** | Never run on a device or emulator: SAF providers, thumbnails, rotation, memory and speed on real hardware are all untested. |

No APK has been built.

## Layout
| Module | What | Android dependency |
|---|---|---|
| `:engine` | Streaming PNG reader/writer, TIFF decoder, stitcher, verification, natural sort, selection rules, job runners (atomic output) | **none** (pure Kotlin/JVM) |
| `:app` | Compose UI, in-app folder picker, Storage Access Framework adapters, ViewModels | yes |

Why a new engine instead of reusing ImageToolbox's: its stitcher and TIFF path go through Android `Bitmap` (8-bit, premultiplied alpha, whole image in RAM) plus resize/scale options. That cannot keep 16-bit data or exact alpha, and cannot stream.

## Atomic output (no partial file can look finished)
Every output (stitched PNG or converted TIFF) goes through the same steps (`Jobs.kt`):
1. create `<final name>.webtoonstitch.part` (a name that is never an image) in the output folder;
2. stream the PNG into it;
3. re-read the whole file and compare it sample-by-sample with the sources;
4. last cancel point, then re-check that the final name is still free (never overwrite; otherwise `name (1).png`);
5. **rename** to the final name. Only now does a finished file exist.

Failure, cancellation, full storage, corrupt read-back or out-of-memory delete the `.part` file. If the **process is killed**, at worst a `.part` file stays behind; it is deleted at the start of the next job (only names containing `.webtoonstitch.part`; other files are never touched). If the storage provider cannot rename, the job fails with a message and keeps nothing - it never falls back to writing the final name directly or to copy-and-delete.
The Android implementation (`SafOutputFolder`) uses `DocumentsContract.createDocument` (MIME `application/octet-stream`, so providers do not append `.png`) and `DocumentsContract.renameDocument`. The system `ExternalStorageProvider` supports rename; some cloud providers may not, and will then be refused with a clear message.

## TIFF Orientation 2-8: memory limitation
* Orientation 1 (normal, top-left) is **streamed** - memory is about one row regardless of image size.
* Orientations 2-8 (mirrored/rotated) cannot be done row by row, because the first output row depends on the *last* input rows. They are applied **exactly** (no resampling) by holding the complete raster in memory:
  `memory needed ≈ width × height × bytes-per-pixel` (e.g. 690×12000 RGB 8-bit ≈ 25 MB; 4096×12000 RGB 16-bit ≈ 281 MB).
* If that exceeds about 70 % of the app's maximum heap, the file is **rejected when it is opened** (so the picker refuses it at selection time, before any output exists) with a message that states the needed and available memory. There is deliberately **no downsampling or other lossy fallback**.
* Orientation 2-8 with samples below 8 bits is rejected (bit-level moves are not implemented).
* Workaround: re-save the TIFF with Orientation = top-left, or use a device with more memory.

## Build (on your machine)
Requires Android Studio (or JDK 17+ and the Android SDK platform 35).
```
./gradlew :engine:test                 # engine tests
./gradlew :engine:largeInputTest       # ~375 MB of pixels inside a 128 MB heap
./gradlew :app:assembleDebug           # -> app/build/outputs/apk/debug/app-debug.apk   (arm64-v8a only)
./gradlew :app:assembleRelease         # signed with the debug key; use your own signing config to distribute
```
### Toolchain (checked against official documentation)
| Component | Version | Evidence |
|---|---|---|
| Gradle (wrapper) | 8.11.1 | AGP 8.7 requires >= 8.9; Kotlin 2.1.20 is "fully compatible with Gradle 7.6.3 through 8.11" (kotlinlang.org *What's new in Kotlin 2.1.20*) |
| Android Gradle Plugin | 8.7.3 | needs Gradle >= 8.9, JDK >= 17, supports up to API 35 (developer.android.com *AGP 8.7.0 release notes*) |
| Kotlin + Compose compiler plugin | 2.1.20 | as above |
| JDK | 17 or newer (Android Studio's bundled JDK 21 is fine) | Gradle runs on Java 21 since 8.5 (docs.gradle.org *compatibility*) |
| compileSdk / targetSdk / minSdk | 35 / 35 / 24 | API 35 is AGP 8.7's maximum; minSdk 24 as in ImageToolbox |
| Compose BOM | 2025.04.00 | listed on the official BOM mapping page; the exact artifact versions it maps to could **not** be read from the fetched page |
| activity-compose 1.10.1, lifecycle-viewmodel-compose 2.8.7, coroutines 1.10.1 | pinned | chosen as an April-2025 era set; per-library minimum compileSdk/AGP was **not** individually verified. If Gradle's `checkAarMetadata` complains, either raise compileSdk (needs a newer AGP) or lower the offending library version |

Not verified: whether Kotlin 2.1.20 officially lists AGP 8.7.x (the page I could read gave no AGP range). If Android Studio proposes upgrading AGP/Gradle/Kotlin together, accepting that is fine; this project uses no deprecated plugin APIs that I know of.

Offline JVM-only runners (no Gradle): `scripts/jvm-test.sh` (engine tests; exits 0 only if >= 1 test ran and none failed; 1 = compile/test failure; 2 = nothing to run) and `scripts/android-logic-stubcheck.sh` (stub-based type check of the non-UI Android code).

## What the engine tests cover (executed)
Expected values come from the JDK's own ImageIO PNG/TIFF codecs or hand-computed pixels, not only from this code.
* **PNG**: every colour type x bit depth round-trips byte-exact; independent ImageIO decode agrees (8-bit RGBA, 16-bit gray, 16-bit RGB); corrupt/truncated/interlaced files are rejected.
* **TIFF**: 50 ImageIO-encoded files (gray8, gray16, rgb8, rgba8, rgb16 x None/LZW/Deflate/ZLib/PackBits x smooth/noise) and 56 hand-built combinations (big/little endian x compression x predictor x 8/16-bit x 1/3 channels), WhiteIsZero at 1/2/4/8/16-bit, palette, alpha, all 8 orientations, ICC byte-for-byte, unsupported-format rejections, truncated/corrupt input.
* **Stitching**: the 690 x (4000+3500+4500) = 690 x 12000 example, 16-bit gray/RGB/RGBA, natural order, width/height/format/colour-profile limits, cancellation, one-sample tamper detection, missing/duplicated rows.
* **Atomic output & stability**: final name never visible during write/verify; simulated process kill leaves only a `.part` file and the next run cleans it; cancel after verification but before publish; provider without rename; name taken while working; full storage; corrupted read-back; deleted source; per-file TIFF failures. No partial or unverified output is ever left under a final name.
* **Memory**: 375 MB of pixel data stitched and 281 MB single-strip TIFFs converted within a 128 MB heap (peak used < 15 MB); too-large oriented TIFF rejected cleanly at open.
* **Mutation checks**: deliberately broken LZW / byte-swap / temp-cleanup / re-check / cancel-point code is caught by the suite.
* **Test harness self-test**: `scripts/jvm-test.sh` was run against injected compile errors, failing tests, a crashing test class, empty test sets and a filter that matches nothing - all give a non-zero exit. (Note: JUnit counts assumption-skipped tests as executed; the 3 large-input tests skip themselves under the default heap.)

## Supported inputs
* **PNG**: all colour types/depths, non-interlaced. Colour chunks (iCCP, sRGB, gAMA, cHRM, cICP), palette and tRNS are preserved.
* **TIFF** (classic, single page, striped, chunky): gray 1/2/4/8/16, RGB 8/16, palette 1-8 (only if the 16-bit colour map is exactly 8-bit representable), +1 *unassociated* alpha (gray+alpha, RGBA); None / LZW / Deflate / PackBits; predictor 2 (8/16-bit); ICC profile; Orientation 1-8 (see above).
* **Rejected with a reason**: multi-page, BigTIFF, tiled, planar, CMYK/Lab/YCbCr, JPEG/CCITT/other compression, float or signed samples, 12-bit etc., premultiplied alpha, unmarked extra channel, ICC profile not matching the colour model, interlaced PNG, JPEG/WebP/other formats, mixed width / bit depth / colour type / colour profile in one stitch.

## Known limitations
* Not carried over: PNG text/pHYs/eXIf chunks and TIFF resolution/EXIF/XMP/other tags (pixel data and colour information are).
* ICC profile name in the output PNG is always "ICC Profile" (profile bytes are identical).
* Stitching needs identical pixel format for all images (no silent promotion 8->16-bit etc.).
* Jobs run in the ViewModel with the screen kept on; they are not a foreground service. If Android kills the process, the job stops; only a `.part` file can remain (see above) and it is cleaned up on the next job.
* The picker browses a folder you grant through the system folder dialog (no storage permissions, no INTERNET permission). On Android 11+ the system does not allow granting a storage root or the Downloads folder itself - pick a sub-folder. Default output is the folder of the first selected image; "Change" picks another.
* Speed on real devices is unmeasured (pure-Kotlin PNG filtering + zlib).
