package com.webtoonstitch.engine

/** Format sniffing: PNG and TIFF are the formats the engine can decode with no loss of information. */
object ImageDecoders {
    fun open(input: ImageInput): RowSource {
        val head = ByteArray(4)
        val n = try {
            input.openStream().use { s -> var k = 0; while (k < 4) { val r = s.read(head, k, 4 - k); if (r < 0) break; k += r }; k }
        } catch (e: java.io.IOException) {
            throw unreadable(input.name, "could not be opened. It may have been deleted, moved, or is not accessible.", e)
        } catch (e: SecurityException) {
            throw unreadable(input.name, "access to this file was denied.", e)
        }
        return when {
            n == 4 && head[0] == 0x89.toByte() && head[1] == 'P'.code.toByte() -> PngReader.open(openStreamSafely(input), input.name)
            n == 4 && ((head[0] == 'I'.code.toByte() && head[1] == 'I'.code.toByte() && head[2].toInt() == 42) ||
                (head[0] == 'M'.code.toByte() && head[1] == 'M'.code.toByte() && head[3].toInt() == 42)) -> Tiff.open(input)
            n == 4 && (head[2].toInt() == 43 || head[3].toInt() == 43) && (head[0] == head[1]) && (head[0] == 'I'.code.toByte() || head[0] == 'M'.code.toByte()) -> Tiff.open(input)
            else -> throw unsupported(input.name, "unsupported or unrecognised image format. Only PNG and TIFF can be processed without altering pixel data.")
        }
    }

    /** Header-only inspection; never decodes pixel data. */
    fun inspect(input: ImageInput): RasterInfo = open(input).use { it.info }

    internal fun openStreamSafely(input: ImageInput): java.io.InputStream = try {
        input.openStream()
    } catch (e: java.io.IOException) {
        throw unreadable(input.name, "could not be opened. It may have been deleted, moved, or is not accessible.", e)
    }
}
