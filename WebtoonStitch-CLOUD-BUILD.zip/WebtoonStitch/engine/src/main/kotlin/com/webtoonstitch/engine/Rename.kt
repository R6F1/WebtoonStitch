package com.webtoonstitch.engine

import java.io.IOException

/*
 * Mass PNG rename (filesystem level only).
 *
 * Nothing in this file reads, decodes or writes image data: it works on FILE NAMES and asks the storage layer to rename. A renamed
 * file is therefore the same bytes under a new name. The storage layer (SAF on Android, java.nio in tests) is behind [RenameFolder].
 */

/** Inclusive numeric range taken from a name such as "009-017 (1).png". */
data class NumericRange(val start: Long, val end: Long)

object RenameNaming {
    // Whole-name match: <digits> - <digits> [ (<digits>) ] .png ; the extension is matched case-insensitively.
    private val PATTERN = Regex("""^(\d+)\s*-\s*(\d+)(?:\s*\(\d+\))?\.png$""", RegexOption.IGNORE_CASE)

    /** The range encoded in [name], or null when the name is not a numeric-range PNG name (or the range is reversed / too large). */
    fun parseRange(name: String): NumericRange? {
        val m = PATTERN.matchEntire(name.trim()) ?: return null
        val a = m.groupValues[1].toLongOrNull() ?: return null
        val b = m.groupValues[2].toLongOrNull() ?: return null
        return if (a <= b) NumericRange(a, b) else null
    }

    /** "001.png", "002.png" ... at least 3 digits; wider only when there are more than 999 files (so names still sort). */
    fun targetName(index1: Int, total: Int): String {
        val width = maxOf(3, total.toString().length)
        return index1.toString().padStart(width, '0') + ".png"
    }
}

data class RenameItem(val originalName: String, val newName: String, val range: NumericRange)
data class SkippedFile(val name: String, val reason: String)

/** A planned destination name that is already taken by a file in the folder. */
data class RenameConflict(val newName: String, val originalName: String)

class RenamePlan(
    val items: List<RenameItem>,
    val skipped: List<SkippedFile>,
    val conflicts: List<RenameConflict>,
    /** Human-readable notes for files that share the same range (they are still renamed, one number each). */
    val duplicateRangeNotes: List<String>
) {
    /** Nothing may run when there is nothing to rename or any destination name is already taken. */
    val canExecute: Boolean get() = items.isNotEmpty() && conflicts.isEmpty()
}

object RenamePlanner {
    /**
     * Builds the plan. Pure: touches nothing. [selected] are the chosen file names, [existingNames] every name currently in the
     * folder (used to detect destination collisions, case-insensitively because many storage providers are).
     * Recognised files are ordered by range start (then end, then natural name order) - the order of [selected], dates and sizes
     * are ignored - and numbered 001, 002, ... from 1 for every plan.
     */
    fun plan(selected: List<String>, existingNames: Collection<String>): RenamePlan {
        val recognised = ArrayList<Pair<String, NumericRange>>()
        val skipped = ArrayList<SkippedFile>()
        for (name in selected.distinct()) {
            val r = RenameNaming.parseRange(name)
            if (r == null) skipped += SkippedFile(name, "no numeric range in the name") else recognised += name to r
        }
        recognised.sortWith(
            compareBy<Pair<String, NumericRange>> { it.second.start }.thenBy { it.second.end }
                .thenComparator { a, b -> NaturalFilenameComparator.compare(a.first, b.first) }
                .thenBy { it.first }
        )
        val items = recognised.mapIndexed { i, (name, r) -> RenameItem(name, RenameNaming.targetName(i + 1, recognised.size), r) }
        val taken = existingNames.mapTo(HashSet()) { it.lowercase() }
        val conflicts = items.filter { it.newName.lowercase() in taken }.map { RenameConflict(it.newName, it.originalName) }
        val dups = items.groupBy { it.range }.filter { it.value.size > 1 }.map { (r, v) ->
            "Range ${r.start}-${r.end} appears ${v.size} times: " + v.joinToString(", ") { it.originalName } + " (each still gets its own number)"
        }
        return RenamePlan(items, skipped, conflicts, dups)
    }
}

/** Storage operations the executor needs. Names are plain file names inside ONE folder. */
interface RenameFolder {
    fun exists(name: String): Boolean
    /** Renames [from] to [to]. Must fail (throw) instead of overwriting or silently choosing another name. */
    fun rename(from: String, to: String)
}

/** Thrown by a [RenameFolder] when a rename could not be undone by the folder itself: the file now has the name [nowNamed]. */
class StrandedRenameException(val from: String, val nowNamed: String, message: String) : IOException(message)

enum class RenameStatus {
    /** Every planned file was renamed. */
    DONE,
    /** Nothing was changed: the plan could not run (conflict, nothing to rename, folder changed, already executed). */
    REFUSED,
    /** A rename failed; every file already renamed was restored to its original name. */
    FAILED_RESTORED,
    /** A rename failed and some files could NOT be restored; see [RenameResult.stranded]. */
    FAILED_NOT_RESTORED
}

class RenameResult(
    val status: RenameStatus,
    val renamed: List<RenameItem>,
    val skipped: List<SkippedFile>,
    val message: String,
    /** Files not under their original name after a failed run: original name -> name it has now. Never deleted. */
    val stranded: List<Pair<String, String>> = emptyList()
)

object RenameExecutor {
    /**
     * Runs [plan] in two phases so that no selected file can ever collide with another:
     *  1. every file is renamed to a unique temporary name,
     *  2. every temporary name is renamed to its final name.
     * Before anything is touched all sources must exist and all destinations must be free. If any rename fails, the journal of
     * completed renames is undone in reverse order. Nothing is ever deleted or overwritten.
     */
    fun execute(folder: RenameFolder, plan: RenamePlan): RenameResult {
        if (plan.items.isEmpty()) return RenameResult(RenameStatus.REFUSED, emptyList(), plan.skipped, "Nothing to rename: none of the selected files has a numeric range in its name.")
        if (plan.conflicts.isNotEmpty()) return RenameResult(RenameStatus.REFUSED, emptyList(), plan.skipped, "Nothing was renamed: ${plan.conflicts.joinToString { it.newName }} already exist(s) in the folder.")
        for (it in plan.items) {
            if (!folder.exists(it.originalName)) return RenameResult(RenameStatus.REFUSED, emptyList(), plan.skipped, "Nothing was renamed: ${it.originalName} is no longer in the folder.")
            if (folder.exists(it.newName)) return RenameResult(RenameStatus.REFUSED, emptyList(), plan.skipped, "Nothing was renamed: ${it.newName} already exists in the folder.")
        }

        val where = LinkedHashMap<RenameItem, String>()       // where each file is RIGHT NOW (starts at its original name)
        for (it in plan.items) where[it] = it.originalName
        var failure: String? = null
        val token = java.lang.Long.toString(System.nanoTime(), 36)

        // Moves item to [to]; on failure records why and (if the folder says so) where the file ended up.
        fun move(item: RenameItem, to: String): Boolean = try {
            folder.rename(where.getValue(item), to); where[item] = to; true
        } catch (e: StrandedRenameException) {
            where[item] = e.nowNamed; failure = "${item.originalName}: ${e.message}"; false
        } catch (e: Exception) {
            failure = "${item.originalName}: ${e.message ?: e.javaClass.simpleName}"; false
        }

        val used = HashSet<String>()
        run {
            for ((i, item) in plan.items.withIndex()) {
                var tmp: String
                var n = 0
                do { tmp = "wtsrename_${token}_${i}_$n.png"; n++ } while (folder.exists(tmp) || tmp in used)
                used += tmp
                if (!move(item, tmp)) return@run
            }
            for (item in plan.items) if (!move(item, item.newName)) return@run
        }

        if (failure == null) {
            return RenameResult(RenameStatus.DONE, plan.items, plan.skipped, "Renamed ${plan.items.size} file(s). File contents were not touched.")
        }

        // Roll back, last file first: every file not under its original name is moved back.
        for (item in plan.items.asReversed()) {
            val now = where.getValue(item)
            if (now == item.originalName) continue
            try {
                folder.rename(now, item.originalName); where[item] = item.originalName
            } catch (e: StrandedRenameException) {
                where[item] = e.nowNamed
            } catch (_: Exception) {
                // stays where it is; reported below
            }
        }
        val stranded = plan.items.filter { where.getValue(it) != it.originalName }.map { it.originalName to where.getValue(it) }
        return if (stranded.isEmpty()) {
            RenameResult(RenameStatus.FAILED_RESTORED, emptyList(), plan.skipped, "Renaming stopped ($failure). Every file was restored to its original name; nothing was changed.")
        } else {
            RenameResult(
                RenameStatus.FAILED_NOT_RESTORED, emptyList(), plan.skipped,
                "Renaming stopped ($failure) and ${stranded.size} file(s) could not be restored. They were NOT deleted; they are now named: " +
                    stranded.joinToString("; ") { "${it.first} -> ${it.second}" },
                stranded
            )
        }
    }
}

/**
 * One rename operation with an explicit confirmation step. Creating the session only builds the preview ([plan]) and changes
 * nothing; the folder is modified only by [confirmAndRun], which can run once.
 */
class RenameSession(private val folder: RenameFolder, selected: List<String>, existingNames: Collection<String>) {
    val plan: RenamePlan = RenamePlanner.plan(selected, existingNames)
    private var used = false

    fun confirmAndRun(): RenameResult {
        if (used) return RenameResult(RenameStatus.REFUSED, emptyList(), plan.skipped, "This rename was already executed.")
        used = true
        return RenameExecutor.execute(folder, plan)
    }
}
