package com.webtoonstitch.engine

/**
 * Size-bounded least-recently-used cache for DISPLAY previews (the UI stores Bitmaps in it). Thread-safe. Generated previews
 * are kept so that scrolling back never decodes an image again; [trimTo] / [clear] give memory back when the system asks.
 * Not used by any export code.
 */
class PreviewCache<V : Any>(private val maxBytes: Long, private val sizeOf: (V) -> Long) {
    private val map = LinkedHashMap<String, V>(32, 0.75f, true)   // access order: eldest = least recently used
    private var bytes = 0L
    private var hitCount = 0L
    private var missCount = 0L

    @Synchronized fun get(key: String): V? {
        val v = map[key]
        if (v == null) missCount++ else hitCount++
        return v
    }

    /** Looks without counting a hit or miss and without refreshing recency (for UI polling while composing). */
    @Synchronized fun peek(key: String): V? = map[key]

    @Synchronized fun put(key: String, value: V) {
        map.put(key, value)?.let { bytes -= sizeOf(it) }
        bytes += sizeOf(value)
        evictTo(maxBytes)
    }

    /** Evicts least-recently-used entries until at most [limit] bytes remain. */
    @Synchronized fun trimTo(limit: Long) = evictTo(limit.coerceAtLeast(0))

    @Synchronized fun clear() { map.clear(); bytes = 0 }

    private fun evictTo(limit: Long) {
        val it = map.entries.iterator()
        while (bytes > limit && it.hasNext()) {
            val e = it.next()
            bytes -= sizeOf(e.value)
            it.remove()
        }
    }

    @get:Synchronized val sizeBytes: Long get() = bytes
    @get:Synchronized val count: Int get() = map.size
    @get:Synchronized val hits: Long get() = hitCount
    @get:Synchronized val misses: Long get() = missCount
    val capacityBytes: Long get() = maxBytes
}
