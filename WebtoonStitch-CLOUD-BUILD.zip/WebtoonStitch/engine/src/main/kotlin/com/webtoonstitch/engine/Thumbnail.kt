package com.webtoonstitch.engine

/** Small RGB preview for the UI. DISPLAY ONLY: previews are never used to produce output files. */
class Thumbnail(val width: Int, val height: Int, val argb: IntArray)

object Thumbnails {
    /**
     * Streams the image once, keeping only every k-th row/column (nearest sampling, no full-size buffer).
     * 16-bit samples use the high byte; alpha is composited on a mid-grey checker so transparency is visible.
     */
    fun render(source: RowSource, maxSide: Int, cancel: CancelCheck = CancelCheck.NONE): Thumbnail {
        val info = source.info
        val step = maxOf(1, (maxOf(info.width, info.height) + maxSide - 1) / maxSide)
        val tw = (info.width + step - 1) / step
        val th = (info.height + step - 1) / step
        val out = IntArray(tw * th)
        val row = ByteArray(info.rowBytes)
        val pal = info.palette
        val d = info.bitDepth
        val ch = info.channels
        var oy = 0
        for (y in 0 until info.height) {
            if (y and 31 == 0) cancel.check()
            source.readRow(row)
            if (y % step != 0) continue
            for (ox in 0 until tw) {
                val x = ox * step
                var r: Int; var g: Int; var b: Int; var a = 255
                when (info.colorType) {
                    3 -> { val i = sample(row, x, d); r = pal!![i * 3].toInt() and 255; g = pal[i * 3 + 1].toInt() and 255; b = pal[i * 3 + 2].toInt() and 255 }
                    0, 4 -> { val v = if (d < 8) sample(row, x, d) * 255 / ((1 shl d) - 1) else hi(row, (x * ch) * (d / 8), d); r = v; g = v; b = v; if (ch == 2) a = hi(row, (x * ch + 1) * (d / 8), d) }
                    else -> { val o = (x * ch) * (d / 8); val s = d / 8; r = hi(row, o, d); g = hi(row, o + s, d); b = hi(row, o + 2 * s, d); if (ch == 4) a = hi(row, o + 3 * s, d) }
                }
                if (a < 255) {
                    val bg = if (((ox / 4) + (oy / 4)) % 2 == 0) 200 else 150
                    r = (r * a + bg * (255 - a)) / 255; g = (g * a + bg * (255 - a)) / 255; b = (b * a + bg * (255 - a)) / 255
                }
                out[oy * tw + ox] = (255 shl 24) or (r shl 16) or (g shl 8) or b
            }
            oy++
        }
        return Thumbnail(tw, th, out)
    }

    private fun hi(row: ByteArray, o: Int, depth: Int) = row[o].toInt() and 255
    private fun sample(row: ByteArray, x: Int, depth: Int): Int = when (depth) {
        8 -> row[x].toInt() and 255
        else -> { val bit = x * depth; ((row[bit / 8].toInt() and 255) shr (8 - depth - bit % 8)) and ((1 shl depth) - 1) }
    }
}
