package com.webtoonstitch.engine

/** Small RGB preview for the UI. DISPLAY ONLY: previews are never used to produce output files. */
class Thumbnail(val width: Int, val height: Int, val argb: IntArray)

object Thumbnails {
    /**
     * Streams the image once, keeping only every k-th row/column (nearest sampling, no full-size buffer).
     * 16-bit samples use the high byte; alpha is composited on a mid-grey checker so transparency is visible.
     */
    fun render(source: RowSource, maxSide: Int, cancel: CancelCheck = CancelCheck.NONE): Thumbnail {
        val info = source.info
        val step = maxOf(1, (maxOf(info.width, info.height) + maxSide - 1) / maxSide)
        val tw = (info.width + step - 1) / step
        val th = (info.height + step - 1) / step
        val out = IntArray(tw * th)
        val row = ByteArray(info.rowBytes)
        val pal = info.palette
        val d = info.bitDepth
        val ch = info.channels
        var oy = 0
        for (y in 0 until info.height) {
            if (y and 31 == 0) cancel.check()
            source.readRow(row)
            if (y % step != 0) continue
            for (ox in 0 until tw) {
                val x = ox * step
                var r: Int; var g: Int; var b: Int; var a = 255
                when (info.colorType) {
                    3 -> { val i = sample(row, x, d); r = pal!![i * 3].toInt() and 255; g = pal[i * 3 + 1].toInt() and 255; b = pal[i * 3 + 2].toInt() and 255 }
                    0, 4 -> { val v = if (d < 8) sample(row, x, d) * 255 / ((1 shl d) - 1) else hi(row, (x * ch) * (d / 8), d); r = v; g = v; b = v; if (ch == 2) a = hi(row, (x * ch + 1) * (d / 8), d) }
                    else -> { val o = (x * ch) * (d / 8); val s = d / 8; r = hi(row, o, d); g = hi(row, o + s, d); b = hi(row, o + 2 * s, d); if (ch == 4) a = hi(row, o + 3 * s, d) }
                }
                if (a < 255) {
                    val bg = if (((ox / 4) + (oy / 4)) % 2 == 0) 200 else 150
                    r = (r * a + bg * (255 - a)) / 255; g = (g * a + bg * (255 - a)) / 255; b = (b * a + bg * (255 - a)) / 255
                }
                out[oy * tw + ox] = (255 shl 24) or (r shl 16) or (g shl 8) or b
            }
            oy++
        }
        return Thumbnail(tw, th, out)
    }

    /**
     * Entry point for the UI. Normal images use [render] exactly as before. Very tall images (see [TallPreview.isTall]) use the
     * balanced top + bottom preview instead of a sliver. DISPLAY ONLY.
     */
    fun renderPreview(source: RowSource, side: Int, cancel: CancelCheck = CancelCheck.NONE): Thumbnail =
        if (TallPreview.isTall(source.info, side)) TallPreview.render(source, side, cancel) else render(source, side, cancel)

    private fun hi(row: ByteArray, o: Int, depth: Int) = row[o].toInt() and 255
    private fun sample(row: ByteArray, x: Int, depth: Int): Int = when (depth) {
        8 -> row[x].toInt() and 255
        else -> { val bit = x * depth; ((row[bit / 8].toInt() and 255) shr (8 - depth - bit % 8)) and ((1 shl depth) - 1) }
    }
}

/**
 * Balanced Region Decoding preview for very tall images (webtoon strips). A whole-image thumbnail of a 690 x 12000 image is a
 * 19 px wide sliver; instead the preview shows the TOP and the BOTTOM of the image, each at a moderate integer downscale
 * (box-averaged, so text stays legible), stacked with a thin grey divider:
 *
 *     +----------+
 *     |   top    |   rr output rows  = the first rr*step source rows
 *     +----------+   GAP rows (grey divider)
 *     |  bottom  |   rr output rows  = the last  rr*step source rows
 *     +----------+
 *
 * Only the rows of those two regions are converted and accumulated; the middle rows are read (a PNG/JPEG/TIFF stream cannot
 * skip rows without decoding them) but never converted, stored or averaged. Memory is one source row, one accumulator row and
 * the small result.
 *
 * DISPLAY ONLY. This file is used by the UI preview and by nothing in the stitch / convert / rename pipelines; the output is
 * always produced from the original rows (a test checks that no export code refers to it).
 */
object TallPreview {
    /** An image is "tall" when its height is at least this many times its width ... */
    const val MIN_ASPECT = 3
    /** Height in output pixels of the divider between the top and the bottom part. */
    const val GAP = 4

    /** ... and it is more than two preview-heights tall (otherwise the ordinary preview is already readable). */
    fun isTall(info: RasterInfo, side: Int): Boolean =
        info.height.toLong() >= MIN_ASPECT.toLong() * info.width && info.height.toLong() > 2L * side

    /** Integer downscale factor: the preview is never wider than [side] and never upscaled. */
    fun step(width: Int, side: Int): Int = maxOf(1, (width + side - 1) / side)

    /** Output rows of each region. */
    fun regionRows(side: Int): Int = maxOf(1, (side - GAP) / 2)

    fun render(source: RowSource, side: Int, cancel: CancelCheck = CancelCheck.NONE): Thumbnail {
        val info = source.info
        val w = info.width; val h = info.height
        val step = step(w, side)
        val rr = regionRows(side)
        val srcRows = rr.toLong() * step
        // Regions must not overlap: otherwise this is not a tall image for this side; use the ordinary preview.
        if (2 * srcRows >= h) return Thumbnails.render(source, side, cancel)
        val tw = (w + step - 1) / step
        val th = rr + GAP + rr
        val out = IntArray(tw * th)
        java.util.Arrays.fill(out, rr * tw, (rr + GAP) * tw, DIVIDER)
        val acc = IntArray(tw * 4)
        val row = ByteArray(info.rowBytes)
        val bottomStart = (h - srcRows).toInt()
        val top = srcRows.toInt()
        var inBlock = 0          // source rows accumulated in the current block
        var outRow = 0           // next output row (within the whole preview)
        for (y in 0 until h) {
            if (y and 31 == 0) cancel.check()
            source.readRow(row)
            val inTop = y < top
            val inBottom = y >= bottomStart
            if (!inTop && !inBottom) continue          // middle: read, not converted
            if (y == bottomStart) { inBlock = 0; outRow = rr + GAP }
            addRow(info, row, step, tw, acc)
            inBlock++
            if (inBlock == step) {
                flush(acc, step, w, tw, out, outRow)
                outRow++; inBlock = 0
                java.util.Arrays.fill(acc, 0)
            }
        }
        return Thumbnail(tw, th, out)
    }

    private const val DIVIDER = (255 shl 24) or (128 shl 16) or (128 shl 8) or 128

    /** Adds one source row to the per-output-column channel sums (r, g, b, a). */
    private fun addRow(info: RasterInfo, row: ByteArray, step: Int, tw: Int, acc: IntArray) {
        val d = info.bitDepth; val ch = info.channels; val pal = info.palette
        for (x in 0 until info.width) {
            var r: Int; var g: Int; var b: Int; var a = 255
            when (info.colorType) {
                3 -> { val i = sample(row, x, d); r = pal!![i * 3].toInt() and 255; g = pal[i * 3 + 1].toInt() and 255; b = pal[i * 3 + 2].toInt() and 255 }
                0, 4 -> { val v = if (d < 8) sample(row, x, d) * 255 / ((1 shl d) - 1) else row[(x * ch) * (d / 8)].toInt() and 255; r = v; g = v; b = v; if (ch == 2) a = row[(x * ch + 1) * (d / 8)].toInt() and 255 }
                else -> { val s = d / 8; val o = (x * ch) * s; r = row[o].toInt() and 255; g = row[o + s].toInt() and 255; b = row[o + 2 * s].toInt() and 255; if (ch == 4) a = row[o + 3 * s].toInt() and 255 }
            }
            val k = (x / step) * 4
            acc[k] += r; acc[k + 1] += g; acc[k + 2] += b; acc[k + 3] += a
        }
    }

    private fun flush(acc: IntArray, step: Int, w: Int, tw: Int, out: IntArray, oy: Int) {
        for (ox in 0 until tw) {
            val cols = minOf(step, w - ox * step)
            val n = step * cols
            var r = (acc[ox * 4] + n / 2) / n; var g = (acc[ox * 4 + 1] + n / 2) / n; var b = (acc[ox * 4 + 2] + n / 2) / n
            val a = (acc[ox * 4 + 3] + n / 2) / n
            if (a < 255) {
                val bg = if (((ox / 4) + (oy / 4)) % 2 == 0) 200 else 150
                r = (r * a + bg * (255 - a)) / 255; g = (g * a + bg * (255 - a)) / 255; b = (b * a + bg * (255 - a)) / 255
            }
            out[oy * tw + ox] = (255 shl 24) or (r shl 16) or (g shl 8) or b
        }
    }

    private fun sample(row: ByteArray, x: Int, depth: Int): Int = when (depth) {
        8 -> row[x].toInt() and 255
        else -> { val bit = x * depth; ((row[bit / 8].toInt() and 255) shr (8 - depth - bit % 8)) and ((1 shl depth) - 1) }
    }
}
