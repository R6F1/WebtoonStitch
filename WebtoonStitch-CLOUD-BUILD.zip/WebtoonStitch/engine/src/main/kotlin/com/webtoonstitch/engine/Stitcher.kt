package com.webtoonstitch.engine

import java.io.InputStream
import java.io.OutputStream

/** Validated, sorted description of a stitch job. Creating it reads headers only. */
class StitchPlan internal constructor(
    val inputs: List<ImageInput>,
    val infos: List<RasterInfo>,
    val outputInfo: RasterInfo,
    val outputName: String
) {
    val width get() = outputInfo.width
    val totalHeight get() = outputInfo.height
}

class StitchResult(val width: Int, val height: Int, val imageCount: Int, val outputName: String)

object Stitcher {
    /**
     * Sorts by natural filename, inspects every header (no pixel decoding) and enforces:
     * identical width, identical pixel format, cumulative height <= [maxHeight]. Never alters any image.
     */
    fun plan(inputs: List<ImageInput>, maxHeight: Int = MAX_STITCH_HEIGHT): StitchPlan {
        if (inputs.isEmpty()) throw EngineException(ErrorCode.NO_INPUT, "Select at least one image.")
        val sorted = inputs.sortedWith { a, b -> NaturalFilenameComparator.compare(a.name, b.name) }
        val infos = sorted.map { ImageDecodersHolder.inspect(it) }
        val w = infos[0].width
        infos.indices.firstOrNull { infos[it].width != w }?.let { i ->
            throw EngineException(
                ErrorCode.WIDTH_MISMATCH,
                "Image width mismatch. All selected images must have the same width.\n" +
                    "${sorted[0].name}: $w px\n${sorted[i].name}: ${infos[i].width} px"
            )
        }
        infos.indices.firstOrNull { !infos[0].sameFormatAs(infos[it]) }?.let { i ->
            throw EngineException(
                ErrorCode.FORMAT_MISMATCH,
                "Pixel format mismatch: ${sorted[0].name} is ${infos[0].formatLabel} but ${sorted[i].name} is ${infos[i].formatLabel} " +
                    "(or has a different palette/colour profile). They cannot be combined without altering pixels."
            )
        }
        val total = infos.sumOf { it.height.toLong() }
        if (total > maxHeight) {
            throw EngineException(
                ErrorCode.HEIGHT_LIMIT,
                "Selection limit exceeded. Maximum combined image height is ${StitchSelection.fmt(maxHeight)} px.\nThe selected images total ${StitchSelection.fmt(total.toInt())} px."
            )
        }
        val f = infos[0]
        val out = RasterInfo(w, total.toInt(), f.colorType, f.bitDepth, f.palette, f.transparency, f.colorChunks)
        return StitchPlan(sorted, infos, out, OutputNaming.stitchName(sorted.map { it.name }))
    }

    /** Streams every source row, top to bottom, straight into the PNG encoder. Memory: O(one row). */
    fun stitch(
        plan: StitchPlan, out: OutputStream,
        progress: (rowsDone: Int, rowsTotal: Int) -> Unit = { _, _ -> },
        cancel: CancelCheck = CancelCheck.NONE
    ): StitchResult {
        val row = ByteArray(plan.outputInfo.rowBytes)
        var done = 0
        try {
            PngWriter(out, plan.outputInfo).use { writer ->
                for ((i, input) in plan.inputs.withIndex()) {
                    ImageDecodersHolder.open(input).use { src ->
                        val si = src.info
                        if (si.width != plan.width || si.height != plan.infos[i].height || !si.sameFormatAs(plan.outputInfo)) {
                            throw EngineException(ErrorCode.FORMAT_MISMATCH, "${input.name} changed after it was selected.")
                        }
                        for (y in 0 until si.height) {
                            cancel.check()
                            src.readRow(row)
                            writer.writeRow(row)
                            done++
                            if (y and 63 == 0) progress(done, plan.totalHeight)
                        }
                    }
                }
                writer.finish()
            }
            progress(plan.totalHeight, plan.totalHeight)
        } catch (e: OutOfMemoryError) {
            throw EngineException(ErrorCode.OUT_OF_MEMORY, "Not enough memory to stitch these images.", e)
        }
        return StitchResult(plan.width, plan.totalHeight, plan.inputs.size, plan.outputName)
    }

    /**
     * Re-reads the finished PNG and compares every row, byte for byte, to a fresh decode of each source.
     * Also checks dimensions, colour type, bit depth, palette, transparency and colour-space chunks.
     */
    fun verify(
        plan: StitchPlan, openOutput: () -> InputStream,
        progress: (rowsDone: Int, rowsTotal: Int) -> Unit = { _, _ -> },
        cancel: CancelCheck = CancelCheck.NONE
    ) {
        PngReader.open(openOutput(), "output").use { out ->
            val oi = out.info
            if (oi.width != plan.width || oi.height != plan.totalHeight) fail("output is ${oi.width}x${oi.height}, expected ${plan.width}x${plan.totalHeight}")
            if (!oi.sameFormatAs(plan.outputInfo)) fail("output pixel format differs from the sources (${oi.formatLabel} vs ${plan.outputInfo.formatLabel})")
            val a = ByteArray(oi.rowBytes); val b = ByteArray(oi.rowBytes)
            var done = 0
            for (input in plan.inputs) {
                ImageDecodersHolder.open(input).use { src ->
                    for (y in 0 until src.info.height) {
                        cancel.check()
                        src.readRow(a); out.readRow(b)
                        if (!a.contentEquals(b)) fail("pixel data differs from ${input.name} at its row $y (output row $done)")
                        done++
                        if (y and 63 == 0) progress(done, plan.totalHeight)
                    }
                }
            }
            progress(plan.totalHeight, plan.totalHeight)
        }
    }

    private fun fail(msg: String): Nothing = throw EngineException(ErrorCode.VERIFICATION_FAILED, "Verification failed: $msg")
}

/** Indirection so Stitcher stays testable with a different decoder set if ever needed. */
internal object ImageDecodersHolder {
    fun open(i: ImageInput) = ImageDecoders.open(i)
    fun inspect(i: ImageInput) = ImageDecoders.inspect(i)
}

object TiffConverter {
    /** Throws [EngineException] (UNSUPPORTED / MULTI_PAGE / UNREADABLE) without writing anything if the TIFF cannot be preserved exactly. */
    fun inspect(input: ImageInput): RasterInfo = Tiff.open(input).use { it.info }

    fun convert(
        input: ImageInput, out: OutputStream,
        progress: (rowsDone: Int, rowsTotal: Int) -> Unit = { _, _ -> },
        cancel: CancelCheck = CancelCheck.NONE
    ): RasterInfo {
        try {
            Tiff.open(input).use { src ->
                val info = src.info
                val row = ByteArray(info.rowBytes)
                PngWriter(out, info).use { w ->
                    for (y in 0 until info.height) {
                        cancel.check()
                        src.readRow(row); w.writeRow(row)
                        if (y and 63 == 0) progress(y + 1, info.height)
                    }
                    w.finish()
                }
                progress(info.height, info.height)
                return info
            }
        } catch (e: OutOfMemoryError) {
            throw EngineException(ErrorCode.OUT_OF_MEMORY, "${input.name}: not enough memory to convert this TIFF.", e)
        }
    }

    /** Compares the PNG to a fresh decode of the TIFF: dimensions, depth, colour type, alpha, ICC profile and every sample. */
    fun verify(
        input: ImageInput, openOutput: () -> InputStream,
        cancel: CancelCheck = CancelCheck.NONE
    ) {
        Tiff.open(input).use { src ->
            PngReader.open(openOutput(), "output").use { png ->
                val a = src.info; val b = png.info
                fun fail(m: String): Nothing = throw EngineException(ErrorCode.VERIFICATION_FAILED, "${input.name}: verification failed: $m")
                if (a.width != b.width || a.height != b.height) fail("dimensions ${b.width}x${b.height} != ${a.width}x${a.height}")
                if (a.bitDepth != b.bitDepth) fail("bit depth ${b.bitDepth} != ${a.bitDepth}")
                if (a.colorType != b.colorType) fail("colour type ${b.colorType} != ${a.colorType}")
                if (a.hasAlpha != b.hasAlpha) fail("alpha channel mismatch")
                if (!a.sameFormatAs(b)) fail("palette / transparency / colour profile differ")
                val ra = ByteArray(a.rowBytes); val rb = ByteArray(a.rowBytes)
                for (y in 0 until a.height) {
                    cancel.check()
                    src.readRow(ra); png.readRow(rb)
                    if (!ra.contentEquals(rb)) fail("pixel data differs at row $y")
                }
            }
        }
    }
}
