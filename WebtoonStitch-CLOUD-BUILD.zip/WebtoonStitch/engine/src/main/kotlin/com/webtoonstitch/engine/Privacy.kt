package com.webtoonstitch.engine

import java.io.DataInputStream
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.util.zip.CRC32

/**
 * PRIVACY-SAFE METADATA POLICY for every PNG this engine writes.
 *
 * An output PNG consists of exactly these chunks and nothing else:
 *   IHDR, [colour-management chunks: iCCP | sRGB | gAMA | cHRM | cICP], [PLTE], [tRNS], IDAT..., IEND
 *
 * Never copied from PNG, JPEG or TIFF sources (none of it is needed to display the pixels correctly):
 *   EXIF incl. GPS, XMP, IPTC / Photoshop resources, author / owner / copyright, camera and device data, creation and
 *   modification times (tIME, EXIF dates), software names, text comments and descriptions (tEXt / zTXt / iTXt, JPEG COM),
 *   resolution (pHYs), thumbnails, and any unknown / private chunk or tag.
 *
 * Kept, because without it the colours would be interpreted differently: the ICC profile (iCCP) or sRGB / gAMA / cHRM / cICP
 * of the source, plus PLTE and tRNS where the pixel format needs them.
 * - The ICC profile bytes are carried over unchanged. The profile's free-text NAME in the iCCP chunk header comes from the
 *   source file and is replaced by the neutral "ICC Profile". (Texts inside the profile itself - its description, its
 *   copyright line - are part of the profile and stay; they describe the colour space, not the photographer or the device.)
 *
 * The policy is enforced in three independent places: the readers only ever collect the chunks above, [PngWriter] refuses
 * to write any other chunk, and [audit] inspects the FINISHED file before it is published. Removing metadata never touches
 * pixel rows: they pass through byte for byte (the pixel verification still compares every row).
 */
object PngPrivacy {
    const val ICC_PROFILE_NAME = "ICC Profile"

    val COLOUR_CHUNKS: Set<String> = setOf("iCCP", "sRGB", "gAMA", "cHRM", "cICP")
    val ALLOWED_CHUNKS: Set<String> = setOf("IHDR", "PLTE", "tRNS", "IDAT", "IEND") + COLOUR_CHUNKS

    /** Result of a successful [audit]: the chunk types of the file, in order (IDAT listed once). */
    class Report(val chunkTypes: List<String>)

    /** Neutral form of a colour chunk: only the iCCP profile name is rewritten; every other byte is untouched. */
    fun sanitize(c: PngChunk): PngChunk {
        if (c.type !in COLOUR_CHUNKS) throw IllegalArgumentException("chunk '${c.type}' is not allowed in an output PNG")
        if (c.type != "iCCP") return c
        val z = c.data.indexOf(0.toByte())
        if (z < 1 || z > 79 || z + 2 > c.data.size) {
            throw EngineException(ErrorCode.UNSUPPORTED, "the embedded colour profile chunk is damaged, so its colour information cannot be preserved.")
        }
        val name = ICC_PROFILE_NAME.toByteArray(Charsets.ISO_8859_1)
        if (z == name.size && String(c.data, 0, z, Charsets.ISO_8859_1) == ICC_PROFILE_NAME) return c
        return PngChunk("iCCP", name + c.data.copyOfRange(z, c.data.size))
    }

    fun sanitize(info: RasterInfo): RasterInfo =
        if (info.colorChunks.isEmpty()) info
        else RasterInfo(info.width, info.height, info.colorType, info.bitDepth, info.palette, info.transparency, info.colorChunks.map(::sanitize))

    /**
     * Reads the finished PNG chunk by chunk and throws [ErrorCode.VERIFICATION_FAILED] unless it contains only the allowed
     * chunks, in a valid order, with nothing after IEND, with colour chunks / palette / transparency identical to [expected].
     * Pixel data is not decoded here (IDAT payloads are skipped); [Stitcher.verify] compares the pixels.
     */
    fun audit(file: InputStream, expected: RasterInfo, name: String = "output"): Report {
        fun fail(msg: String): Nothing = throw EngineException(ErrorCode.VERIFICATION_FAILED, "Privacy check failed for $name: $msg Nothing was kept.")
        val want = sanitize(expected)
        val din = DataInputStream(file.buffered(1 shl 16))
        try {
            val sig = ByteArray(8); din.readFully(sig)
            if (!sig.contentEquals(byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A))) fail("not a PNG file.")
            val seen = ArrayList<String>()
            val colour = LinkedHashMap<String, ByteArray>()
            var plte: ByteArray? = null; var trns: ByteArray? = null
            var idatStarted = false; var idatEnded = false; var iend = false
            while (!iend) {
                val len = din.readInt()
                val tb = ByteArray(4); din.readFully(tb)
                val type = String(tb, Charsets.ISO_8859_1)
                if (len < 0) fail("chunk '$type' has an invalid length.")
                if (type !in ALLOWED_CHUNKS) fail("it contains a '$type' chunk, which is not allowed (only pixel and colour-management data may be written).")
                if (seen.isEmpty() && type != "IHDR") fail("the first chunk is '$type', not IHDR.")
                if (type == "IDAT") {
                    if (idatEnded) fail("IDAT chunks are not contiguous.")
                    if (!idatStarted) seen += "IDAT"
                    idatStarted = true
                    var left = len.toLong() + 4
                    while (left > 0) { val s = din.skip(left); if (s <= 0) { din.readByte(); left-- } else left -= s }
                    continue
                }
                if (idatStarted) idatEnded = true
                if (type != "IEND" && idatStarted) fail("chunk '$type' appears after the image data.")
                if (type in seen) fail("duplicate '$type' chunk.")
                val data = ByteArray(len); din.readFully(data)
                val crcRead = din.readInt()
                val crc = CRC32().also { it.update(tb); it.update(data) }.value.toInt()
                if (crc != crcRead) fail("chunk '$type' has a bad checksum.")
                seen += type
                when (type) {
                    "IHDR" -> {
                        val h = java.nio.ByteBuffer.wrap(data)
                        if (len != 13 || h.getInt(0) != want.width || h.getInt(4) != want.height || data[8].toInt() != want.bitDepth ||
                            data[9].toInt() != want.colorType || data[10].toInt() != 0 || data[11].toInt() != 0 || data[12].toInt() != 0
                        ) fail("the image header differs from the expected dimensions / bit depth / colour type.")
                    }
                    "PLTE" -> plte = data
                    "tRNS" -> trns = data
                    "IEND" -> iend = true
                    else -> colour[type] = data
                }
            }
            if (!idatStarted) fail("there is no image data.")
            if (din.read() != -1) fail("extra data follows the IEND chunk.")
            val wantColour = want.colorChunks.associate { it.type to it.data }
            if (colour.keys != wantColour.keys) fail("colour-management chunks ${colour.keys} differ from the source's ${wantColour.keys}.")
            for ((t, d) in wantColour) if (!colour.getValue(t).contentEquals(d)) fail("the '$t' chunk differs from the source's colour profile.")
            if (!(plte ?: ByteArray(0)).contentEquals(want.palette ?: ByteArray(0))) fail("the palette differs from the source.")
            if (!(trns ?: ByteArray(0)).contentEquals(want.transparency ?: ByteArray(0))) fail("the transparency chunk differs from the source.")
            return Report(seen)
        } catch (e: EOFException) {
            fail("the file ends unexpectedly.")
        } catch (e: IOException) {
            fail("it could not be read back (${e.message}).")
        } finally {
            try { din.close() } catch (_: IOException) {}
        }
    }
}
