package com.webtoonstitch.engine

const val MAX_STITCH_HEIGHT = 12_000

data class Candidate(
    val id: String,
    val name: String,
    val width: Int,
    val height: Int,
    /** [RasterInfo.formatKey] of the image. */
    val formatKey: String
)

enum class RejectReason { HEIGHT_LIMIT, WIDTH_MISMATCH, FORMAT_MISMATCH, DUPLICATE, INVALID }

sealed class AddResult {
    object Accepted : AddResult()
    data class Rejected(val reason: RejectReason, val message: String) : AddResult()
}

/**
 * Pure selection logic used by the picker. Items are always kept in natural filename order
 * (never selection order) and the cumulative height can never exceed [maxHeight].
 */
class StitchSelection(val maxHeight: Int = MAX_STITCH_HEIGHT) {
    private val list = ArrayList<Candidate>()

    val items: List<Candidate> get() = list.toList()
    val count: Int get() = list.size
    val totalHeight: Int get() = list.sumOf { it.height }
    val remainingHeight: Int get() = maxHeight - totalHeight
    val width: Int? get() = list.firstOrNull()?.width
    fun contains(id: String) = list.any { it.id == id }

    fun summary(): String =
        "Selected height: ${fmt(totalHeight)} / ${fmt(maxHeight)} px\nRemaining: ${fmt(remainingHeight)} px"

    fun tryAdd(c: Candidate): AddResult {
        if (c.width <= 0 || c.height <= 0) {
            return reject(RejectReason.INVALID, "${c.name}: could not determine the image size.")
        }
        if (contains(c.id)) return reject(RejectReason.DUPLICATE, "${c.name} is already selected.")
        val first = list.firstOrNull()
        if (first != null && first.width != c.width) {
            return reject(
                RejectReason.WIDTH_MISMATCH,
                "Image width mismatch. All selected images must have the same width.\n" +
                    "${first.name}: ${first.width} px wide\n${c.name}: ${c.width} px wide"
            )
        }
        if (first != null && first.formatKey != c.formatKey) {
            return reject(
                RejectReason.FORMAT_MISMATCH,
                "Pixel format mismatch. ${first.name} and ${c.name} differ in colour type, bit depth, palette or colour profile, " +
                    "so they cannot be combined without changing how their pixels are interpreted."
            )
        }
        if (c.height > maxHeight || c.height > remainingHeight) {
            return reject(
                RejectReason.HEIGHT_LIMIT,
                "Selection limit exceeded. Maximum combined image height is ${fmt(maxHeight)} px.\n" +
                    "${c.name} is ${fmt(c.height)} px tall but only ${fmt(remainingHeight)} px remain.\n" + summary()
            )
        }
        list.add(c)
        list.sortWith { x, y -> NaturalFilenameComparator.compare(x.name, y.name) }
        return AddResult.Accepted
    }

    fun remove(id: String): Boolean = list.removeAll { it.id == id }
    fun clear() = list.clear()

    private fun reject(r: RejectReason, m: String) = AddResult.Rejected(r, m)

    companion object {
        fun fmt(n: Int): String = "%,d".format(java.util.Locale.US, n)
    }
}
