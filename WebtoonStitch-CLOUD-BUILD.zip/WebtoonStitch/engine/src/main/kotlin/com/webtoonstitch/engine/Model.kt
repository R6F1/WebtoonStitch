package com.webtoonstitch.engine

import java.io.Closeable

/** Machine-readable failure category. The message of [EngineException] is always user-presentable. */
enum class ErrorCode {
    UNREADABLE, UNSUPPORTED, FORMAT_MISMATCH, WIDTH_MISMATCH, HEIGHT_LIMIT,
    OUT_OF_MEMORY, VERIFICATION_FAILED, MULTI_PAGE, NO_INPUT, IO_WRITE
}

class EngineException(val code: ErrorCode, message: String, cause: Throwable? = null) :
    Exception(message, cause)

/** Cooperative cancellation. Throw (e.g. [java.util.concurrent.CancellationException]) from [check] to abort. */
fun interface CancelCheck {
    fun check()

    companion object {
        val NONE = CancelCheck { }
    }
}

/** A raw PNG chunk (type + data, without length/CRC). */
class PngChunk(val type: String, val data: ByteArray) {
    override fun equals(other: Any?) =
        other is PngChunk && other.type == type && other.data.contentEquals(data)

    override fun hashCode() = type.hashCode() * 31 + data.contentHashCode()
}

/**
 * Pixel layout of a raster, expressed in PNG terms. All rows handed around the engine use the
 * PNG byte layout: samples are packed MSB-first for depths < 8, and 16-bit samples are big-endian.
 */
class RasterInfo(
    val width: Int,
    val height: Int,
    val colorType: Int,
    val bitDepth: Int,
    /** PLTE chunk payload (RGB triplets) for colorType 3. */
    val palette: ByteArray? = null,
    /** tRNS chunk payload, if any. */
    val transparency: ByteArray? = null,
    /** iCCP / sRGB / gAMA / cHRM / cICP chunks that define the colour space. */
    val colorChunks: List<PngChunk> = emptyList()
) {
    val channels: Int
        get() = when (colorType) {
            0, 3 -> 1
            4 -> 2
            2 -> 3
            6 -> 4
            else -> throw IllegalStateException("bad colour type $colorType")
        }
    val bitsPerPixel: Int get() = channels * bitDepth
    val filterBytesPerPixel: Int get() = maxOf(1, bitsPerPixel / 8)
    val rowBytes: Int get() = ((width.toLong() * bitsPerPixel + 7) / 8).toInt()
    val hasAlpha: Boolean get() = colorType == 4 || colorType == 6 || transparency != null

    /**
     * Cheap key used by pickers: two images may only be stitched if their keys are equal.
     * Covers colour type, bit depth and (via a checksum) the palette, transparency key and colour-space chunks.
     */
    val formatKey: String
        get() {
            val base = "$colorType/$bitDepth"
            if (palette == null && transparency == null && colorChunks.isEmpty()) return base
            val crc = java.util.zip.CRC32()
            palette?.let { crc.update(1); crc.update(it) }
            transparency?.let { crc.update(2); crc.update(it) }
            for (c in colorChunks) { crc.update(3); crc.update(c.type.toByteArray(Charsets.ISO_8859_1)); crc.update(c.data) }
            return base + "/" + java.lang.Long.toHexString(crc.value)
        }

    val formatLabel: String
        get() = when (colorType) {
            0 -> "Grayscale"; 2 -> "RGB"; 3 -> "Indexed"; 4 -> "Grayscale+alpha"; else -> "RGBA"
        } + " $bitDepth-bit"

    /** Everything that must be identical for rows to be copied between two rasters unchanged. */
    fun sameFormatAs(o: RasterInfo): Boolean =
        colorType == o.colorType && bitDepth == o.bitDepth &&
            (palette ?: ByteArray(0)).contentEquals(o.palette ?: ByteArray(0)) &&
            (transparency ?: ByteArray(0)).contentEquals(o.transparency ?: ByteArray(0)) &&
            colorChunks == o.colorChunks

    companion object {
        fun validCombination(colorType: Int, depth: Int) = when (colorType) {
            0 -> depth in intArrayOf(1, 2, 4, 8, 16)
            2, 4, 6 -> depth == 8 || depth == 16
            3 -> depth in intArrayOf(1, 2, 4, 8)
            else -> false
        }
    }
}

/**
 * Sequential top-to-bottom source of pixel rows in PNG byte layout.
 * [readRow] must be called exactly `info.height` times; [dst] must hold at least `info.rowBytes` bytes.
 */
interface RowSource : Closeable {
    val info: RasterInfo
    fun readRow(dst: ByteArray)
}
