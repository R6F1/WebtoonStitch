package com.webtoonstitch.engine

import java.io.IOException
import java.io.InputStream

/** Reads [count] bytes starting at [start] from a [RandomAccess] file, with an internal buffer. */
internal class BoundedStream(
    private val ra: RandomAccess, start: Long, private val count: Long
) : InputStream() {
    private var pos = start
    private var left = count
    private val buf = ByteArray(1 shl 15)
    private var bp = 0
    private var bl = 0

    private fun fill(): Boolean {
        if (left <= 0) return false
        val n = ra.readAt(pos, buf, 0, minOf(buf.size.toLong(), left).toInt())
        if (n <= 0) throw IOException("unexpected end of TIFF file")
        pos += n; left -= n; bp = 0; bl = n
        return true
    }

    override fun read(): Int {
        if (bp >= bl && !fill()) return -1
        return buf[bp++].toInt() and 0xFF
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (len == 0) return 0
        if (bp >= bl && !fill()) return -1
        val n = minOf(len, bl - bp)
        System.arraycopy(buf, bp, b, off, n)
        bp += n
        return n
    }
}

/** Streaming decoder for TIFF LZW (MSB-first codes, "early change", as written by libtiff/Photoshop). */
internal class TiffLzwInputStream(private val src: InputStream) : InputStream() {
    private val prefix = IntArray(4096)
    private val suffix = ByteArray(4096)
    private val length = IntArray(4096)
    private val out = ByteArray(4098)
    private var outPos = 0
    private var outLen = 0
    private var nextCode = 258
    private var codeLen = 9
    private var prev = -1
    private var bitBuf = 0
    private var bitCnt = 0
    private var eof = false

    init {
        for (i in 0..255) { suffix[i] = i.toByte(); length[i] = 1; prefix[i] = -1 }
    }

    private fun readCode(): Int {
        while (bitCnt < codeLen) {
            val b = src.read()
            if (b < 0) return -1
            bitBuf = (bitBuf shl 8) or b
            bitCnt += 8
        }
        val code = (bitBuf ushr (bitCnt - codeLen)) and ((1 shl codeLen) - 1)
        bitCnt -= codeLen
        bitBuf = bitBuf and ((1 shl bitCnt) - 1)
        return code
    }

    private fun emit(code: Int) {
        val len = length[code]
        var c = code
        for (i in len - 1 downTo 0) { out[i] = suffix[c]; c = prefix[c] }
        outPos = 0; outLen = len
    }

    private fun addEntry(p: Int, c: Byte) {
        if (nextCode >= 4096) return
        prefix[nextCode] = p; suffix[nextCode] = c; length[nextCode] = length[p] + 1
        nextCode++
        if (nextCode == 511) codeLen = 10 else if (nextCode == 1023) codeLen = 11 else if (nextCode == 2047) codeLen = 12
    }

    private fun fill(): Boolean {
        if (eof) return false
        while (true) {
            val code = readCode()
            if (code < 0 || code == 257) { eof = true; return false }
            if (code == 256) { nextCode = 258; codeLen = 9; prev = -1; continue }
            if (prev == -1) {
                if (code >= 256) throw IOException("corrupt LZW data")
                emit(code); prev = code; return true
            }
            if (code < nextCode) {
                emit(code)
                addEntry(prev, out[0])
            } else if (code == nextCode) {
                emit(prev)
                val first = out[0]
                out[outLen++] = first
                addEntry(prev, first)
            } else throw IOException("corrupt LZW data")
            prev = code
            return true
        }
    }

    override fun read(): Int {
        if (outPos >= outLen && !fill()) return -1
        return out[outPos++].toInt() and 0xFF
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (len == 0) return 0
        if (outPos >= outLen && !fill()) return -1
        val n = minOf(len, outLen - outPos)
        System.arraycopy(out, outPos, b, off, n)
        outPos += n
        return n
    }
}

internal class PackBitsInputStream(private val src: InputStream) : InputStream() {
    private var repeatLeft = 0
    private var repeatByte = 0
    private var literalLeft = 0

    override fun read(): Int {
        if (repeatLeft > 0) { repeatLeft--; return repeatByte }
        while (literalLeft == 0) {
            val n = src.read()
            if (n < 0) return -1
            val s = n.toByte().toInt()
            if (s >= 0) literalLeft = s + 1
            else if (s != -128) {
                val rb = src.read()
                if (rb < 0) return -1
                repeatByte = rb
                repeatLeft = -s   // total run length is 1 - s; one is returned now
                return rb
            }
        }
        literalLeft--
        return src.read()
    }
}
