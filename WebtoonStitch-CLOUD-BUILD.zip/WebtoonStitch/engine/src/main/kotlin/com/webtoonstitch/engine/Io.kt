package com.webtoonstitch.engine

import java.io.Closeable
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.io.RandomAccessFile

/** Random-access read view of an input file (needed by TIFF, whose strips can be anywhere in the file). */
interface RandomAccess : Closeable {
    val length: Long
    /** Reads up to [len] bytes at [position]; returns -1 at end of file. */
    fun readAt(position: Long, buf: ByteArray, off: Int, len: Int): Int
}

/**
 * One input image. The Android layer implements this over content URIs
 * (ContentResolver.openInputStream / openFileDescriptor); the JVM implementation below uses files.
 */
interface ImageInput {
    val name: String
    fun openStream(): InputStream
    fun openRandomAccess(): RandomAccess
}

class FileImageInput(private val file: File, override val name: String = file.name) : ImageInput {
    override fun openStream(): InputStream = FileInputStream(file).buffered(1 shl 16)
    override fun openRandomAccess(): RandomAccess {
        val raf = RandomAccessFile(file, "r")
        return object : RandomAccess {
            override val length: Long get() = raf.length()
            override fun readAt(position: Long, buf: ByteArray, off: Int, len: Int): Int {
                raf.seek(position)
                return raf.read(buf, off, len)
            }
            override fun close() = raf.close()
        }
    }
}

internal fun InputStream.readFullyOrFalse(buf: ByteArray, off: Int, len: Int): Boolean {
    var n = 0
    while (n < len) {
        val r = read(buf, off + n, len - n)
        if (r < 0) return false
        n += r
    }
    return true
}

internal fun unreadable(name: String?, detail: String, cause: Throwable? = null) =
    EngineException(ErrorCode.UNREADABLE, (name?.let { "$it: " } ?: "") + detail, cause)

internal fun unsupported(name: String?, detail: String) =
    EngineException(ErrorCode.UNSUPPORTED, (name?.let { "$it: " } ?: "") + detail)
