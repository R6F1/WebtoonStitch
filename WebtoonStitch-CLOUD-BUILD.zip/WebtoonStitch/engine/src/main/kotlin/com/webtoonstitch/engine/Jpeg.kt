package com.webtoonstitch.engine

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.util.zip.Deflater

/**
 * Streaming decoder for baseline / extended-sequential, 8-bit, Huffman-coded JPEG (the kind that is stored in
 * almost every ".jpg"). It produces 8-bit RGB (or 8-bit grayscale) rows in PNG byte layout.
 *
 * WHAT "DECODED PIXEL VALUES" MEANS HERE
 * JPEG does not define one unique decoded result: different decoders may differ by a few levels. This decoder
 * deliberately reproduces the arithmetic of the Independent JPEG Group reference decoder (libjpeg 6b, the default
 * settings used by the JDK's ImageIO and, bit-for-bit, by libjpeg-turbo):
 *   - integer "islow" inverse DCT (jidctint.c),
 *   - "fancy" triangle chroma upsampling (jdsample.c) for 4:2:2 and 4:2:0,
 *   - fixed-point YCbCr -> RGB conversion (jdcolor.c).
 * The tests compare every decoded pixel of the sample files with ImageIO and with Pillow/libjpeg-turbo.
 *
 * Nothing is ever approximated or guessed: anything this decoder cannot reproduce faithfully is REJECTED with a
 * clear message (progressive, arithmetic-coded, 12-bit, CMYK, RGB-stored, unusual subsampling, EXIF rotation,
 * truncated or corrupt data). Truncated files are never padded with grey.
 *
 * Memory: three MCU-row sample buffers per component (a few tens of KB for a 1000 px wide image). Never the full image.
 * The embedded ICC profile (APP2), if any, is carried over into the PNG as an iCCP chunk.
 */
internal class JpegRowSource private constructor(
    private val name: String,
    private val inp: ByteReader,
    override val info: RasterInfo,
    private val comps: List<Comp>,
    private val hMax: Int,
    private val vMax: Int,
    private val restartInterval: Int
) : RowSource {

    class Comp(val id: Int, val h: Int, val v: Int, val tq: Int) {
        var td = 0
        var ta = 0
        var pred = 0
        lateinit var planes: Array<ByteArray>     // 3 MCU-row buffers (ring)
        var stride = 0
        var rowsPerMcu = 0
        var dw = 0                                 // downsampled width  (real columns)
        var dh = 0                                 // downsampled height (real rows)
    }

    private val width = info.width
    private val height = info.height
    private val gray = comps.size == 1
    private val mcuW = 8 * hMax
    private val mcuH = 8 * vMax
    private val mcusX = (width + mcuW - 1) / mcuW
    private val mcusY = (height + mcuH - 1) / mcuH
    private val coef = IntArray(64)
    private val ws = IntArray(64)
    private val lines = Array(comps.size) { ByteArray(0) }
    private var colSum = IntArray(0)
    private var decodedMcuRows = 0
    private var nextRow = 0
    private var mcuCounter = 0
    private var nextRst = 0

    // Tables are filled by [open] before construction completes (see init order in companion).
    lateinit var quant: Array<IntArray?>             // [4], natural (de-zigzagged) order not needed: kept in zigzag order
    lateinit var dcLut: Array<ShortArray?>
    lateinit var acLut: Array<ShortArray?>

    init {
        for ((i, c) in comps.withIndex()) {
            c.stride = mcusX * c.h * 8
            c.rowsPerMcu = c.v * 8
            c.planes = Array(3) { ByteArray(c.stride * c.rowsPerMcu) }
            c.dw = (width * c.h + hMax - 1) / hMax
            c.dh = (height * c.v + vMax - 1) / vMax
            lines[i] = ByteArray(maxOf(width, 2 * c.dw) + 2)
        }
        colSum = IntArray(comps.maxOf { it.dw } + 2)
    }

    // ------------------------------------------------------------------------------------------ row output

    override fun readRow(dst: ByteArray) {
        check(nextRow < height) { "all rows already read" }
        val m = nextRow / mcuH
        try {
            // Fancy upsampling needs the first chroma row of the NEXT MCU row, so decoding runs one MCU row ahead.
            val need = minOf(m + 1, mcusY - 1)
            while (decodedMcuRows <= need) decodeMcuRow(decodedMcuRows++)
        } catch (e: EngineException) {
            throw e
        } catch (e: IOException) {
            throw unreadable(name, "JPEG data could not be read: ${e.message}", e)
        }
        val y = nextRow
        for ((i, c) in comps.withIndex()) buildLine(c, lines[i], y)
        if (gray) {
            System.arraycopy(lines[0], 0, dst, 0, width)
        } else {
            val ly = lines[0]; val lcb = lines[1]; val lcr = lines[2]
            var o = 0
            for (x in 0 until width) {
                val yy = ly[x].toInt() and 255
                val cb = lcb[x].toInt() and 255
                val cr = lcr[x].toInt() and 255
                val r = yy + CR_R[cr]
                val g = yy + ((CB_G[cb] + CR_G[cr]) shr 16)
                val b = yy + CB_B[cb]
                dst[o++] = (if (r < 0) 0 else if (r > 255) 255 else r).toByte()
                dst[o++] = (if (g < 0) 0 else if (g > 255) 255 else g).toByte()
                dst[o++] = (if (b < 0) 0 else if (b > 255) 255 else b).toByte()
            }
        }
        nextRow++
    }

    override fun close() { inp.close() }

    // Component row [r] must belong to MCU row m-1, m or m+1 (the ring holds exactly those three).
    private fun rowArray(c: Comp, r: Int): ByteArray = c.planes[(r / c.rowsPerMcu) % 3]
    private fun rowOffset(c: Comp, r: Int): Int = (r % c.rowsPerMcu) * c.stride

    /** Builds one full-resolution row [y] (width samples) of component [c] in [out]. */
    private fun buildLine(c: Comp, out: ByteArray, y: Int) {
        val hr = hMax / c.h
        val vr = vMax / c.v
        val r = if (vr == 2) y / 2 else y
        val a = rowArray(c, r); val ao = rowOffset(c, r)
        if (hr == 1 && vr == 1) {
            System.arraycopy(a, ao, out, 0, width)
            return
        }
        val dw = c.dw
        if (hr == 2 && vr == 1) {
            if (dw > 2) h2v1Fancy(a, ao, out, dw) else for (i in 0 until dw) { out[2 * i] = a[ao + i]; out[2 * i + 1] = a[ao + i] }
            return
        }
        // h2v2
        if (dw > 2) {
            val nr = if (y % 2 == 0) maxOf(r - 1, 0) else minOf(r + 1, c.dh - 1)
            val b = rowArray(c, nr); val bo = rowOffset(c, nr)
            h2v2Fancy(a, ao, b, bo, out, dw)
        } else {
            for (i in 0 until dw) { out[2 * i] = a[ao + i]; out[2 * i + 1] = a[ao + i] }
        }
    }

    // jdsample.c h2v1_fancy_upsample
    private fun h2v1Fancy(src: ByteArray, o: Int, out: ByteArray, dw: Int) {
        var p = 0
        var v = src[o].toInt() and 255
        out[p++] = v.toByte()
        out[p++] = ((v * 3 + (src[o + 1].toInt() and 255) + 2) shr 2).toByte()
        for (i in 1 until dw - 1) {
            v = (src[o + i].toInt() and 255) * 3
            out[p++] = ((v + (src[o + i - 1].toInt() and 255) + 1) shr 2).toByte()
            out[p++] = ((v + (src[o + i + 1].toInt() and 255) + 2) shr 2).toByte()
        }
        v = src[o + dw - 1].toInt() and 255
        out[p++] = ((v * 3 + (src[o + dw - 2].toInt() and 255) + 1) shr 2).toByte()
        out[p] = v.toByte()
    }

    // jdsample.c h2v2_fancy_upsample (one output row: [a] is the nearer input row, [b] the farther one)
    private fun h2v2Fancy(a: ByteArray, ao: Int, b: ByteArray, bo: Int, out: ByteArray, dw: Int) {
        val cs = colSum
        for (i in 0 until dw) cs[i] = (a[ao + i].toInt() and 255) * 3 + (b[bo + i].toInt() and 255)
        var p = 0
        out[p++] = ((cs[0] * 4 + 8) shr 4).toByte()
        out[p++] = ((cs[0] * 3 + cs[1] + 7) shr 4).toByte()
        for (i in 1 until dw - 1) {
            out[p++] = ((cs[i] * 3 + cs[i - 1] + 8) shr 4).toByte()
            out[p++] = ((cs[i] * 3 + cs[i + 1] + 7) shr 4).toByte()
        }
        out[p++] = ((cs[dw - 1] * 3 + cs[dw - 2] + 8) shr 4).toByte()
        out[p] = ((cs[dw - 1] * 4 + 7) shr 4).toByte()
    }

    // ------------------------------------------------------------------------------------------ entropy decoding

    private fun decodeMcuRow(m: Int) {
        for (mx in 0 until mcusX) {
            if (restartInterval > 0 && mcuCounter > 0 && mcuCounter % restartInterval == 0) {
                inp.syncRestart(nextRst, name)
                nextRst = (nextRst + 1) and 7
                for (c in comps) c.pred = 0
            }
            for (c in comps) {
                val plane = c.planes[m % 3]
                for (by in 0 until c.v) for (bx in 0 until c.h) {
                    decodeBlock(c)
                    idct(plane, (by * 8) * c.stride + (mx * c.h + bx) * 8, c.stride)
                }
            }
            mcuCounter++
        }
    }

    private fun decodeBlock(c: Comp) {
        val q = quant[c.tq]!!
        java.util.Arrays.fill(coef, 0)
        val dc = dcLut[c.td] ?: throw unreadable(name, "JPEG is corrupt: a Huffman table is missing.")
        val ac = acLut[c.ta] ?: throw unreadable(name, "JPEG is corrupt: a Huffman table is missing.")
        val t = inp.decode(dc, name)
        if (t > 11) throw unreadable(name, "JPEG is corrupt (invalid DC size).")
        val diff = if (t == 0) 0 else extend(inp.bits(t, name), t)
        c.pred += diff
        coef[0] = c.pred * q[0]
        var k = 1
        while (k < 64) {
            val rs = inp.decode(ac, name)
            val r = rs shr 4
            val s = rs and 15
            if (s == 0) {
                if (r == 15) { k += 16; continue }
                break
            }
            k += r
            if (k > 63) throw unreadable(name, "JPEG is corrupt (coefficient index out of range).")
            if (s > 10) throw unreadable(name, "JPEG is corrupt (invalid AC size).")
            coef[ZIGZAG[k]] = extend(inp.bits(s, name), s) * q[k]
            k++
        }
    }

    private fun extend(v: Int, t: Int) = if (v < (1 shl (t - 1))) v - (1 shl t) + 1 else v

    // jidctint.c jpeg_idct_islow (CONST_BITS = 13, PASS1_BITS = 2), range-limited with +128 level shift.
    private fun idct(out: ByteArray, base: Int, stride: Int) {
        val w = ws
        for (col in 0 until 8) {
            val i0 = coef[col]; val i1 = coef[8 + col]; val i2 = coef[16 + col]; val i3 = coef[24 + col]
            val i4 = coef[32 + col]; val i5 = coef[40 + col]; val i6 = coef[48 + col]; val i7 = coef[56 + col]
            var z2 = i2; var z3 = i6
            var z1 = (z2 + z3) * FIX_0_541196100
            var tmp2 = z1 + z3 * (-FIX_1_847759065)
            var tmp3 = z1 + z2 * FIX_0_765366865
            z2 = i0; z3 = i4
            var tmp0 = (z2 + z3) shl 13
            var tmp1 = (z2 - z3) shl 13
            val tmp10 = tmp0 + tmp3; val tmp13 = tmp0 - tmp3; val tmp11 = tmp1 + tmp2; val tmp12 = tmp1 - tmp2
            tmp0 = i7; tmp1 = i5; tmp2 = i3; tmp3 = i1
            z1 = tmp0 + tmp3; z2 = tmp1 + tmp2; z3 = tmp0 + tmp2
            var z4 = tmp1 + tmp3
            val z5 = (z3 + z4) * FIX_1_175875602
            tmp0 *= FIX_0_298631336; tmp1 *= FIX_2_053119869; tmp2 *= FIX_3_072711026; tmp3 *= FIX_1_501321110
            z1 *= -FIX_0_899976223; z2 *= -FIX_2_562915447; z3 *= -FIX_1_961570560; z4 *= -FIX_0_390180644
            z3 += z5; z4 += z5
            tmp0 += z1 + z3; tmp1 += z2 + z4; tmp2 += z2 + z3; tmp3 += z1 + z4
            w[col] = (tmp10 + tmp3 + R1) shr 11
            w[56 + col] = (tmp10 - tmp3 + R1) shr 11
            w[8 + col] = (tmp11 + tmp2 + R1) shr 11
            w[48 + col] = (tmp11 - tmp2 + R1) shr 11
            w[16 + col] = (tmp12 + tmp1 + R1) shr 11
            w[40 + col] = (tmp12 - tmp1 + R1) shr 11
            w[24 + col] = (tmp13 + tmp0 + R1) shr 11
            w[32 + col] = (tmp13 - tmp0 + R1) shr 11
        }
        for (row in 0 until 8) {
            val o = row * 8
            val i0 = w[o]; val i1 = w[o + 1]; val i2 = w[o + 2]; val i3 = w[o + 3]
            val i4 = w[o + 4]; val i5 = w[o + 5]; val i6 = w[o + 6]; val i7 = w[o + 7]
            var z2 = i2; var z3 = i6
            var z1 = (z2 + z3) * FIX_0_541196100
            var tmp2 = z1 + z3 * (-FIX_1_847759065)
            var tmp3 = z1 + z2 * FIX_0_765366865
            var tmp0 = (i0 + i4) shl 13
            var tmp1 = (i0 - i4) shl 13
            val tmp10 = tmp0 + tmp3; val tmp13 = tmp0 - tmp3; val tmp11 = tmp1 + tmp2; val tmp12 = tmp1 - tmp2
            tmp0 = i7; tmp1 = i5; tmp2 = i3; tmp3 = i1
            z1 = tmp0 + tmp3; z2 = tmp1 + tmp2; z3 = tmp0 + tmp2
            var z4 = tmp1 + tmp3
            val z5 = (z3 + z4) * FIX_1_175875602
            tmp0 *= FIX_0_298631336; tmp1 *= FIX_2_053119869; tmp2 *= FIX_3_072711026; tmp3 *= FIX_1_501321110
            z1 *= -FIX_0_899976223; z2 *= -FIX_2_562915447; z3 *= -FIX_1_961570560; z4 *= -FIX_0_390180644
            z3 += z5; z4 += z5
            tmp0 += z1 + z3; tmp1 += z2 + z4; tmp2 += z2 + z3; tmp3 += z1 + z4
            val p = base + row * stride
            out[p] = lim((tmp10 + tmp3 + R2) shr 18)
            out[p + 7] = lim((tmp10 - tmp3 + R2) shr 18)
            out[p + 1] = lim((tmp11 + tmp2 + R2) shr 18)
            out[p + 6] = lim((tmp11 - tmp2 + R2) shr 18)
            out[p + 2] = lim((tmp12 + tmp1 + R2) shr 18)
            out[p + 5] = lim((tmp12 - tmp1 + R2) shr 18)
            out[p + 3] = lim((tmp13 + tmp0 + R2) shr 18)
            out[p + 4] = lim((tmp13 - tmp0 + R2) shr 18)
        }
    }

    private fun lim(v: Int): Byte { val x = v + 128; return (if (x < 0) 0 else if (x > 255) 255 else x).toByte() }

    // ------------------------------------------------------------------------------------------ byte / bit reader

    class ByteReader(private val s: InputStream) {
        private val buf = ByteArray(1 shl 16)
        private var pos = 0
        private var lim = 0
        // entropy-coded bit buffer: [cnt] valid bits in the low end of [acc]; the newest [pad] of them are zero padding
        private var acc = 0L
        private var cnt = 0
        private var pad = 0
        private var markerHit = false
        private var markerCode = 0

        fun read(): Int {
            if (pos >= lim) {
                lim = s.read(buf, 0, buf.size); pos = 0
                if (lim <= 0) { lim = 0; return -1 }
            }
            return buf[pos++].toInt() and 255
        }

        fun readFully(dst: ByteArray, n: Int): Boolean {
            for (i in 0 until n) { val b = read(); if (b < 0) return false; dst[i] = b.toByte() }
            return true
        }

        fun close() = s.close()

        fun resetBits() { acc = 0; cnt = 0; pad = 0; markerHit = false }

        private fun fill() {
            while (cnt <= 48) {
                if (markerHit) { acc = acc shl 8; cnt += 8; pad += 8; continue }
                var b = read()
                if (b < 0) { markerHit = true; markerCode = -1; continue }   // end of file: treated like a marker => padding
                if (b == 0xFF) {
                    var n = read()
                    while (n == 0xFF) n = read()
                    if (n == 0) { /* stuffed 0xFF data byte */ }
                    else { markerHit = true; markerCode = n; continue }
                }
                acc = (acc shl 8) or b.toLong(); cnt += 8
            }
        }

        private fun consume(n: Int, name: String) {
            cnt -= n
            if (cnt < pad) throw unreadable(name, "JPEG data is truncated or corrupt (image data ended early).")
        }

        fun bits(n: Int, name: String): Int {
            if (cnt < n) fill()
            val v = ((acc ushr (cnt - n)) and ((1L shl n) - 1)).toInt()
            consume(n, name)
            return v
        }

        fun decode(lut: ShortArray, name: String): Int {
            if (cnt < 16) fill()
            val e = lut[((acc ushr (cnt - 16)) and 0xFFFF).toInt()].toInt()
            if (e == 0) throw unreadable(name, "JPEG data is corrupt (invalid Huffman code).")
            consume(e shr 8, name)
            return e and 255
        }

        /** Consumes the byte padding and the RSTn marker that must follow a restart interval. */
        fun syncRestart(expected: Int, name: String) {
            if (cnt - pad >= 8) throw unreadable(name, "JPEG data is corrupt (unexpected data before a restart marker).")
            acc = 0; cnt = 0; pad = 0
            if (!markerHit) {
                var b = read()
                if (b != 0xFF) throw unreadable(name, "JPEG data is corrupt (restart marker expected).")
                while (b == 0xFF) b = read()
                markerCode = b
            }
            markerHit = false
            if (markerCode != 0xD0 + expected) {
                throw unreadable(name, "JPEG data is corrupt or truncated (restart marker $expected expected).")
            }
        }
    }

    companion object {
        private const val FIX_0_298631336 = 2446
        private const val FIX_0_390180644 = 3196
        private const val FIX_0_541196100 = 4433
        private const val FIX_0_765366865 = 6270
        private const val FIX_0_899976223 = 7373
        private const val FIX_1_175875602 = 9633
        private const val FIX_1_501321110 = 12299
        private const val FIX_1_847759065 = 15137
        private const val FIX_1_961570560 = 16069
        private const val FIX_2_053119869 = 16819
        private const val FIX_2_562915447 = 20995
        private const val FIX_3_072711026 = 25172
        private const val R1 = 1 shl 10          // DESCALE rounding, CONST_BITS - PASS1_BITS = 11
        private const val R2 = 1 shl 17          // DESCALE rounding, CONST_BITS + PASS1_BITS + 3 = 18

        private val ZIGZAG = intArrayOf(
            0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5, 12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28,
            35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51, 58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63
        )

        // jdcolor.c build_ycc_rgb_table (SCALEBITS = 16)
        private fun fix(x: Double) = (x * 65536 + 0.5).toInt()
        private val CR_R = IntArray(256) { (fix(1.40200) * (it - 128) + 32768) shr 16 }
        private val CB_B = IntArray(256) { (fix(1.77200) * (it - 128) + 32768) shr 16 }
        private val CR_G = IntArray(256) { -fix(0.71414) * (it - 128) }
        private val CB_G = IntArray(256) { -fix(0.34414) * (it - 128) + 32768 }

        fun open(stream: InputStream, name: String): RowSource {
            val inp = ByteReader(stream)
            try {
                return parse(stream, inp, name)
            } catch (e: Throwable) {
                try { inp.close() } catch (_: IOException) {}
                if (e is IOException) throw unreadable(name, "JPEG could not be read: ${e.message}", e)
                throw e
            }
        }

        private fun u16(inp: ByteReader, name: String): Int {
            val a = inp.read(); val b = inp.read()
            if (a < 0 || b < 0) throw unreadable(name, "JPEG is truncated (ended inside the headers).")
            return (a shl 8) or b
        }

        private fun nextMarker(inp: ByteReader, name: String): Int {
            var b = inp.read()
            while (b != 0xFF) { if (b < 0) throw unreadable(name, "JPEG is truncated (no image data found)."); b = inp.read() }
            while (b == 0xFF) b = inp.read()
            if (b < 0) throw unreadable(name, "JPEG is truncated (no image data found).")
            return b
        }

        private fun parse(stream: InputStream, inp: ByteReader, name: String): RowSource {
            if (inp.read() != 0xFF || inp.read() != 0xD8) throw unreadable(name, "not a JPEG (missing SOI marker).")
            val quant = arrayOfNulls<IntArray>(4)
            val dcT = arrayOfNulls<ShortArray>(4)
            val acT = arrayOfNulls<ShortArray>(4)
            var comps: List<Comp>? = null
            var w = 0; var h = 0
            var ri = 0
            var adobeTransform = -1
            var orientation = 1
            val iccParts = HashMap<Int, ByteArray>()
            var iccCount = -1
            var sawSof = false
            while (true) {
                val m = nextMarker(inp, name)
                when (m) {
                    0xD8, 0x01, in 0xD0..0xD7 -> continue
                    0xD9 -> throw unreadable(name, "JPEG contains no image data.")
                }
                val len = u16(inp, name) - 2
                if (len < 0) throw unreadable(name, "JPEG is corrupt (bad segment length).")
                val body = ByteArray(len)
                if (!inp.readFully(body, len)) throw unreadable(name, "JPEG is truncated (ended inside the headers).")
                when (m) {
                    0xDB -> { // DQT
                        var p = 0
                        while (p < len) {
                            val pq = body[p].toInt() and 255 shr 4; val tq = body[p].toInt() and 15; p++
                            if (tq > 3 || pq > 1) throw unreadable(name, "JPEG is corrupt (bad quantisation table).")
                            val t = IntArray(64)
                            for (i in 0 until 64) {
                                if (pq == 0) { if (p >= len) throw unreadable(name, "JPEG is corrupt (short DQT)."); t[i] = body[p++].toInt() and 255 }
                                else { if (p + 1 >= len) throw unreadable(name, "JPEG is corrupt (short DQT)."); t[i] = ((body[p].toInt() and 255) shl 8) or (body[p + 1].toInt() and 255); p += 2 }
                            }
                            quant[tq] = t
                        }
                    }
                    0xC4 -> { // DHT
                        var p = 0
                        while (p < len) {
                            if (p + 17 > len) throw unreadable(name, "JPEG is corrupt (short DHT).")
                            val tc = (body[p].toInt() and 255) shr 4; val th = body[p].toInt() and 15; p++
                            if (th > 3 || tc > 1) throw unreadable(name, "JPEG is corrupt (bad Huffman table id).")
                            val counts = IntArray(17); var total = 0
                            for (i in 1..16) { counts[i] = body[p++].toInt() and 255; total += counts[i] }
                            if (total > 256 || p + total > len) throw unreadable(name, "JPEG is corrupt (bad DHT).")
                            val symbols = IntArray(total) { body[p + it].toInt() and 255 }
                            p += total
                            val lut = buildLut(counts, symbols, name)
                            if (tc == 0) dcT[th] = lut else acT[th] = lut
                        }
                    }
                    0xDD -> { if (len < 2) throw unreadable(name, "JPEG is corrupt (bad DRI)."); ri = ((body[0].toInt() and 255) shl 8) or (body[1].toInt() and 255) }
                    0xE1 -> if (len >= 14 && String(body, 0, 4, Charsets.ISO_8859_1) == "Exif" && body[4].toInt() == 0) orientation = exifOrientation(body, 6, len)
                    0xE2 -> if (len >= 14 && String(body, 0, 11, Charsets.ISO_8859_1) == "ICC_PROFILE" && body[11].toInt() == 0) {
                        val seq = body[12].toInt() and 255; val cnt = body[13].toInt() and 255
                        if (iccCount >= 0 && iccCount != cnt) throw unsupported(name, "the embedded ICC profile is inconsistent, so its colour information cannot be preserved.")
                        iccCount = cnt
                        iccParts[seq] = body.copyOfRange(14, len)
                    }
                    0xEE -> if (len >= 12 && String(body, 0, 5, Charsets.ISO_8859_1) == "Adobe") adobeTransform = body[11].toInt() and 255
                    0xC0, 0xC1 -> {
                        if (sawSof) throw unreadable(name, "JPEG is corrupt (two frame headers).")
                        if (len < 6) throw unreadable(name, "JPEG is corrupt (short SOF).")
                        val prec = body[0].toInt() and 255
                        h = ((body[1].toInt() and 255) shl 8) or (body[2].toInt() and 255)
                        w = ((body[3].toInt() and 255) shl 8) or (body[4].toInt() and 255)
                        val n = body[5].toInt() and 255
                        if (prec != 8) throw unsupported(name, "this JPEG uses $prec-bit samples; only 8-bit JPEG is supported.")
                        if (w == 0 || h == 0) throw unsupported(name, "this JPEG has no height stored in its header (DNL); it is not supported.")
                        if (len < 6 + 3 * n) throw unreadable(name, "JPEG is corrupt (short SOF).")
                        comps = List(n) { Comp(body[6 + 3 * it].toInt() and 255, (body[7 + 3 * it].toInt() and 255) shr 4, body[7 + 3 * it].toInt() and 15, body[8 + 3 * it].toInt() and 255) }
                        sawSof = true
                    }
                    0xC2 -> throw unsupported(name, "this is a progressive JPEG. Only baseline (sequential) JPEG is supported; the file was not modified.")
                    0xC3, in 0xC5..0xC7, in 0xC9..0xCB, in 0xCD..0xCF ->
                        throw unsupported(name, "this JPEG uses an unsupported coding process (lossless, hierarchical or arithmetic coding).")
                    0xDA -> { // SOS
                        val cs = comps ?: throw unreadable(name, "JPEG is corrupt (image data before the frame header).")
                        return start(stream, inp, name, w, h, cs, quant, dcT, acT, ri, body, len, adobeTransform, orientation, iccParts, iccCount)
                    }
                }
            }
        }

        private fun start(
            stream: InputStream, inp: ByteReader, name: String, w: Int, h: Int, cs0: List<Comp>,
            quant: Array<IntArray?>, dcT: Array<ShortArray?>, acT: Array<ShortArray?>, ri: Int,
            sos: ByteArray, sosLen: Int, adobe: Int, orientation: Int, iccParts: Map<Int, ByteArray>, iccCount: Int
        ): RowSource {
            val n = cs0.size
            // A single-component scan is one 8x8 block per MCU whatever sampling factors the header states.
            val cs = if (n == 1) listOf(Comp(cs0[0].id, 1, 1, cs0[0].tq)) else cs0
            when (n) {
                1 -> {}
                3 -> {
                    if (adobe == 0 || (cs[0].id == 'R'.code && cs[1].id == 'G'.code && cs[2].id == 'B'.code))
                        throw unsupported(name, "this JPEG stores RGB directly (not YCbCr); only standard YCbCr JPEG is supported.")
                    if (adobe > 1) throw unsupported(name, "this JPEG uses an unsupported colour transform (Adobe $adobe).")
                }
                4 -> throw unsupported(name, "this JPEG is CMYK/YCCK; converting it to RGB would alter colours, so it is not supported.")
                else -> throw unsupported(name, "this JPEG has $n colour components; not supported.")
            }
            if (n == 3) {
                val y = cs[0]
                val okY = (y.h == 1 && y.v == 1) || (y.h == 2 && y.v == 1) || (y.h == 2 && y.v == 2)
                if (!okY || cs[1].h != 1 || cs[1].v != 1 || cs[2].h != 1 || cs[2].v != 1)
                    throw unsupported(name, "this JPEG uses chroma subsampling (luma ${y.h}x${y.v}, chroma ${cs[1].h}x${cs[1].v}) that is not supported. Supported: 4:4:4, 4:2:2 and 4:2:0.")
            } else if (cs0[0].h < 1 || cs0[0].v < 1 || cs0[0].h > 4 || cs0[0].v > 4) {
                throw unreadable(name, "JPEG is corrupt (bad sampling factors).")
            }
            if (orientation != 1) throw unsupported(
                name, "this JPEG carries an EXIF rotation/flip flag (orientation $orientation). Applying it would rearrange the pixels, so the file is not accepted."
            )
            // --- scan header
            val ns = sos[0].toInt() and 255
            if (ns != n) throw unsupported(name, "this JPEG stores its colour components in separate scans (non-interleaved); not supported.")
            if (sosLen < 1 + 2 * ns + 3) throw unreadable(name, "JPEG is corrupt (short SOS).")
            for (i in 0 until ns) {
                val id = sos[1 + 2 * i].toInt() and 255
                val c = cs.firstOrNull { it.id == id } ?: throw unreadable(name, "JPEG is corrupt (scan refers to an unknown component).")
                val t = sos[2 + 2 * i].toInt() and 255
                c.td = t shr 4; c.ta = t and 15
                if (c.td > 3 || c.ta > 3) throw unreadable(name, "JPEG is corrupt (bad Huffman table selector).")
            }
            val ss = sos[1 + 2 * ns].toInt() and 255; val se = sos[2 + 2 * ns].toInt() and 255; val a = sos[3 + 2 * ns].toInt() and 255
            if (ss != 0 || se != 63 || a != 0) throw unsupported(name, "this JPEG uses spectral selection / successive approximation (progressive); not supported.")
            for (c in cs) {
                if (c.tq > 3 || quant[c.tq] == null) throw unreadable(name, "JPEG is corrupt (quantisation table missing).")
                if (dcT[c.td] == null || acT[c.ta] == null) throw unreadable(name, "JPEG is corrupt (Huffman table missing).")
            }
            val chunks = ArrayList<PngChunk>()
            if (iccCount >= 0) chunks += iccChunk(name, iccParts, iccCount, n == 1)
            val colorType = if (n == 1) 0 else 2
            val info = RasterInfo(w, h, colorType, 8, colorChunks = chunks)
            val src = JpegRowSource(name, inp, info, cs, cs[0].h, cs[0].v, ri)
            src.quant = quant; src.dcLut = dcT; src.acLut = acT
            return src
        }

        private fun iccChunk(name: String, parts: Map<Int, ByteArray>, count: Int, gray: Boolean): PngChunk {
            if (count == 0 || parts.size != count || (1..count).any { it !in parts })
                throw unsupported(name, "the embedded ICC profile is incomplete, so its colour information cannot be preserved.")
            val profile = ByteArrayOutputStream().also { o -> for (i in 1..count) o.write(parts.getValue(i)) }.toByteArray()
            if (profile.size < 132 || String(profile, 36, 4, Charsets.ISO_8859_1) != "acsp")
                throw unsupported(name, "the embedded ICC profile is invalid, so it cannot be preserved.")
            val space = String(profile, 16, 4, Charsets.ISO_8859_1)
            if ((gray && space != "GRAY") || (!gray && space != "RGB "))
                throw unsupported(name, "the embedded ICC profile ($space) does not match the image colour model; PNG cannot store this combination.")
            val d = Deflater(9)
            val bos = ByteArrayOutputStream()
            bos.write("ICC Profile".toByteArray(Charsets.ISO_8859_1)); bos.write(0); bos.write(0)
            d.setInput(profile); d.finish()
            val tmp = ByteArray(8192)
            while (!d.finished()) bos.write(tmp, 0, d.deflate(tmp))
            d.end()
            return PngChunk("iCCP", bos.toByteArray())
        }

        /** Reads the EXIF orientation (tag 0x0112) from IFD0; 1 if absent or unreadable. */
        private fun exifOrientation(b: ByteArray, tiff: Int, len: Int): Int {
            if (len < tiff + 8) return 1
            val le = b[tiff].toInt() == 'I'.code
            fun u16(o: Int) = if (le) (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8) else ((b[o].toInt() and 255) shl 8) or (b[o + 1].toInt() and 255)
            fun u32(o: Int) = if (le) u16(o) or (u16(o + 2) shl 16) else (u16(o) shl 16) or u16(o + 2)
            if (u16(tiff + 2) != 42) return 1
            val ifd = tiff + u32(tiff + 4)
            if (ifd < tiff || ifd + 2 > len) return 1
            val n = u16(ifd)
            for (i in 0 until n) {
                val e = ifd + 2 + 12 * i
                if (e + 12 > len) return 1
                if (u16(e) == 0x0112) { val v = u16(e + 8); return if (v in 1..8) v else 1 }
            }
            return 1
        }

        /** 16-bit lookup: index = next 16 bits of the stream, value = (code length shl 8) or symbol; 0 = invalid code. */
        private fun buildLut(counts: IntArray, symbols: IntArray, name: String): ShortArray {
            val lut = ShortArray(1 shl 16)
            var code = 0; var k = 0
            for (len in 1..16) {
                for (i in 0 until counts[len]) {
                    if (code >= (1 shl len)) throw unreadable(name, "JPEG is corrupt (invalid Huffman table).")
                    val shift = 16 - len
                    val from = code shl shift
                    val e = ((len shl 8) or symbols[k]).toShort()
                    for (j in from until (from + (1 shl shift))) lut[j] = e
                    code++; k++
                }
                code = code shl 1
            }
            return lut
        }
    }
}
