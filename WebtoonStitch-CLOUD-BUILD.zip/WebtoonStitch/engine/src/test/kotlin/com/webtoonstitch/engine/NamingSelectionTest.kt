package com.webtoonstitch.engine

import org.junit.Assert.*
import org.junit.Test

class NamingSelectionTest {
    private fun sorted(vararg n: String) = n.toList().sortedWith(NaturalFilenameComparator)

    @Test fun naturalOrder() {
        assertEquals(
            listOf("001.png", "002.png", "003.png", "010.png", "011.png", "020.png"),
            sorted("020.png", "010.png", "003.png", "001.png", "011.png", "002.png")
        )
        assertEquals(listOf("2.png", "10.png", "100.png"), sorted("100.png", "10.png", "2.png"))
        assertEquals(listOf("a2.png", "a10.png", "b1.png"), sorted("b1.png", "a10.png", "a2.png"))
        assertEquals(listOf("ch1_2.png", "ch1_10.png", "ch2_1.png"), sorted("ch2_1.png", "ch1_10.png", "ch1_2.png"))
    }

    @Test fun naturalOrderIsDeterministicAndTotal() {
        val names = listOf("1.png", "01.png", "001.png", "A1.png", "a1.png", "x.png", "X.png", "99999999999999999999999.png", "5.png")
        val a = names.sortedWith(NaturalFilenameComparator)
        val b = names.reversed().sortedWith(NaturalFilenameComparator)
        assertEquals(a, b)
        for (x in names) for (y in names) assertEquals(-Integer.signum(NaturalFilenameComparator.compare(x, y)), Integer.signum(NaturalFilenameComparator.compare(y, x)))
    }

    @Test fun stitchNames() {
        assertEquals("001-009.png", OutputNaming.stitchName((1..9).map { "00$it.png" }.reversed()))
        assertEquals("Chapter_001-Chapter_003.png", OutputNaming.stitchName(listOf("Chapter_002.png", "Chapter_003.png", "Chapter_001.png")))
        assertEquals("a.b-a.d.png", OutputNaming.stitchName(listOf("a.b.png", "a.d.png")))
        assertEquals("001-001.png", OutputNaming.stitchName(listOf("001.png")))
    }

    @Test fun tiffNames() {
        assertEquals("001.png", OutputNaming.tiffToPngName("001.tif"))
        assertEquals("003.png", OutputNaming.tiffToPngName("003.tiff"))
        assertEquals("a.b.png", OutputNaming.tiffToPngName("a.b.TIF"))
    }

    @Test fun uniqueNames() {
        assertEquals("a.png", OutputNaming.uniqueName("a.png") { false })
        assertEquals("a (1).png", OutputNaming.uniqueName("a.png") { it == "a.png" })
        assertEquals("a (3).png", OutputNaming.uniqueName("a.png") { it in setOf("a.png", "a (1).png", "a (2).png") })
    }

    private fun c(n: String, w: Int, h: Int, f: String = "2/8") = Candidate(n, n, w, h, f)

    @Test fun selectionKeepsNaturalOrderNotSelectionOrder() {
        val s = StitchSelection()
        for (n in listOf("010.png", "002.png", "001.png")) assertEquals(AddResult.Accepted, s.tryAdd(c(n, 690, 100)))
        assertEquals(listOf("001.png", "002.png", "010.png"), s.items.map { it.name })
    }

    @Test fun cumulativeLimitFromSpec() {
        val s = StitchSelection()
        for ((i, h) in listOf(2000, 2500, 2000, 2500, 2500).withIndex()) assertEquals(AddResult.Accepted, s.tryAdd(c("00${i + 1}.png", 690, h)))
        assertEquals(11_500, s.totalHeight)
        assertEquals(500, s.remainingHeight)
        val r = s.tryAdd(c("006.png", 690, 700))
        assertTrue(r is AddResult.Rejected)
        assertEquals(RejectReason.HEIGHT_LIMIT, (r as AddResult.Rejected).reason)
        assertTrue(r.message.startsWith("Selection limit exceeded. Maximum combined image height is 12,000 px."))
        assertEquals(5, s.count)
        assertEquals(11_500, s.totalHeight)
        // exactly fitting is allowed
        assertEquals(AddResult.Accepted, s.tryAdd(c("007.png", 690, 500)))
        assertEquals(12_000, s.totalHeight)
        assertEquals(0, s.remainingHeight)
        // deselect recalculates immediately
        assertTrue(s.remove("007.png"))
        assertEquals(500, s.remainingHeight)
        assertEquals(AddResult.Accepted, s.tryAdd(c("006.png", 690, 500)))
    }

    @Test fun singleImageTallerThanLimitRejected() {
        val r = StitchSelection().tryAdd(c("a.png", 690, 12_001))
        assertTrue(r is AddResult.Rejected && r.reason == RejectReason.HEIGHT_LIMIT)
    }

    @Test fun widthMismatchRejectedWithNamesAndWidths() {
        val s = StitchSelection()
        s.tryAdd(c("001.png", 690, 4000))
        val r = s.tryAdd(c("002.png", 720, 3500)) as AddResult.Rejected
        assertEquals(RejectReason.WIDTH_MISMATCH, r.reason)
        assertTrue(r.message.contains("Image width mismatch. All selected images must have the same width."))
        assertTrue(r.message.contains("001.png: 690 px"))
        assertTrue(r.message.contains("002.png: 720 px"))
        assertEquals(1, s.count)
    }

    @Test fun formatMismatchAndInvalidAndDuplicate() {
        val s = StitchSelection()
        s.tryAdd(c("1.png", 10, 10, "2/8"))
        assertEquals(RejectReason.FORMAT_MISMATCH, (s.tryAdd(c("2.png", 10, 10, "2/16")) as AddResult.Rejected).reason)
        assertEquals(RejectReason.INVALID, (s.tryAdd(c("3.png", 0, 0)) as AddResult.Rejected).reason)
        assertEquals(RejectReason.DUPLICATE, (s.tryAdd(c("1.png", 10, 10, "2/8")) as AddResult.Rejected).reason)
    }

    @Test fun removingFirstImageAllowsNewWidth() {
        val s = StitchSelection()
        s.tryAdd(c("1.png", 690, 10)); s.remove("1.png")
        assertEquals(AddResult.Accepted, s.tryAdd(c("2.png", 720, 10)))
    }
}
