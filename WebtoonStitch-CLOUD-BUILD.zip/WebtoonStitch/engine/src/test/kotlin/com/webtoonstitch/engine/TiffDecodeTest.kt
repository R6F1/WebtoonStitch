package com.webtoonstitch.engine

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.awt.color.ColorSpace
import java.awt.color.ICC_ColorSpace
import java.awt.color.ICC_Profile
import java.awt.image.*
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import javax.imageio.IIOImage
import javax.imageio.ImageIO
import javax.imageio.ImageWriteParam
import javax.imageio.stream.MemoryCacheImageOutputStream

class TiffDecodeTest {
    @get:Rule val tmp = TemporaryFolder()

    // ---------- Part 1: files produced by the JDK's own TIFF encoder (independent of my code) ----------

    private fun imageIoTiff(img: BufferedImage, compression: String): ByteArray {
        val w = ImageIO.getImageWritersByFormatName("tiff").next()
        val p = w.defaultWriteParam
        if (compression == "None") p.compressionMode = ImageWriteParam.MODE_DISABLED
        else { p.compressionMode = ImageWriteParam.MODE_EXPLICIT; p.compressionType = compression }
        val bos = ByteArrayOutputStream()
        MemoryCacheImageOutputStream(bos).use { w.output = it; w.write(null, IIOImage(img, null, null), p) }
        w.dispose()
        return bos.toByteArray()
    }

    private fun image(kind: String, w: Int, h: Int, seed: Long, noisy: Boolean): BufferedImage {
        val r = java.util.Random(seed)
        fun v(max: Int, x: Int, y: Int, c: Int) = if (noisy) r.nextInt(max + 1) else ((x * 3 + y * 5 + c * 40) % (max + 1))
        return when (kind) {
            "gray8" -> BufferedImage(w, h, BufferedImage.TYPE_BYTE_GRAY).also { b -> for (y in 0 until h) for (x in 0 until w) b.raster.setSample(x, y, 0, v(255, x, y, 0)) }
            "gray16" -> BufferedImage(w, h, BufferedImage.TYPE_USHORT_GRAY).also { b -> for (y in 0 until h) for (x in 0 until w) b.raster.setSample(x, y, 0, v(65535, x * 17, y * 13, 0)) }
            "rgb8" -> BufferedImage(w, h, BufferedImage.TYPE_3BYTE_BGR).also { b -> for (y in 0 until h) for (x in 0 until w) for (c in 0..2) b.raster.setSample(x, y, c, v(255, x, y, c)) }
            "rgba8" -> BufferedImage(w, h, BufferedImage.TYPE_4BYTE_ABGR).also { b -> for (y in 0 until h) for (x in 0 until w) for (c in 0..3) b.raster.setSample(x, y, c, v(255, x, y, c)) }
            "rgb16" -> {
                val cm = ComponentColorModel(ColorSpace.getInstance(ColorSpace.CS_sRGB), intArrayOf(16, 16, 16), false, false, java.awt.Transparency.OPAQUE, DataBuffer.TYPE_USHORT)
                val ras = Raster.createInterleavedRaster(DataBuffer.TYPE_USHORT, w, h, w * 3, 3, intArrayOf(0, 1, 2), null)
                BufferedImage(cm, ras, false, null).also { b -> for (y in 0 until h) for (x in 0 until w) for (c in 0..2) b.raster.setSample(x, y, c, v(65535, x * 11, y * 7, c)) }
            }
            else -> throw IllegalArgumentException(kind)
        }
    }

    /** Samples straight from the source raster (BufferedImage), in PNG channel order, expressed per row as big-endian bytes. */
    private fun expectedRows(img: BufferedImage, kind: String): List<ByteArray> {
        val chans = when (kind) { "gray8", "gray16" -> 1; "rgb8", "rgb16" -> 3; else -> 4 }
        val bytes = if (kind.endsWith("16")) 2 else 1
        // BufferedImage band order for 3BYTE_BGR / 4BYTE_ABGR rasters is already RGB(A) for getSample (band 0 = R)
        return List(img.height) { y ->
            ByteArray(img.width * chans * bytes).also { row ->
                for (x in 0 until img.width) for (c in 0 until chans) {
                    val s = img.raster.getSample(x, y, c)
                    val o = (x * chans + c) * bytes
                    if (bytes == 2) { row[o] = (s shr 8).toByte(); row[o + 1] = s.toByte() } else row[o] = s.toByte()
                }
            }
        }
    }

    @Test fun imageIoEncodedTiffsDecodeAndConvertExactly() {
        var cases = 0
        for (kind in listOf("gray8", "gray16", "rgb8", "rgba8", "rgb16")) for (comp in listOf("None", "LZW", "Deflate", "PackBits", "ZLib")) for (noisy in listOf(false, true)) {
            val img = image(kind, 131, 77, 42, noisy)
            val tiff = imageIoTiff(img, comp)
            val exp = expectedRows(img, kind)
            val label = "$kind/$comp/${if (noisy) "noise" else "smooth"}"
            val input = TiffTestUtil.input("$label.tif".replace('/', '_'), tiff, tmp.root)
            val (info, rows) = TiffTestUtil.decodeToRows(input)
            assertEquals(label, 131, info.width); assertEquals(label, 77, info.height)
            assertEquals(label, if (kind.endsWith("16")) 16 else 8, info.bitDepth)
            assertEquals(label, when (kind) { "gray8", "gray16" -> 0; "rgb8", "rgb16" -> 2; else -> 6 }, info.colorType)
            TestUtil.assertRowsEqual(exp, rows, "TIFF decode $label")
            // full conversion -> PNG -> decode with the JDK's PNG reader (independent) and compare to the original raster
            val bos = ByteArrayOutputStream(); TiffConverter.convert(input, bos)
            TiffConverter.verify(input, { ByteArrayInputStream(bos.toByteArray()) })
            val png = ImageIO.read(ByteArrayInputStream(bos.toByteArray()))
            for (y in 0 until 77) for (x in 0 until 131) for (c in 0 until img.raster.numBands) {
                assertEquals("$label PNG sample ($x,$y,$c)", img.raster.getSample(x, y, c), png.raster.getSample(x, y, c))
            }
            cases++
        }
        println("ImageIO-encoded TIFF cases verified: $cases")
    }

    @Test fun largerStripsAndOddWidthsFromImageIo() {
        for (w in intArrayOf(1, 2, 7, 1001)) {
            val img = image("rgb8", w, 300, 5L, true)
            val input = TiffTestUtil.input("w$w.tif", imageIoTiff(img, "LZW"), tmp.root)
            TestUtil.assertRowsEqual(expectedRows(img, "rgb8"), TiffTestUtil.decodeToRows(input).second, "width $w")
        }
    }

    @Test fun iccProfileFromImageIoIsPreservedBitForBit() {
        val prof = ICC_Profile.getInstance(ColorSpace.CS_sRGB)
        val cs = ICC_ColorSpace(prof)
        val cm = ComponentColorModel(cs, intArrayOf(8, 8, 8), false, false, java.awt.Transparency.OPAQUE, DataBuffer.TYPE_BYTE)
        val ras = Raster.createInterleavedRaster(DataBuffer.TYPE_BYTE, 20, 10, 60, 3, intArrayOf(0, 1, 2), null)
        val img = BufferedImage(cm, ras, false, null)
        for (y in 0 until 10) for (x in 0 until 20) for (c in 0..2) img.raster.setSample(x, y, c, (x * 9 + y * 5 + c) and 255)
        val tiff = imageIoTiff(img, "LZW")
        val input = TiffTestUtil.input("icc.tif", tiff, tmp.root)
        val bos = ByteArrayOutputStream(); TiffConverter.convert(input, bos)
        val (pi, _) = TestUtil.decodePng(bos.toByteArray())
        val chunk = pi.colorChunks.single { it.type == "iCCP" }
        assertEquals("ICC Profile", String(chunk.data, 0, 11, Charsets.ISO_8859_1))
        val inf = java.util.zip.Inflater(); inf.setInput(chunk.data, 13, chunk.data.size - 13)
        val out = ByteArray(prof.data.size + 10); val n = inf.inflate(out); inf.end()
        assertArrayEquals(prof.data, out.copyOf(n))
    }

    // ---------- Part 2: hand-built TIFFs (exact control over tags) ----------

    private fun rowsOf(w: Int, h: Int, spp: Int, bytes: Int, seed: Long) =
        TestUtil.randomRows(RasterInfo(w, h, when (spp) { 1 -> 0; 2 -> 4; 3 -> 2; else -> 6 }, bytes * 8), seed)

    @Test fun endiannessCompressionAndPredictorMatrix() {
        var n = 0
        for (le in listOf(false, true)) for (comp in listOf(1, 8, 32946, 32773)) for (pred in listOf(1, 2)) for (bps in listOf(8, 16)) for (spp in listOf(1, 3)) {
            if (pred == 2 && comp == 1) continue  // predictor is defined for compressed data; skip nonsense combo
            val rows = rowsOf(53, 41, spp, bps / 8, 77L + n)
            val spec = TiffSpec(53, 41, spp, bps, if (spp == 1) 1 else 2, compression = comp, predictor = pred, le = le, rps = 8)
            val input = TiffTestUtil.input("m$n.tif", TiffTestUtil.write(spec, rows), tmp.root)
            val (info, got) = TiffTestUtil.decodeToRows(input)
            assertEquals(bps, info.bitDepth)
            TestUtil.assertRowsEqual(rows, got, "le=$le comp=$comp pred=$pred bps=$bps spp=$spp")
            n++
        }
        println("endianness/compression/predictor combinations verified: $n")
    }

    @Test fun singleStripWholeImageAndPartialLastStrip() {
        for (rps in intArrayOf(41, 40, 7, 1)) {
            val rows = rowsOf(30, 41, 3, 1, rps.toLong())
            val input = TiffTestUtil.input("s$rps.tif", TiffTestUtil.write(TiffSpec(30, 41, 3, 8, 2, compression = 8, rps = rps), rows), tmp.root)
            TestUtil.assertRowsEqual(rows, TiffTestUtil.decodeToRows(input).second, "rps=$rps")
        }
    }

    @Test fun whiteIsZeroIsInvertedExactlyAtEveryDepth() {
        for (bps in intArrayOf(1, 2, 4, 8, 16)) for (le in listOf(false, true)) {
            val w = 21; val h = 9
            val rows = TestUtil.randomRows(RasterInfo(w, h, 0, bps), 9L + bps)
            val input = TiffTestUtil.input("wiz$bps$le.tif", TiffTestUtil.write(TiffSpec(w, h, 1, bps, 0, le = le), rows), tmp.root)
            val (info, got) = TiffTestUtil.decodeToRows(input)
            assertEquals(bps, info.bitDepth)
            val max = (1 shl bps) - 1
            for (y in 0 until h) for (x in 0 until w) {
                fun sample(r: ByteArray): Int = when {
                    bps == 16 -> ((r[2 * x].toInt() and 255) shl 8) or (r[2 * x + 1].toInt() and 255)
                    bps == 8 -> r[x].toInt() and 255
                    else -> { val bit = x * bps; (r[bit / 8].toInt() and 255 shr (8 - bps - bit % 8)) and max }
                }
                val maxv = if (bps == 16) 65535 else max
                assertEquals("bps=$bps ($x,$y)", maxv - sample(rows[y]), sample(got[y]))
            }
        }
    }

    @Test fun lowBitGrayBlackIsZeroIsByteExact() {
        for (bps in intArrayOf(1, 2, 4)) {
            val rows = TestUtil.randomRows(RasterInfo(21, 6, 0, bps), 3L + bps)
            val input = TiffTestUtil.input("g$bps.tif", TiffTestUtil.write(TiffSpec(21, 6, 1, bps, 1, compression = 32773), rows), tmp.root)
            TestUtil.assertRowsEqual(rows, TiffTestUtil.decodeToRows(input).second, "bps=$bps")
        }
    }

    @Test fun paletteExactWhenRepresentableIn8Bit() {
        val n = 16
        val cm = IntArray(3 * n) { (it * 257) and 0xFFFF }.also { for (i in it.indices) it[i] = ((i * 13) % 256) * 257 }
        val rows = TestUtil.randomRows(RasterInfo(10, 5, 3, 4, ByteArray(48)), 4)
        val input = TiffTestUtil.input("pal.tif", TiffTestUtil.write(TiffSpec(10, 5, 1, 4, 3, colormap = cm), rows), tmp.root)
        val (info, got) = TiffTestUtil.decodeToRows(input)
        assertEquals(3, info.colorType)
        for (i in 0 until n) for (c in 0..2) assertEquals(cm[c * n + i] / 257, info.palette!![i * 3 + c].toInt() and 255)
        TestUtil.assertRowsEqual(rows, got)
        // not representable -> rejected
        val bad = cm.copyOf().also { it[5] = 12345 }
        val e = rejects(TiffTestUtil.write(TiffSpec(10, 5, 1, 4, 3, colormap = bad), rows))
        assertEquals(ErrorCode.UNSUPPORTED, e.code); assertTrue(e.message!!, e.message!!.contains("palette"))
    }

    @Test fun unassociatedAlphaPreservedGrayAndRgb() {
        for (bps in intArrayOf(8, 16)) for (spp in intArrayOf(2, 4)) for (le in listOf(false, true)) {
            val rows = rowsOf(19, 11, spp, bps / 8, bps * 10L + spp)
            val spec = TiffSpec(19, 11, spp, bps, if (spp == 2) 1 else 2, extra = 2, le = le, compression = 8, predictor = 2, rps = 4)
            val (info, got) = TiffTestUtil.decodeToRows(TiffTestUtil.input("a$bps$spp$le.tif", TiffTestUtil.write(spec, rows), tmp.root))
            assertEquals(if (spp == 2) 4 else 6, info.colorType); assertTrue(info.hasAlpha)
            TestUtil.assertRowsEqual(rows, got, "alpha bps=$bps spp=$spp le=$le")
        }
    }

    @Test fun whiteIsZeroGrayAlphaInvertsOnlyTheGrayChannel() {
        for (bps in intArrayOf(8, 16)) {
            val rows = rowsOf(9, 3, 2, bps / 8, 1)
            val (_, got) = TiffTestUtil.decodeToRows(TiffTestUtil.input("wa$bps.tif", TiffTestUtil.write(TiffSpec(9, 3, 2, bps, 0, extra = 2), rows), tmp.root))
            val b = bps / 8
            for (y in 0 until 3) for (x in 0 until 9) for (k in 0 until b) {
                assertEquals((rows[y][x * 2 * b + k].toInt() xor 0xFF) and 255, got[y][x * 2 * b + k].toInt() and 255)          // gray inverted
                assertEquals(rows[y][x * 2 * b + b + k], got[y][x * 2 * b + b + k])                                              // alpha untouched
            }
        }
    }

    @Test fun allEightOrientationsOnKnownPixels() {
        // stored image 3x2:  a b c / d e f  with 8-bit gray values 1..6
        val rows = listOf(byteArrayOf(1, 2, 3), byteArrayOf(4, 5, 6))
        val expected = mapOf(
            1 to listOf("123", "456"), 2 to listOf("321", "654"), 3 to listOf("654", "321"), 4 to listOf("456", "123"),
            5 to listOf("14", "25", "36"), 6 to listOf("41", "52", "63"), 7 to listOf("63", "52", "41"), 8 to listOf("36", "25", "14")
        )
        for ((o, exp) in expected) for (le in listOf(false, true)) {
            val input = TiffTestUtil.input("o$o$le.tif", TiffTestUtil.write(TiffSpec(3, 2, 1, 8, 1, orientation = o, le = le), rows), tmp.root)
            val (info, got) = TiffTestUtil.decodeToRows(input)
            assertEquals("orientation $o width", exp[0].length, info.width); assertEquals("orientation $o height", exp.size, info.height)
            for (y in exp.indices) assertEquals("orientation $o row $y", exp[y], got[y].joinToString("") { (it.toInt() and 255).toString() })
        }
    }

    @Test fun orientationOnRgb16MovesWholePixels() {
        val rows = List(2) { y -> ByteArray(3 * 6) { i -> (y * 100 + i).toByte() } }   // 3x2 RGB16
        val input = TiffTestUtil.input("o6.tif", TiffTestUtil.write(TiffSpec(3, 2, 3, 16, 2, orientation = 6), rows), tmp.root)
        val (info, got) = TiffTestUtil.decodeToRows(input)
        assertEquals(2, info.width); assertEquals(3, info.height)
        // orientation 6: out(x',y') = src(sx=y', sy=H-1-x')  -> out row 0 = [src(0,1), src(0,0)]
        assertArrayEquals(rows[1].copyOfRange(0, 6) + rows[0].copyOfRange(0, 6), got[0])
    }

    @Test fun iccProfileEmbeddedByHandIsCopiedAndColourModelChecked() {
        val rgb = ICC_Profile.getInstance(ColorSpace.CS_sRGB).data
        val gray = ICC_Profile.getInstance(ColorSpace.CS_GRAY).data
        val rowsRgb = rowsOf(4, 4, 3, 1, 1)
        val (info, _) = TiffTestUtil.decodeToRows(TiffTestUtil.input("i1.tif", TiffTestUtil.write(TiffSpec(4, 4, 3, 8, 2, icc = rgb), rowsRgb), tmp.root))
        assertEquals(1, info.colorChunks.count { it.type == "iCCP" })
        val rowsG = rowsOf(4, 4, 1, 2, 1)
        assertEquals(1, TiffTestUtil.decodeToRows(TiffTestUtil.input("i2.tif", TiffTestUtil.write(TiffSpec(4, 4, 1, 16, 1, icc = gray), rowsG), tmp.root)).first.colorChunks.size)
        val e = rejects(TiffTestUtil.write(TiffSpec(4, 4, 1, 16, 1, icc = rgb), rowsG))
        assertEquals(ErrorCode.UNSUPPORTED, e.code)
        assertEquals(ErrorCode.UNSUPPORTED, rejects(TiffTestUtil.write(TiffSpec(4, 4, 3, 8, 2, icc = ByteArray(200)), rowsRgb)).code)
    }

    // ---------- Part 3: fail safely ----------

    private fun rejects(bytes: ByteArray, name: String = "bad.tif"): EngineException {
        val f = File(tmp.root, "${System.nanoTime()}_$name").apply { writeBytes(bytes) }
        try { Tiff.open(FileImageInput(f)).use { r -> val row = ByteArray(r.info.rowBytes); repeat(r.info.height) { r.readRow(row) } }; fail("expected rejection") }
        catch (e: EngineException) { assertNotNull(e.message); return e }
        throw AssertionError()
    }

    @Test fun unsupportedFormatsAreRejectedWithExplanation() {
        val r1 = rowsOf(8, 8, 1, 1, 1); val r3 = rowsOf(8, 8, 3, 1, 1); val r4 = rowsOf(8, 8, 4, 1, 1)
        val multi = rejects(TiffTestUtil.write(TiffSpec(8, 8, 1, 8, 1, extraPages = 2), r1))
        assertEquals(ErrorCode.MULTI_PAGE, multi.code); assertTrue(multi.message!!.contains("multi-page"))
        assertTrue(rejects(TiffTestUtil.write(TiffSpec(8, 8, 4, 8, 2, extra = 1), r4)).message!!.contains("premultiplied"))
        assertTrue(rejects(TiffTestUtil.write(TiffSpec(8, 8, 4, 8, 2, extra = 0), r4)).message!!.contains("not marked as alpha"))
        assertTrue(rejects(TiffTestUtil.write(TiffSpec(8, 8, 4, 8, 5), r4)).message!!.contains("CMYK"))
        assertTrue(rejects(TiffTestUtil.write(TiffSpec(8, 8, 3, 8, 6), r3)).message!!.contains("YCbCr"))
        assertTrue(rejects(TiffTestUtil.write(TiffSpec(8, 8, 1, 8, 1, compression = 7), r1)).message!!.contains("JPEG"))
        assertTrue(rejects(TiffTestUtil.write(TiffSpec(8, 8, 1, 8, 1, sampleFormat = 3), r1)).message!!.contains("unsigned"))
        assertTrue(rejects(TiffTestUtil.write(TiffSpec(8, 8, 3, 8, 2, planar = 2), r3)).message!!.contains("planar"))
        assertTrue(rejects(TiffTestUtil.write(TiffSpec(8, 8, 1, 8, 1, tiled = true), r1)).message!!.contains("tiled"))
        assertTrue(rejects(TiffTestUtil.write(TiffSpec(8, 8, 1, 12, 1), r1)).message!!.contains("12 bits"))
        assertTrue(rejects(TiffTestUtil.write(TiffSpec(8, 8, 1, 8, 1, magic = 43), r1)).message!!.contains("BigTIFF"))
        assertTrue(rejects(TiffTestUtil.write(TiffSpec(8, 8, 1, 4, 1, orientation = 6), rowsOf(8, 8, 1, 1, 1))).message!!.contains("Orientation"))
        assertEquals(ErrorCode.UNREADABLE, rejects(ByteArray(64) { 7 }).code)
    }

    @Test fun truncatedFileIsReportedNotSilentlyPadded() {
        val rows = rowsOf(64, 64, 3, 1, 8)
        val full = TiffTestUtil.write(TiffSpec(64, 64, 3, 8, 2, compression = 8, rps = 16), rows)
        val e = rejects(full.copyOf(full.size / 2))
        assertEquals(ErrorCode.UNREADABLE, e.code)
    }

    @Test fun corruptCompressedStreamIsReported() {
        val rows = rowsOf(64, 64, 3, 1, 9)
        val bytes = TiffTestUtil.write(TiffSpec(64, 64, 3, 8, 2, compression = 8, rps = 64), rows)
        for (i in 20 until 60) bytes[i] = (bytes[i] + 77).toByte()
        assertEquals(ErrorCode.UNREADABLE, rejects(bytes).code)
    }

    @Test fun verifyDetectsAnyPixelChangeInTheOutput() {
        val rows = rowsOf(40, 40, 3, 2, 21)
        val input = TiffTestUtil.input("v.tif", TiffTestUtil.write(TiffSpec(40, 40, 3, 16, 2), rows), tmp.root)
        val bos = ByteArrayOutputStream(); val info = TiffConverter.convert(input, bos)
        TiffConverter.verify(input, { ByteArrayInputStream(bos.toByteArray()) })
        val (pi, prow) = TestUtil.decodePng(bos.toByteArray())
        prow[17][33] = (prow[17][33] + 1).toByte()          // a single least-significant-bit change of one sample
        val tampered = TestUtil.encodePng(pi, prow)
        try { TiffConverter.verify(input, { ByteArrayInputStream(tampered) }); fail("tampering not detected") }
        catch (e: EngineException) { assertEquals(ErrorCode.VERIFICATION_FAILED, e.code); assertTrue(e.message!!.contains("row 17")) }
        assertEquals(16, info.bitDepth)
    }

    @Test fun orientedTiffThatDoesNotFitInMemoryIsRejectedAtOpenWithNumbersAndNoDownscaling() {
        val rows = List(200) { y -> ByteArray(300 * 3) { (y + it).toByte() } }          // 300x200 RGB8 = 180,000 bytes
        val spec = TiffSpec(300, 200, 3, 8, 2, orientation = 6)
        val input = TiffTestUtil.input("big_rot.tif", TiffTestUtil.write(spec, rows), tmp.root)
        val saved = Tiff.orientationMemoryBudget
        try {
            Tiff.orientationMemoryBudget = { 100_000L }                                   // pretend the app only has ~100 KB to spare
            val e = try { Tiff.open(input).close(); null } catch (x: EngineException) { x }!!
            assertEquals(ErrorCode.OUT_OF_MEMORY, e.code)
            assertTrue(e.message!!, e.message!!.contains("Orientation 6") && e.message!!.contains("never downscaled"))
            // the same rejection applies to the converter, before anything is written
            val bos = ByteArrayOutputStream()
            try { TiffConverter.convert(input, bos); fail() } catch (x: EngineException) { assertEquals(ErrorCode.OUT_OF_MEMORY, x.code) }
            assertEquals("nothing may be written when the file is rejected", 0, bos.size())
            // with enough budget the very same file converts exactly (rotation applied, no resampling)
            Tiff.orientationMemoryBudget = { 10_000_000L }
            val (info, got) = TiffTestUtil.decodeToRows(input)
            assertEquals(200, info.width); assertEquals(300, info.height)
            assertArrayEquals(rows[199].copyOfRange(0, 3) + rows[198].copyOfRange(0, 3), got[0].copyOf(6))   // out(0,0)=src(0,H-1), out(1,0)=src(0,H-2)
        } finally { Tiff.orientationMemoryBudget = saved }
    }

    @Test fun orientationOneIsNeverMemoryLimited() {
        val rows = List(200) { y -> ByteArray(900) { (y * 3 + it).toByte() } }
        val input = TiffTestUtil.input("big_o1.tif", TiffTestUtil.write(TiffSpec(300, 200, 3, 8, 2), rows), tmp.root)
        val saved = Tiff.orientationMemoryBudget
        try { Tiff.orientationMemoryBudget = { 1L }; TestUtil.assertRowsEqual(rows, TiffTestUtil.decodeToRows(input).second, "orientation 1 streams") }
        finally { Tiff.orientationMemoryBudget = saved }
    }
}
