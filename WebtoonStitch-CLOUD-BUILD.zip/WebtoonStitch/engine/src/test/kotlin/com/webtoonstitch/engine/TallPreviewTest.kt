package com.webtoonstitch.engine

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.awt.image.BufferedImage
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import javax.imageio.ImageIO

/**
 * Balanced Region Decoding (tall-image previews). The preview is display-only: these tests pin down its geometry and pixels,
 * the cache, resource handling, and - most importantly - that nothing about it can reach the exported files.
 */
class TallPreviewTest {
    @get:Rule val tmp = TemporaryFolder()

    /** Synthetic source: rows come from [fill]; counts rows read and closes. */
    private class Fake(override val info: RasterInfo, val fill: (y: Int, buf: ByteArray) -> Unit) : RowSource {
        var rowsRead = 0; var closed = false
        override fun readRow(dst: ByteArray) { fill(rowsRead, dst); rowsRead++ }
        override fun close() { closed = true }
    }

    private fun rgb(w: Int, h: Int, f: (x: Int, y: Int) -> Int) = Fake(RasterInfo(w, h, 2, 8)) { y, b ->
        for (x in 0 until w) { val v = f(x, y); b[x * 3] = (v shr 16).toByte(); b[x * 3 + 1] = (v shr 8).toByte(); b[x * 3 + 2] = v.toByte() }
    }
    private fun px(r: Int, g: Int, b: Int) = (255 shl 24) or ((r and 255) shl 16) or ((g and 255) shl 8) or (b and 255)

    // ---- 1. detection ------------------------------------------------------------------------------------------------
    @Test fun tallDetectionThresholds() {
        val side = 320
        assertTrue(TallPreview.isTall(RasterInfo(800, 2400, 2, 8), side))        // exactly 3:1 and > 2*side
        assertFalse(TallPreview.isTall(RasterInfo(800, 2399, 2, 8), side))       // just under 3:1
        assertFalse(TallPreview.isTall(RasterInfo(100, 400, 2, 8), side))        // 4:1 but not more than two preview heights (640)
        assertTrue(TallPreview.isTall(RasterInfo(100, 700, 2, 8), side))
        assertFalse(TallPreview.isTall(RasterInfo(2400, 800, 2, 8), side))       // landscape
        assertFalse(TallPreview.isTall(RasterInfo(690, 1280, 2, 8), side))       // an ordinary webtoon panel keeps the ordinary preview
        assertTrue(TallPreview.isTall(RasterInfo(690, 12000, 2, 8), side))       // the spec's stitched-size image
        assertTrue(TallPreview.isTall(RasterInfo(690, 12000, 6, 16), 512))
    }

    // ---- 2. top / bottom region extraction (exact at 1:1) --------------------------------------------------------------
    @Test fun topAndBottomRegionsAreExtractedExactlyAndTheMiddleIsAbsent() {
        val w = 100; val h = 1000; val side = 320
        val src = rgb(w, h) { x, y -> px(y and 255, (y shr 8) and 255, x) }          // pixel encodes its own source row and column
        val t = Thumbnails.renderPreview(src, side)
        val rr = TallPreview.regionRows(side)
        assertEquals(w, t.width); assertEquals(rr + TallPreview.GAP + rr, t.height)
        for (i in 0 until rr) for (x in 0 until w) {
            assertEquals("top row $i", px(i and 255, (i shr 8) and 255, x), t.argb[i * w + x])
            val sy = h - rr + i
            assertEquals("bottom row $i (source row $sy)", px(sy and 255, (sy shr 8) and 255, x), t.argb[(rr + TallPreview.GAP + i) * w + x])
        }
        for (g in 0 until TallPreview.GAP) for (x in 0 until w) assertEquals(px(128, 128, 128), t.argb[(rr + g) * w + x])
        assertEquals("every source row is read exactly once, in order", h, src.rowsRead)
    }

    // ---- 3. scaling ---------------------------------------------------------------------------------------------------
    @Test fun scalingIsAnIntegerBoxAverageAndNeverUpscales() {
        val w = 800; val h = 4000; val side = 320
        fun v(x: Int, y: Int, c: Int) = (x * 7 + y * 13 + c * 61) and 255
        val src = rgb(w, h) { x, y -> px(v(x, y, 0), v(x, y, 1), v(x, y, 2)) }
        val t = Thumbnails.renderPreview(src, side)
        val step = TallPreview.step(w, side); val rr = TallPreview.regionRows(side)
        assertEquals(3, step); assertEquals(267, t.width); assertEquals(320, t.height)
        assertTrue(t.width <= side && t.height <= side)
        fun expected(ox: Int, srcY0: Int): Int {          // independent reference: average of the step x step block
            val chans = IntArray(3); var n = 0
            for (y in srcY0 until srcY0 + step) for (x in ox * step until minOf(w, ox * step + step)) { for (c in 0..2) chans[c] += v(x, y, c); n++ }
            return px((chans[0] + n / 2) / n, (chans[1] + n / 2) / n, (chans[2] + n / 2) / n)
        }
        for (oy in 0 until rr) for (ox in 0 until t.width) {
            assertEquals("top ($ox,$oy)", expected(ox, oy * step), t.argb[oy * t.width + ox])
            assertEquals("bottom ($ox,$oy)", expected(ox, h - rr * step + oy * step), t.argb[(rr + TallPreview.GAP + oy) * t.width + ox])
        }
        // a narrow image is not enlarged
        val narrow = Thumbnails.renderPreview(rgb(40, 2000) { x, y -> px(x, y, 0) }, side)
        assertEquals(40, narrow.width)
        assertEquals(1, TallPreview.step(40, side))
    }

    @Test fun sixteenBitAlphaAndPaletteSourcesAreHandled() {
        // RGBA 16-bit: the high byte is used; half-transparent pixels are composited on the checker, opaque ones are exact
        val info = RasterInfo(10, 2000, 6, 16)
        val src = Fake(info) { y, b -> for (x in 0 until 10) { val o = x * 8; b[o] = 200.toByte(); b[o + 2] = 100.toByte(); b[o + 4] = 50.toByte(); b[o + 6] = (if (y < 500) 255 else 0).toByte() } }
        val t = Thumbnails.renderPreview(src, 320)
        assertEquals(px(200, 100, 50), t.argb[0])                                   // opaque top
        val rr = TallPreview.regionRows(320)
        val bottom = t.argb[(rr + TallPreview.GAP) * t.width]                       // fully transparent -> checker grey, not the colour
        assertTrue(bottom != px(200, 100, 50)); assertEquals((bottom shr 16) and 255, (bottom shr 8) and 255)
        // palette
        val pal = byteArrayOf(10, 20, 30, 40, 50, 60)
        val p = Fake(RasterInfo(8, 2000, 3, 8, palette = pal)) { _, b -> for (x in 0 until 8) b[x] = (x and 1).toByte() }
        val pt = Thumbnails.renderPreview(p, 320)
        assertEquals(px(10, 20, 30), pt.argb[0]); assertEquals(px(40, 50, 60), pt.argb[1])
    }

    // ---- 4. normal-sized images keep the existing preview ------------------------------------------------------------
    @Test fun normalSizedImagesGetExactlyTheOldPreview() {
        for ((w, h) in listOf(300 to 500, 690 to 1280, 50 to 50, 800 to 2000, 1200 to 700)) {
            val mk = { rgb(w, h) { x, y -> px(x * 3 + y, y * 5, x xor y) } }
            val old = Thumbnails.render(mk(), 320); val now = Thumbnails.renderPreview(mk(), 320)
            assertEquals("$w x $h", old.width, now.width); assertEquals(old.height, now.height); assertArrayEquals(old.argb, now.argb)
        }
        // while a tall image is NOT given the old sliver
        val tall = Thumbnails.renderPreview(rgb(690, 12000) { x, y -> px(x, y, 0) }, 320)
        val sliver = Thumbnails.render(rgb(690, 12000) { x, y -> px(x, y, 0) }, 320)
        assertTrue(sliver.width < 30); assertTrue(tall.width > 200)
    }

    // ---- real PNG through the real decoder ------------------------------------------------------------------------------
    @Test fun realPngFileEndToEnd() {
        val w = 120; val h = 1500
        val img = BufferedImage(w, h, BufferedImage.TYPE_INT_RGB)
        for (y in 0 until h) for (x in 0 until w) img.setRGB(x, y, px((x * 2 + y) and 255, (y * 7) and 255, (x * y) and 255))
        val f = File(tmp.root, "tall.png"); ImageIO.write(img, "png", f)
        val t = ImageDecoders.openPreview(FileImageInput(f)).use { Thumbnails.renderPreview(it, 320) }
        val rr = TallPreview.regionRows(320)
        assertEquals(120, t.width)
        for (i in 0 until rr) for (x in 0 until w) {
            assertEquals(img.getRGB(x, i), t.argb[i * w + x])
            assertEquals(img.getRGB(x, h - rr + i), t.argb[(rr + TallPreview.GAP + i) * w + x])
        }
    }

    // ---- 5. caching -----------------------------------------------------------------------------------------------------
    @Test fun previewCacheHitsMissesEvictionAndTrim() {
        val c = PreviewCache<ByteArray>(100) { it.size.toLong() }
        assertNull(c.get("a")); assertEquals(1, c.misses)
        c.put("a", ByteArray(40)); c.put("b", ByteArray(40))
        assertNotNull(c.get("a")); assertEquals(1, c.hits)             // a is now most recently used
        c.put("c", ByteArray(40))                                      // 120 > 100: evicts the least recently used = b
        assertNull(c.peek("b")); assertNotNull(c.peek("a")); assertNotNull(c.peek("c"))
        assertEquals(80, c.sizeBytes); assertEquals(2, c.count)
        c.put("a", ByteArray(10))                                      // replacing a key re-accounts its size
        assertEquals(50, c.sizeBytes)
        c.trimTo(10); assertTrue(c.sizeBytes <= 10)
        c.clear(); assertEquals(0, c.sizeBytes); assertEquals(0, c.count)
        val m = c.misses; c.peek("zzz"); assertEquals("peek does not count", m, c.misses)
    }

    @Test fun generatedPreviewIsRenderedOnceThenServedFromTheCache() {
        val cache = PreviewCache<Thumbnail>(10L shl 20) { it.argb.size * 4L }
        var renders = 0
        fun get(key: String): Thumbnail = cache.get(key) ?: run {
            renders++; Thumbnails.renderPreview(rgb(100, 1000) { x, y -> px(x, y, 1) }, 320).also { cache.put(key, it) }
        }
        val a = get("f@320"); val b = get("f@320"); val c = get("f@320")
        assertEquals(1, renders); assertSame(a, b); assertSame(b, c)
        get("g@320"); assertEquals(2, renders)
    }

    // ---- 6. resources / cancellation ------------------------------------------------------------------------------------
    @Test fun cancellationStopsEarlyAndTheSourceIsClosedByTheCaller() {
        val src = rgb(100, 100_000) { x, y -> px(x, y, 0) }
        var checks = 0
        try {
            src.use { Thumbnails.renderPreview(it, 320, CancelCheck { if (++checks == 3) throw java.util.concurrent.CancellationException("scrolled away") }) }
            fail("must cancel")
        } catch (_: java.util.concurrent.CancellationException) {}
        assertTrue("stopped after ~64 rows, not 100000 (read ${src.rowsRead})", src.rowsRead < 100)
        assertTrue(src.closed)
    }

    @Test fun failingSourceStillClosesAndPropagates() {
        val src = Fake(RasterInfo(100, 2000, 2, 8)) { y, _ -> if (y == 10) throw EngineException(ErrorCode.UNREADABLE, "x.png: damaged") }
        try { src.use { Thumbnails.renderPreview(it, 320) }; fail() } catch (e: EngineException) { assertEquals(ErrorCode.UNREADABLE, e.code) }
        assertTrue(src.closed)
    }

    @Test fun resultIsSmallRegardlessOfImageSize() {
        val t = Thumbnails.renderPreview(Fake(RasterInfo(4000, 200_000, 2, 8)) { _, _ -> }, 320)   // 800 Mpixel source, no pixels stored
        assertTrue(t.argb.size <= 320 * 320)
        assertEquals(320, t.height)
    }

    // ---- 7. preview data can never reach the export pipeline ------------------------------------------------------------
    private val root: File = run {
        var d: File? = File("").absoluteFile
        while (d != null && !File(d, "app/src/main/kotlin").isDirectory) d = d.parentFile
        d ?: error("project root not found")
    }

    @Test fun noExportCodeReferencesPreviewCode() {
        val engine = File(root, "engine/src/main/kotlin/com/webtoonstitch/engine")
        val exportFiles = listOf("Stitcher.kt", "Jobs.kt", "Png.kt", "Tiff.kt", "TiffCodecs.kt", "Jpeg.kt", "Privacy.kt", "Selection.kt", "Naming.kt", "Rename.kt", "Io.kt", "Model.kt")
        for (n in exportFiles) {
            val t = File(engine, n).readText()
            for (bad in listOf("Thumbnail", "TallPreview", "PreviewCache", "openPreview", "renderPreview"))
                assertFalse("$n must not reference $bad", t.contains(bad))
        }
        val app = File(root, "app/src/main/kotlin/com/webtoonstitch/app")
        for (n in listOf("vm/StitchViewModel.kt", "vm/TiffViewModel.kt", "vm/RenameViewModel.kt", "saf/Saf.kt", "saf/SafRenameFolder.kt")) {
            val t = File(app, n).readText()
            for (bad in listOf("ThumbnailCache", "Thumbnails", "TallPreview", "PreviewCache", "renderPreview"))
                assertFalse("$n must not reference $bad", t.contains(bad))
        }
        // the only code that opens an image for a preview is the cache; the only decoder entry used for export is open()
        assertTrue(File(app, "ThumbnailCache.kt").readText().contains("openPreview"))
        assertFalse(File(engine, "Jobs.kt").readText().contains("openPreview"))
    }

    // ---- 8. stitching output is unchanged by previews ------------------------------------------------------------------
    @Test fun stitchingTallImagesIsPixelIdenticalWhetherOrNotPreviewsWereRendered() {
        fun make(name: String, w: Int, h: Int, k: Int): FileImageInput {
            val img = BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB)
            for (y in 0 until h) for (x in 0 until w) img.setRGB(x, y, ((x * 31 + y * 17 + k * 101) * 2654435761L).toInt() or (if ((x + y) % 5 == 0) 0x40000000 else 0xFF000000.toInt()))
            val f = File(tmp.root, name); ImageIO.write(img, "png", f); return FileImageInput(f)
        }
        val inputs = listOf(make("001.png", 200, 1400, 1), make("002.png", 200, 1700, 2), make("003.png", 200, 900, 3))
        val hashesBefore = inputs.map { sha(File(tmp.root, it.name).readBytes()) }
        fun stitched(): ByteArray { val plan = Stitcher.plan(inputs); return ByteArrayOutputStream().also { Stitcher.stitch(plan, it) }.toByteArray() }

        val without = stitched()
        for (i in inputs) for (side in listOf(320, 512, 100)) ImageDecoders.openPreview(i).use { Thumbnails.renderPreview(it, side) }
        val with = stitched()
        assertArrayEquals("exported PNG bytes must not depend on previews", without, with)
        Stitcher.verify(Stitcher.plan(inputs), { with.inputStream() })                         // pixel-exact against the originals
        val out = ImageIO.read(with.inputStream())
        assertEquals(200, out.width); assertEquals(4000, out.height)                            // no resize, no crop, no gap
        assertEquals(hashesBefore, inputs.map { sha(File(tmp.root, it.name).readBytes()) })     // originals untouched
    }

    private fun sha(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }
}
