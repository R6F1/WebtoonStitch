package com.webtoonstitch.engine

import org.junit.Assert.*
import org.junit.Test
import java.awt.image.BufferedImage
import java.io.ByteArrayInputStream
import javax.imageio.ImageIO

class PngCodecTest {
    private val combos = listOf(
        0 to 1, 0 to 2, 0 to 4, 0 to 8, 0 to 16, 2 to 8, 2 to 16, 4 to 8, 4 to 16, 6 to 8, 6 to 16, 3 to 1, 3 to 2, 3 to 4, 3 to 8
    )

    private fun info(ct: Int, d: Int, w: Int = 37, h: Int = 23) =
        RasterInfo(w, h, ct, d, palette = if (ct == 3) ByteArray(3 * (1 shl d)) { (it * 7).toByte() } else null)

    @Test fun roundTripEveryColourTypeAndDepthIsByteExact() {
        for ((ct, d) in combos) for (level in intArrayOf(0, 6)) {
            val i = info(ct, d)
            val rows = TestUtil.randomRows(i, seed = ct * 100L + d)
            val (ri, back) = TestUtil.decodePng(TestUtil.encodePng(i, rows, level))
            assertEquals("type $ct depth $d", i.formatKey, ri.formatKey)
            assertEquals(i.width, ri.width); assertEquals(i.height, ri.height)
            TestUtil.assertRowsEqual(rows, back, "type $ct depth $d level $level")
        }
    }

    @Test fun paletteTransparencyAndColourChunksSurvive() {
        val chunks = listOf(PngChunk("iCCP", byteArrayOf(1, 2, 3, 0, 0, 9, 9)), PngChunk("gAMA", byteArrayOf(0, 1, -122, -96)))
        val i = RasterInfo(8, 4, 3, 8, ByteArray(768) { (it % 251).toByte() }, ByteArray(10) { (200 + it).toByte() }, chunks)
        val rows = TestUtil.randomRows(i, 5)
        val (ri, back) = TestUtil.decodePng(TestUtil.encodePng(i, rows))
        assertTrue(PngPrivacy.sanitize(i).sameFormatAs(ri))
        assertArrayEquals(i.palette, ri.palette); assertArrayEquals(i.transparency, ri.transparency)
        // Privacy policy: only the free-text profile NAME is replaced; every byte after it (the profile) and the gAMA chunk are identical.
        assertEquals(listOf(PngChunk("iCCP", "ICC Profile".toByteArray() + byteArrayOf(0, 0, 9, 9)), chunks[1]), ri.colorChunks)
        TestUtil.assertRowsEqual(rows, back)
    }

    @Test fun independentDecoderAgrees8bitRgba() {
        val i = info(6, 8, 50, 40)
        val rows = TestUtil.randomRows(i, 11)
        val img = ImageIO.read(ByteArrayInputStream(TestUtil.encodePng(i, rows)))
        for (y in 0 until 40) for (x in 0 until 50) {
            val o = x * 4
            val argb = img.getRGB(x, y) // non-premultiplied for TYPE_4BYTE_ABGR
            val exp = ((rows[y][o + 3].toInt() and 255) shl 24) or ((rows[y][o].toInt() and 255) shl 16) or
                ((rows[y][o + 1].toInt() and 255) shl 8) or (rows[y][o + 2].toInt() and 255)
            assertEquals("($x,$y)", exp, argb)
        }
    }

    @Test fun independentDecoderAgrees16bitGray() {
        val i = info(0, 16, 64, 30)
        val rows = TestUtil.randomRows(i, 12)
        val img = ImageIO.read(ByteArrayInputStream(TestUtil.encodePng(i, rows)))
        assertEquals(BufferedImage.TYPE_USHORT_GRAY, img.type)
        for (y in 0 until 30) for (x in 0 until 64) {
            val exp = ((rows[y][2 * x].toInt() and 255) shl 8) or (rows[y][2 * x + 1].toInt() and 255)
            assertEquals("($x,$y)", exp, img.raster.getSample(x, y, 0))
        }
    }

    @Test fun independentDecoderAgrees16bitRgb() {
        val i = info(2, 16, 20, 20)
        val rows = TestUtil.randomRows(i, 13)
        val img = ImageIO.read(ByteArrayInputStream(TestUtil.encodePng(i, rows)))
        for (y in 0 until 20) for (x in 0 until 20) for (c in 0..2) {
            val o = 6 * x + 2 * c
            val exp = ((rows[y][o].toInt() and 255) shl 8) or (rows[y][o + 1].toInt() and 255)
            assertEquals("($x,$y,$c)", exp, img.raster.getSample(x, y, c))
        }
    }

    @Test fun readsPngsWrittenByTheJdk() {
        val bi = BufferedImage(33, 17, BufferedImage.TYPE_4BYTE_ABGR)
        val r = java.util.Random(3)
        for (y in 0 until 17) for (x in 0 until 33) bi.setRGB(x, y, r.nextInt())
        val bos = java.io.ByteArrayOutputStream(); ImageIO.write(bi, "png", bos)
        val (info, rows) = TestUtil.decodePng(bos.toByteArray())
        assertEquals("6/8", info.formatKey)
        for (y in 0 until 17) for (x in 0 until 33) {
            val argb = bi.getRGB(x, y); val o = x * 4
            assertEquals(argb ushr 24, rows[y][o + 3].toInt() and 255)
            assertEquals((argb shr 16) and 255, rows[y][o].toInt() and 255)
        }
    }

    @Test fun headerOnlyInspectionDoesNotNeedPixelData() {
        val i = info(2, 8, 690, 4000)
        val bos = java.io.ByteArrayOutputStream()
        PngWriter(bos, i).use { w -> val row = ByteArray(i.rowBytes); repeat(i.height) { w.writeRow(row) }; w.finish() }
        val bytes = bos.toByteArray()
        val ri = PngReader.readInfo(ByteArrayInputStream(bytes.copyOf(120)))  // truncated right after the header
        assertEquals(690, ri.width); assertEquals(4000, ri.height)
    }

    @Test fun truncatedAndCorruptFilesFailWithEngineException() {
        val i = info(2, 8, 40, 40)
        val good = TestUtil.encodePng(i, TestUtil.randomRows(i, 1))
        try { TestUtil.decodePng(good.copyOf(good.size / 2)); fail() } catch (e: EngineException) { assertEquals(ErrorCode.UNREADABLE, e.code) }
        val bad = good.copyOf(); bad[bad.size / 2] = (bad[bad.size / 2] + 1).toByte()
        try { TestUtil.decodePng(bad); fail() } catch (e: EngineException) { assertEquals(ErrorCode.UNREADABLE, e.code) }
        try { TestUtil.decodePng(ByteArray(100)); fail() } catch (e: EngineException) { assertEquals(ErrorCode.UNREADABLE, e.code) }
    }

    @Test fun interlacedPngIsRejectedNotMisread() {
        val bi = BufferedImage(10, 10, BufferedImage.TYPE_INT_RGB)
        val w = ImageIO.getImageWritersByFormatName("png").next()
        val p = w.defaultWriteParam
        // JDK's PNG writer supports progressive (Adam7) mode
        p.progressiveMode = javax.imageio.ImageWriteParam.MODE_DEFAULT
        val bos = java.io.ByteArrayOutputStream()
        w.output = ImageIO.createImageOutputStream(bos); w.write(null, javax.imageio.IIOImage(bi, null, null), p); w.dispose()
        try { TestUtil.decodePng(bos.toByteArray()); fail() } catch (e: EngineException) { assertEquals(ErrorCode.UNSUPPORTED, e.code) }
    }
}
