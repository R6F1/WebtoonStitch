package com.webtoonstitch.engine

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.*
import java.util.concurrent.CancellationException

class JobsTest {
    @get:Rule val tmp = TemporaryFolder()

    /**
     * Directory-backed OutputFolder with the same temp->rename contract as the Android implementation.
     * Hooks simulate full storage, corrupted writes, a provider that cannot rename, and a process that dies
     * (ignoreDelete: cleanup code never gets to run).
     */
    private inner class DirFolder(
        val dir: File, val failAfterBytes: Long = Long.MAX_VALUE, val corruptOnRead: Boolean = false,
        val failRename: Boolean = false, val ignoreDelete: Boolean = false
    ) : OutputFolder {
        val created = ArrayList<String>()
        override fun exists(name: String) = File(dir, name).exists()
        override fun removeStaleTemporaries() { dir.listFiles { f -> f.name.contains(TEMP_SUFFIX) }?.forEach { it.delete() } }
        override fun createTemporary(finalNameHint: String): OutputFile {
            var n = 0; var tmpName = finalNameHint + TEMP_SUFFIX
            while (File(dir, tmpName).exists()) tmpName = "$finalNameHint.${++n}$TEMP_SUFFIX"
            val f = File(dir, tmpName); f.createNewFile(); created += tmpName
            return object : OutputFile {
                override fun openOutput(): OutputStream = object : FilterOutputStream(FileOutputStream(f)) {
                    var n = 0L
                    override fun write(b: Int) { if (++n > failAfterBytes) throw IOException("No space left on device"); out.write(b) }
                    override fun write(b: ByteArray, o: Int, l: Int) { n += l; if (n > failAfterBytes) throw IOException("write failed: ENOSPC (No space left on device)"); out.write(b, o, l) }
                }
                override fun openInput(): InputStream {
                    val bytes = f.readBytes()
                    if (corruptOnRead) { val i = bytes.size / 2; bytes[i] = (bytes[i] + 1).toByte() }
                    return ByteArrayInputStream(bytes)
                }
                override fun commit(finalName: String) {
                    if (failRename) throw UnsupportedOperationException("rename not supported")
                    val target = File(dir, finalName)
                    check(!target.exists()) { "engine must never publish over an existing file" }
                    if (!f.renameTo(target)) throw IOException("rename failed")
                }
                override fun delete() { if (!ignoreDelete) f.delete() }
            }
        }
    }

    private fun finals(dir: File) = dir.list()!!.filter { !it.contains(TEMP_SUFFIX) }.sorted()
    private fun temps(dir: File) = dir.list()!!.filter { it.contains(TEMP_SUFFIX) }.sorted()

    private fun pngInput(name: String, w: Int, h: Int, seed: Long, ct: Int = 2, d: Int = 8, dir: File = tmp.root): FileImageInput {
        val i = RasterInfo(w, h, ct, d)
        return FileImageInput(File(dir, name).apply { writeBytes(TestUtil.encodePng(i, TestUtil.randomRows(i, seed))) })
    }

    private fun outDir() = tmp.newFolder()

    @Test fun stitchJobWritesVerifiesAndNamesTheOutput() {
        val out = outDir()
        val ins = listOf(pngInput("002.png", 40, 30, 2), pngInput("001.png", 40, 20, 1))
        val phases = HashSet<Jobs.Phase>()
        val r = Jobs.stitch(ins, DirFolder(out), { phases += it.phase })
        assertEquals("001-002.png", r.outputName); assertEquals(50, r.height); assertEquals(40, r.width)
        assertEquals(setOf(Jobs.Phase.PLANNING, Jobs.Phase.WRITING, Jobs.Phase.VERIFYING), phases)
        assertEquals(listOf("001-002.png"), out.list()!!.toList())
        // source files untouched
        assertEquals(ins.size, tmp.root.listFiles { f -> f.name.endsWith(".png") }!!.size)
    }

    @Test fun existingOutputIsNeverOverwritten() {
        val out = outDir(); val marker = File(out, "001-002.png").apply { writeText("precious") }
        val ins = listOf(pngInput("001.png", 10, 5, 1), pngInput("002.png", 10, 5, 2))
        assertEquals("001-002 (1).png", Jobs.stitch(ins, DirFolder(out)).outputName)
        assertEquals("001-002 (2).png", Jobs.stitch(ins, DirFolder(out)).outputName)
        assertEquals("precious", marker.readText())
    }

    @Test fun fullStorageFailsCleanlyAndLeavesNoPartialFile() {
        val out = outDir()
        val ins = listOf(pngInput("a1.png", 300, 300, 1))
        val e = try { Jobs.stitch(ins, DirFolder(out, failAfterBytes = 5_000)); null } catch (x: EngineException) { x }!!
        assertEquals(ErrorCode.IO_WRITE, e.code); assertTrue(e.message!!, e.message!!.contains("Not enough free storage"))
        assertEquals(0, out.list()!!.size)
    }

    @Test fun cancellationLeavesNoPartialFile() {
        val out = outDir(); var n = 0
        try { Jobs.stitch(listOf(pngInput("1.png", 100, 400, 1)), DirFolder(out), cancel = { if (++n == 50) throw CancellationException() }); fail() } catch (_: CancellationException) {}
        assertEquals(0, out.list()!!.size)
    }

    @Test fun failedVerificationDeletesTheOutputAndReportsIt() {
        val out = outDir()
        val e = try { Jobs.stitch(listOf(pngInput("1.png", 200, 200, 1)), DirFolder(out, corruptOnRead = true)); null } catch (x: EngineException) { x }!!
        assertTrue(e.code == ErrorCode.VERIFICATION_FAILED || e.code == ErrorCode.UNREADABLE)
        assertEquals("a corrupted output must never be kept", 0, out.list()!!.size)
    }

    @Test fun sourceDeletedAfterSelectionIsReportedClearly() {
        val a = pngInput("1.png", 10, 10, 1); val b = pngInput("2.png", 10, 10, 2)
        File(tmp.root, "2.png").delete()
        val e = try { Jobs.stitch(listOf(a, b), DirFolder(outDir())); null } catch (x: EngineException) { x }!!
        assertEquals(ErrorCode.UNREADABLE, e.code); assertTrue(e.message!!, e.message!!.contains("2.png") && e.message!!.contains("deleted"))
    }

    @Test fun tiffBatchReportsEachFileAndContinuesAfterFailures() {
        val out = outDir()
        fun tiff(name: String, spec: TiffSpec, seed: Long): FileImageInput {
            val i = RasterInfo(spec.w, spec.h, if (spec.spp == 1) 0 else 2, spec.bps)
            return TiffTestUtil.input(name, TiffTestUtil.write(spec, TestUtil.randomRows(i, seed)), tmp.root)
        }
        val good1 = tiff("001.tif", TiffSpec(30, 20, 3, 16, 2, compression = 8, predictor = 2), 1)
        val multi = tiff("002.tif", TiffSpec(8, 8, 1, 8, 1, extraPages = 1), 2)
        val cmyk = tiff("003.tif", TiffSpec(8, 8, 4, 8, 5), 3)
        val good2 = tiff("004.tiff", TiffSpec(17, 9, 1, 8, 1, compression = 32773), 4)
        val dup = tiff("004.TIF", TiffSpec(5, 5, 1, 8, 1), 5)             // would also become 004.png
        File(out, "001.png").writeText("existing")                          // pre-existing output
        val done = ArrayList<List<JobOutcome>>()
        val res = Jobs.convertTiffs(listOf(good1, multi, cmyk, good2, dup), DirFolder(out), onFileDone = { done += it })
        // the 2-page file now converts page by page: 5 inputs -> 6 outcomes, reported in 5 per-file callbacks
        assertEquals(6, res.size); assertEquals(res, done.flatten()); assertEquals(5, done.size)
        assertEquals("001 (1).png", (res[0] as JobOutcome.Success).outputName)
        assertEquals("002_p001.png", (res[1] as JobOutcome.Success).outputName)
        assertEquals("002_p002.png", (res[2] as JobOutcome.Success).outputName)
        assertEquals(ErrorCode.UNSUPPORTED, (res[3] as JobOutcome.Failure).code)
        assertEquals("004.png", (res[4] as JobOutcome.Success).outputName)
        assertEquals("004 (1).png", (res[5] as JobOutcome.Success).outputName)
        assertEquals(setOf("001.png", "001 (1).png", "002_p001.png", "002_p002.png", "004.png", "004 (1).png"), out.list()!!.toSet())
        assertEquals("existing", File(out, "001.png").readText())
        // converted file is exactly the source pixels
        val (pi, rows) = TestUtil.decodePng(File(out, "001 (1).png").readBytes())
        assertEquals("2/16", pi.formatKey)
        TestUtil.assertRowsEqual(TiffTestUtil.decodeToRows(good1).second, rows)
    }

    @Test fun tiffBatchCancellationStopsTheBatchAndRemovesPartialOutput() {
        val out = outDir(); var checks = 0
        val ins = (1..3).map { TiffTestUtil.input("$it.tif", TiffTestUtil.write(TiffSpec(64, 64, 1, 8, 1), TestUtil.randomRows(RasterInfo(64, 64, 0, 8), it.toLong())), tmp.root) }
        try { Jobs.convertTiffs(ins, DirFolder(out), cancel = { if (++checks == 100) throw CancellationException() }); fail() } catch (_: CancellationException) {}
        assertTrue("only fully verified outputs may remain", out.list()!!.all { name -> TestUtil.decodePng(File(out, name).readBytes()).first.height == 64 })
        assertTrue(out.list()!!.size < 3)
    }

    @Test fun thumbnailsAreStreamedSubsamplesAndHandleEveryFormat() {
        for ((ct, d) in listOf(0 to 1, 0 to 8, 0 to 16, 2 to 8, 2 to 16, 4 to 8, 6 to 16, 3 to 4)) {
            val i = RasterInfo(700, 2000, ct, d, palette = if (ct == 3) ByteArray(48) { (it * 5).toByte() } else null)
            val bytes = TestUtil.encodePng(i, TestUtil.randomRows(i, 9L))
            val t = PngReader.open(ByteArrayInputStream(bytes)).use { Thumbnails.render(it, 200) }
            assertTrue("$ct/$d", t.width in 1..200 && t.height in 1..200 && t.argb.size == t.width * t.height)
            assertTrue(t.argb.all { (it ushr 24) == 255 })
        }
        // exact content check on a tiny known image: 8-bit gray, step 1
        val i = RasterInfo(3, 2, 0, 8)
        val rows = listOf(byteArrayOf(10, 20, 30), byteArrayOf(40, 50, 60))
        val t = PngReader.open(ByteArrayInputStream(TestUtil.encodePng(i, rows))).use { Thumbnails.render(it, 100) }
        assertEquals(listOf(10, 20, 30, 40, 50, 60), t.argb.map { it and 255 })
    }

    // ---------------- atomic output: temp -> verify -> rename ----------------

    @Test fun finalNameNeverExistsWhileTheOutputIsBeingWrittenOrVerified() {
        val out = outDir()
        val snapshots = ArrayList<Pair<Jobs.Phase, List<String>>>()
        val ins = listOf(pngInput("001.png", 60, 300, 1), pngInput("002.png", 60, 300, 2))
        val r = Jobs.stitch(ins, DirFolder(out), { p -> if (p.fraction in 0.1f..0.9f) snapshots += p.phase to out.list()!!.sorted() })
        assertTrue("expected mid-run observations of both phases", snapshots.any { it.first == Jobs.Phase.WRITING } && snapshots.any { it.first == Jobs.Phase.VERIFYING })
        for ((phase, names) in snapshots) {
            assertFalse("final name visible during $phase: $names", names.contains("001-002.png"))
            assertEquals("only the temporary file may exist during $phase", listOf("001-002.png$TEMP_SUFFIX"), names)
        }
        assertEquals("001-002.png", r.outputName)
        assertEquals(listOf("001-002.png"), out.list()!!.toList())          // after success: only the final file, no temp
    }

    @Test fun processKilledMidWriteLeavesNoFileThatLooksFinishedAndTheNextRunCleansUp() {
        val out = outDir()
        val ins = listOf(pngInput("1.png", 100, 600, 1))
        var n = 0
        // ignoreDelete simulates a killed process: no finally/cleanup code runs. The "kill" happens halfway through writing.
        try { Jobs.stitch(ins, DirFolder(out, ignoreDelete = true), cancel = { if (++n == 300) throw CancellationException("process died") }); fail() } catch (_: CancellationException) {}
        assertEquals("no final-looking file may exist", emptyList<String>(), finals(out))
        assertEquals("the partial data is only under the temporary name", listOf("1-1.png$TEMP_SUFFIX"), temps(out))
        assertFalse("the partial file must not be a valid PNG", try { TestUtil.decodePng(File(out, temps(out)[0]).readBytes()); true } catch (_: EngineException) { false })
        // next run (a new process): stale temp is removed, and the real output is produced normally
        val r = Jobs.stitch(ins, DirFolder(out))
        assertEquals("1-1.png", r.outputName)
        assertEquals(listOf("1-1.png"), out.list()!!.toList())
    }

    @Test fun staleTemporariesAreRemovedButOtherFilesAreNeverTouched() {
        val out = outDir()
        File(out, "x.png$TEMP_SUFFIX").writeText("old partial"); File(out, "y.png.2$TEMP_SUFFIX").writeText("old partial")
        File(out, "mine.png").writeText("user file"); File(out, "notes.part").writeText("user file")
        Jobs.stitch(listOf(pngInput("1.png", 10, 10, 1)), DirFolder(out))
        assertEquals(listOf("1-1.png", "mine.png", "notes.part"), out.list()!!.sorted())
        assertEquals("user file", File(out, "mine.png").readText()); assertEquals("user file", File(out, "notes.part").readText())
    }

    @Test fun cancelAfterVerificationButBeforePublishingKeepsNothing() {
        val out = outDir(); var armed = false
        try {
            Jobs.stitch(listOf(pngInput("1.png", 30, 100, 1)), DirFolder(out),
                { p -> if (p.phase == Jobs.Phase.VERIFYING && p.fraction >= 1f) armed = true },
                { if (armed) throw CancellationException("cancelled at the last moment") })
            fail()
        } catch (_: CancellationException) {}
        assertEquals(0, out.list()!!.size)
    }

    @Test fun providerWithoutRenameFailsSafelyInsteadOfWritingTheFinalNameDirectly() {
        val out = outDir()
        val e = try { Jobs.stitch(listOf(pngInput("1.png", 20, 20, 1)), DirFolder(out, failRename = true)); null } catch (x: EngineException) { x }!!
        assertEquals(ErrorCode.IO_WRITE, e.code); assertTrue(e.message!!, e.message!!.contains("does not support renaming"))
        assertEquals("nothing may be kept, not even a copy", 0, out.list()!!.size)
    }

    @Test fun nameTakenWhileWorkingIsNeverOverwrittenAtPublishTime() {
        val out = outDir(); var planted = false
        val r = Jobs.stitch(listOf(pngInput("1.png", 40, 200, 1)), DirFolder(out), { p ->
            if (!planted && p.phase == Jobs.Phase.WRITING && p.fraction > 0.3f) { planted = true; File(out, "1-1.png").writeText("created by someone else meanwhile") }
        })
        assertTrue(planted)
        assertEquals("1-1 (1).png", r.outputName)
        assertEquals("created by someone else meanwhile", File(out, "1-1.png").readText())
        assertEquals(listOf("1-1 (1).png", "1-1.png"), out.list()!!.sorted())
    }

    @Test fun everyFailureModeLeavesNeitherFinalNorTemporaryFiles() {
        fun inputs() = listOf(pngInput("a.png", 150, 150, 3))
        val cases: List<Pair<String, (File) -> Unit>> = listOf(
            "storage full" to { d -> try { Jobs.stitch(inputs(), DirFolder(d, failAfterBytes = 3_000)) } catch (_: EngineException) {} },
            "corrupt readback" to { d -> try { Jobs.stitch(inputs(), DirFolder(d, corruptOnRead = true)) } catch (_: EngineException) {} },
            "rename refused" to { d -> try { Jobs.stitch(inputs(), DirFolder(d, failRename = true)) } catch (_: EngineException) {} },
            "source vanished" to { d -> val i = inputs(); File(tmp.root, "a.png").delete(); try { Jobs.stitch(i, DirFolder(d)) } catch (_: EngineException) {} },
        )
        for ((name, run) in cases) { val d = outDir(); run(d); assertEquals("after '$name'", emptyList<String>(), d.list()!!.toList()) }
    }

    @Test fun tiffBatchUsesTheSameAtomicWorkflowPerFile() {
        val out = outDir(); val seen = HashSet<String>()
        val ins = (1..2).map { TiffTestUtil.input("$it.tif", TiffTestUtil.write(TiffSpec(80, 80, 1, 8, 1), TestUtil.randomRows(RasterInfo(80, 80, 0, 8), it.toLong())), tmp.root) }
        Jobs.convertTiffs(ins, DirFolder(out), onProgress = { p -> if (p.phase == Jobs.Phase.WRITING) seen += out.list()!!.joinToString("|") })
        for (snapshot in seen) assertTrue("final .png visible while still writing: $snapshot", snapshot.split("|").filter { it.isNotEmpty() }.all { it.contains(TEMP_SUFFIX) || it == "1.png" })
        assertEquals(listOf("1.png", "2.png"), out.list()!!.sorted())
    }
}
