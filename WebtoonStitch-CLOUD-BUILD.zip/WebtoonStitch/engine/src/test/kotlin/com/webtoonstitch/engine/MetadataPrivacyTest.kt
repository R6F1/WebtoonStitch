package com.webtoonstitch.engine

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.*
import java.security.MessageDigest
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.Inflater
import javax.imageio.ImageIO

/**
 * Privacy-safe metadata policy: the stitched / converted PNG contains only pixels + colour management.
 *
 * Sources are deliberately FULL of identifying data: PNGs carrying every ancillary chunk type (tEXt/zTXt/iTXt incl. XMP,
 * eXIf, tIME, pHYs, an unknown private chunk, even bytes after IEND), a JPEG with EXIF (camera, software, dates, author,
 * copyright, GPS), XMP, IPTC and comments, and a TIFF with author/copyright/software/description/XMP/IPTC tags.
 * Every identifying string contains a unique "TOKEN-..." which must not appear ANYWHERE in the output bytes.
 * The output chunks are listed by a parser written in this file (not by the engine's own audit), so the engine does not grade itself.
 */
class MetadataPrivacyTest {
    @get:Rule val tmp = TemporaryFolder()

    // ------------------------------------------------------------------------------------------ helpers

    private fun res(path: String): ByteArray =
        (MetadataPrivacyTest::class.java.getResourceAsStream("/$path") ?: fail("missing resource $path").let { null })!!.use { it.readBytes() }

    private val tokens: List<String> = String(res("privacy/tokens.txt")).lines().filter { it.isNotBlank() }
    private val profile: ByteArray = res("jpeg/profile.icc")

    private class Chunk(val type: String, val data: ByteArray)

    /** Independent PNG chunk lister. Tolerates trailing garbage after IEND (reported separately). */
    private fun chunks(png: ByteArray): Pair<List<Chunk>, Int> {
        assertArrayEquals(byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A), png.copyOf(8))
        val out = ArrayList<Chunk>(); var p = 8
        while (p < png.size) {
            val len = ((png[p].toInt() and 255) shl 24) or ((png[p + 1].toInt() and 255) shl 16) or ((png[p + 2].toInt() and 255) shl 8) or (png[p + 3].toInt() and 255)
            val type = String(png, p + 4, 4, Charsets.ISO_8859_1)
            out += Chunk(type, png.copyOfRange(p + 8, p + 8 + len)); p += 12 + len
            if (type == "IEND") break
        }
        return out to (png.size - p)
    }

    private fun chunkBytes(type: String, data: ByteArray): ByteArray {
        val t = type.toByteArray(Charsets.ISO_8859_1)
        val bo = ByteArrayOutputStream(); val d = DataOutputStream(bo)
        d.writeInt(data.size); d.write(t); d.write(data); d.writeInt(CRC32().also { it.update(t); it.update(data) }.value.toInt())
        return bo.toByteArray()
    }

    private fun z(b: ByteArray): ByteArray { val d = Deflater(); d.setInput(b); d.finish(); val o = ByteArrayOutputStream(); val t = ByteArray(4096); while (!d.finished()) o.write(t, 0, d.deflate(t)); d.end(); return o.toByteArray() }
    private fun latin(s: String) = s.toByteArray(Charsets.ISO_8859_1)

    /** Rebuilds [png] with extra chunks after IHDR, extra chunks after the last IDAT, and raw bytes after IEND. */
    private fun inject(png: ByteArray, before: List<Pair<String, ByteArray>>, after: List<Pair<String, ByteArray>> = emptyList(), trailer: ByteArray = ByteArray(0)): ByteArray {
        val (cs, _) = chunks(png); val bo = ByteArrayOutputStream(); bo.write(png, 0, 8)
        val lastIdat = cs.indexOfLast { it.type == "IDAT" }
        for ((i, c) in cs.withIndex()) {
            bo.write(chunkBytes(c.type, c.data))
            if (i == 0) before.forEach { bo.write(chunkBytes(it.first, it.second)) }
            if (i == lastIdat) after.forEach { bo.write(chunkBytes(it.first, it.second)) }
        }
        bo.write(trailer); return bo.toByteArray()
    }

    /** One of every identifying chunk a PNG may carry. */
    private fun metadataChunksBefore(): List<Pair<String, ByteArray>> = listOf(
        "tEXt" to latin("Author\u0000TOKEN-AUTHOR-4471"), "tEXt" to latin("Copyright\u0000TOKEN-COPYRIGHT-8812"),
        "tEXt" to latin("Software\u0000TOKEN-SOFTWARE-2290"), "tEXt" to latin("Comment\u0000TOKEN-COMMENT-9031"),
        "tEXt" to latin("Description\u0000TOKEN-DESC-6642"), "tEXt" to latin("Creation Time\u00002019:03:07 21:14:55"),
        "zTXt" to (latin("Source\u0000\u0000") + z(latin("TOKEN-OWNER-1523"))),
        "iTXt" to (latin("XML:com.adobe.xmp\u0000\u0000\u0000\u0000\u0000") + latin("<x:xmpmeta>TOKEN-XMP-3318</x:xmpmeta>")),
        "eXIf" to (latin("MM\u0000*\u0000\u0000\u0000\u0008") + latin("GPS TOKEN-MAKE-5530 TOKEN-MODEL-1187 TOKEN-SERIAL-6619")),
        "pHYs" to byteArrayOf(0, 0, 11, 19, 0, 0, 11, 19, 1), "prVt" to latin("TOKEN-IPTC-7724 private chunk")
    )
    private fun metadataChunksAfter(): List<Pair<String, ByteArray>> = listOf(
        "tIME" to byteArrayOf(0x07, 0xE3.toByte(), 3, 7, 21, 14, 55), "tEXt" to latin("Comment\u0000TOKEN-HOST-2214"), "zzZz" to latin("TOKEN-DOCNAME-9987")
    )
    private val trailer = latin("TOKEN-PAGENAME-3301 trailing bytes after IEND")

    private fun containsToken(bytes: ByteArray): List<String> {
        val s = String(bytes, Charsets.ISO_8859_1)
        return tokens.filter { s.contains(it) } + listOf("Exif", "XML:com", "GPS", "Photoshop", "8BIM", "xmpmeta", "TOKEN").filter { s.contains(it) }
    }

    private fun file(dir: File, name: String, bytes: ByteArray) = FileImageInput(File(dir, name).apply { writeBytes(bytes) })

    private class DirFolder(val dir: File, val tamper: ((ByteArray) -> ByteArray)? = null) : OutputFolder {
        override fun exists(name: String) = File(dir, name).exists()
        override fun removeStaleTemporaries() { dir.listFiles { f -> f.name.contains(TEMP_SUFFIX) }?.forEach { it.delete() } }
        override fun createTemporary(finalNameHint: String): OutputFile {
            val f = File(dir, finalNameHint + TEMP_SUFFIX); f.createNewFile()
            return object : OutputFile {
                override fun openOutput(): OutputStream = FileOutputStream(f)
                override fun openInput(): InputStream = ByteArrayInputStream(f.readBytes().let { b -> tamper?.invoke(b) ?: b })
                override fun commit(finalName: String) { check(!File(dir, finalName).exists()); check(f.renameTo(File(dir, finalName))) }
                override fun delete() { f.delete() }
            }
        }
    }

    private fun imageIoSamples(bytes: ByteArray): Triple<Int, Int, IntArray> {
        val r = (ImageIO.read(ByteArrayInputStream(bytes)) ?: fail("ImageIO cannot read the image").let { null })!!.raster
        return Triple(r.width, r.height, IntArray(r.width * r.height * r.numBands).also { r.getPixels(0, 0, r.width, r.height, it) })
    }

    private fun sha(rgb: ByteArray) = MessageDigest.getInstance("SHA-256").digest(rgb).joinToString("") { "%02x".format(it) }

    private fun iccProfileOf(chunk: Chunk): ByteArray {
        val zi = chunk.data.indexOf(0.toByte()); val inf = Inflater().apply { setInput(chunk.data, zi + 2, chunk.data.size - zi - 2) }
        val buf = ByteArray(profile.size + 64); val n = inf.inflate(buf); inf.end(); return buf.copyOf(n)
    }

    /** Everything that must be true of ANY output PNG. Returns its chunks. */
    private fun assertCleanOutput(out: ByteArray, what: String): List<Chunk> {
        val (cs, extra) = chunks(out)
        assertEquals("$what: bytes after IEND", 0, extra)
        val types = cs.map { it.type }
        val bad = types.filter { it !in setOf("IHDR", "PLTE", "tRNS", "iCCP", "sRGB", "gAMA", "cHRM", "cICP", "IDAT", "IEND") }
        assertTrue("$what: forbidden chunks $bad in $types", bad.isEmpty())
        assertEquals("$what: first chunk", "IHDR", types.first()); assertEquals("$what: last chunk", "IEND", types.last())
        val found = containsToken(out)
        assertTrue("$what: identifying strings found in the output: $found", found.isEmpty())
        return cs
    }

    // ------------------------------------------------------------------------------------------ PNG sources

    private fun checkPngSource(name: String, info: RasterInfo, seed: Long, colour: List<Pair<String, ByteArray>>, expectProfile: Boolean) {
        val rows = TestUtil.randomRows(info, seed, smooth = seed % 2 == 0L)
        val plain = TestUtil.encodePng(info, rows)
        val src = inject(plain, colour + metadataChunksBefore(), metadataChunksAfter(), trailer)
        // the test is only meaningful if the source REALLY carries the metadata
        val srcTypes = chunks(src).first.map { it.type }
        for (t in listOf("tEXt", "zTXt", "iTXt", "eXIf", "tIME", "pHYs", "prVt", "zzZz")) assertTrue("$name source lacks $t", t in srcTypes)
        assertTrue("$name source must contain identifying strings", containsToken(src).size >= 8)

        val d = tmp.newFolder(); val out = tmp.newFolder()
        val r = Jobs.stitch(listOf(file(d, "p.png", src)), DirFolder(out))
        assertEquals(listOf(r.outputName), out.list()!!.toList())
        val bytes = File(out, r.outputName).readBytes()
        val cs = assertCleanOutput(bytes, name)

        // exact expected chunk sequence
        val expectTypes = buildList {
            add("IHDR"); colour.forEach { add(it.first) }
            if (info.palette != null) add("PLTE"); if (info.transparency != null) add("tRNS"); add("IDAT"); add("IEND")
        }
        assertEquals("$name chunk sequence", expectTypes.sorted(), cs.map { it.type }.distinct().sorted())
        // geometry / alpha / depth
        val ih = cs.first().data; val bb = java.nio.ByteBuffer.wrap(ih)
        assertEquals(info.width, bb.getInt(0)); assertEquals(info.height, bb.getInt(4)); assertEquals(info.bitDepth, ih[8].toInt()); assertEquals(info.colorType, ih[9].toInt())
        assertEquals(info.transparency?.toList(), cs.firstOrNull { it.type == "tRNS" }?.data?.toList())
        assertEquals(info.palette?.toList(), cs.firstOrNull { it.type == "PLTE" }?.data?.toList())
        // colour management intact: same payload; iCCP only has a neutral name
        for ((t, data) in colour) {
            val o = cs.single { it.type == t }.data
            if (t == "iCCP") {
                assertTrue("iCCP name neutral", String(o, 0, 12, Charsets.ISO_8859_1) == "ICC Profile\u0000")
                val zi = data.indexOf(0.toByte())
                assertArrayEquals("iCCP profile data bytes", data.copyOfRange(zi, data.size), o.copyOfRange(11, o.size))
                if (expectProfile) assertArrayEquals("decoded ICC profile", profile, iccProfileOf(cs.single { it.type == "iCCP" }))
            } else assertArrayEquals("$t chunk", data, o)
        }
        // pixels: the engine's decode, ImageIO's decode of the polluted source, and ImageIO's decode of the output must all agree
        val (_, back) = TestUtil.decodePng(bytes)
        TestUtil.assertRowsEqual(rows, back, "$name pixel rows")
        val a = imageIoSamples(src); val b = imageIoSamples(bytes)
        assertEquals(a.first, b.first); assertEquals(a.second, b.second); assertArrayEquals("$name ImageIO samples", a.third, b.third)
    }

    @Test fun rgb8PngWithEveryKindOfMetadata_isCleaned_colourProfileAndPixelsIntact() {
        val z = latin("ICC Profile").size
        val iccChunk = "iCCP" to (latin("Canon EOS TOKEN-MAKE-5530 profile\u0000\u0000") + z(profile))
        checkPngSource("rgb8+iCCP", RasterInfo(37, 23, 2, 8), 2, listOf(iccChunk, "gAMA" to byteArrayOf(0, 1, -122, -96), "cHRM" to ByteArray(32) { it.toByte() }), true)
    }

    @Test fun srgbTaggedPngKeepsItsSrgbAndGammaChunks() =
        checkPngSource("rgb8+sRGB", RasterInfo(20, 11, 2, 8), 4, listOf("sRGB" to byteArrayOf(0), "gAMA" to byteArrayOf(0, 1, -122, -96)), false)

    @Test fun rgba16PngKeepsAlphaAndSixteenBitDepth() =
        checkPngSource("rgba16", RasterInfo(29, 17, 6, 16), 7, emptyList(), false)

    @Test fun gray16WithAlphaAndPaletteWithTransparencyKeepTheirSpecialChunks() {
        checkPngSource("gray+alpha16", RasterInfo(13, 9, 4, 16), 8, emptyList(), false)
        checkPngSource("palette+tRNS", RasterInfo(31, 12, 3, 8, ByteArray(768) { (it * 7 % 251).toByte() }, ByteArray(40) { (100 + it).toByte() }), 10, emptyList(), false)
        checkPngSource("gray1bit", RasterInfo(37, 9, 0, 1), 12, emptyList(), false)
    }

    @Test fun theWorkingSamplePngKeepsItsAdobeRgbProfileAndExactPixels() {
        val src = res("samples/itloads.png"); val d = tmp.newFolder(); val out = tmp.newFolder()
        val r = Jobs.stitch(listOf(file(d, "itloads.png", src)), DirFolder(out))
        val bytes = File(out, r.outputName).readBytes()
        val cs = assertCleanOutput(bytes, "itloads.png")
        assertEquals(listOf("IHDR", "iCCP", "IDAT", "IEND"), cs.map { it.type }.distinct())
        val before = chunks(src).first.single { it.type == "iCCP" }
        assertArrayEquals(before.data, cs.single { it.type == "iCCP" }.data)          // already neutral: byte-identical
        val a = imageIoSamples(src); val b = imageIoSamples(bytes)
        assertArrayEquals(a.third, b.third)
        assertEquals(String(res("samples/golden.txt")).lines().first { it.startsWith("itloads.png") }.split(" ")[4], sha(ByteArray(b.third.size) { b.third[it].toByte() }))
    }

    // ------------------------------------------------------------------------------------------ JPEG source

    @Test fun jpegWithExifGpsXmpIptcCommentsAndIccProducesAPngWithOnlyPixelsAndTheProfile() {
        val src = res("privacy/meta.jpg")
        assertTrue("source must contain identifying strings", containsToken(src).size >= 8)
        val d = tmp.newFolder(); val out = tmp.newFolder()
        val r = Jobs.stitch(listOf(file(d, "photo.png", src)), DirFolder(out))
        val bytes = File(out, r.outputName).readBytes()
        val cs = assertCleanOutput(bytes, "meta.jpg")
        assertEquals(listOf("IHDR", "iCCP", "IDAT", "IEND"), cs.map { it.type }.distinct())
        assertArrayEquals("ICC profile unchanged", profile, iccProfileOf(cs.single { it.type == "iCCP" }))
        val ih = java.nio.ByteBuffer.wrap(cs.first().data)
        assertEquals(96, ih.getInt(0)); assertEquals(70, ih.getInt(4))
        val a = imageIoSamples(src); val b = imageIoSamples(bytes)
        assertArrayEquals("decoded JPEG pixels == PNG pixels (ImageIO both sides)", a.third, b.third)
        assertEquals(String(res("privacy/golden.txt")).lines().first { it.startsWith("meta.jpg") }.split(" ")[4], sha(ByteArray(b.third.size) { b.third[it].toByte() }))
    }

    // ------------------------------------------------------------------------------------------ TIFF source

    @Test fun tiffWithAuthorCopyrightSoftwareDescriptionXmpIptcConvertsToACleanPng() {
        val src = res("privacy/meta.tif")
        assertTrue("source must contain identifying strings", containsToken(src).size >= 8)
        val d = tmp.newFolder(); val out = tmp.newFolder()
        val res = Jobs.convertTiffs(listOf(file(d, "scan.tif", src)), DirFolder(out))
        val ok = res.single() as JobOutcome.Success
        assertEquals("scan.png", ok.outputName); assertEquals(listOf("scan.png"), out.list()!!.toList())
        val bytes = File(out, ok.outputName).readBytes()
        val cs = assertCleanOutput(bytes, "meta.tif")
        assertEquals(listOf("IHDR", "iCCP", "IDAT", "IEND"), cs.map { it.type }.distinct())
        assertArrayEquals("ICC profile unchanged", profile, iccProfileOf(cs.single { it.type == "iCCP" }))
        val b = imageIoSamples(bytes)
        assertEquals(String(res("privacy/golden.txt")).lines().first { it.startsWith("meta.tif") }.split(" ")[4], sha(ByteArray(b.third.size) { b.third[it].toByte() }))
    }

    // ------------------------------------------------------------------------------------------ the checks themselves can fail

    private fun cleanOutput(): Triple<StitchPlan, ByteArray, RasterInfo> {
        val i = RasterInfo(16, 10, 2, 8); val d = tmp.newFolder()
        val plan = Stitcher.plan(listOf(file(d, "a.png", TestUtil.encodePng(i, TestUtil.randomRows(i, 1)))))
        val bo = ByteArrayOutputStream(); Stitcher.stitch(plan, bo)
        return Triple(plan, bo.toByteArray(), plan.outputInfo)
    }

    @Test fun auditAcceptsACleanFileAndReportsItsChunks() {
        val (plan, bytes, info) = cleanOutput()
        assertEquals(listOf("IHDR", "IDAT", "IEND"), PngPrivacy.audit(ByteArrayInputStream(bytes), info).chunkTypes)
        Stitcher.verify(plan, { ByteArrayInputStream(bytes) })
    }

    @Test fun auditRejectsEveryMetadataChunkTypeAnywhereInTheFile() {
        val (plan, bytes, info) = cleanOutput()
        val kinds = listOf("tEXt" to latin("Author\u0000x"), "zTXt" to (latin("k\u0000\u0000") + z(latin("x"))), "iTXt" to latin("XML:com.adobe.xmp\u0000\u0000\u0000\u0000\u0000x"),
            "eXIf" to latin("MM\u0000*"), "tIME" to ByteArray(7), "pHYs" to ByteArray(9), "bKGD" to ByteArray(6), "sPLT" to latin("p\u0000\u0008"), "prVt" to latin("x"), "zzZz" to latin("x"))
        for ((t, data) in kinds) {
            for (variant in 0..1) {
                val tampered = if (variant == 0) inject(bytes, listOf(t to data)) else inject(bytes, emptyList(), listOf(t to data))
                val e = try { PngPrivacy.audit(ByteArrayInputStream(tampered), info); null } catch (e: EngineException) { e }
                assertNotNull("audit must reject $t (variant $variant)", e); assertEquals(ErrorCode.VERIFICATION_FAILED, e!!.code); assertTrue(e.message!!, e.message!!.contains(t))
                assertEquals(ErrorCode.VERIFICATION_FAILED, try { Stitcher.verify(plan, { ByteArrayInputStream(tampered) }); null } catch (x: EngineException) { x.code })
            }
        }
        val e = try { PngPrivacy.audit(ByteArrayInputStream(bytes + trailer), info); null } catch (e: EngineException) { e }
        assertTrue("data after IEND must be rejected", e != null && e.message!!.contains("follows the IEND"))
    }

    @Test fun auditRejectsAColourProfileThatIsNotTheSources() {
        val (_, bytes, info) = cleanOutput()
        val withIcc = inject(bytes, listOf("iCCP" to (latin("Camera X\u0000\u0000") + z(profile))))
        assertNotNull(try { PngPrivacy.audit(ByteArrayInputStream(withIcc), info); null } catch (e: EngineException) { e })   // not in the source at all
        val src = RasterInfo(16, 10, 2, 8, colorChunks = listOf(PngChunk("iCCP", latin("ICC Profile\u0000\u0000") + z(profile))))
        assertNotNull("a profile with a source-supplied free-text name is not neutral", try { PngPrivacy.audit(ByteArrayInputStream(withIcc), src); null } catch (e: EngineException) { e })
    }

    @Test fun writerRefusesToWriteAnythingButColourChunks() {
        for (t in listOf("tEXt", "eXIf", "tIME", "iTXt", "pHYs", "prVt")) {
            assertThrows(IllegalArgumentException::class.java) {
                PngWriter(ByteArrayOutputStream(), RasterInfo(4, 4, 2, 8, colorChunks = listOf(PngChunk(t, ByteArray(3)))))
            }
        }
    }

    @Test fun ifAnOutputEverCarriedMetadataTheJobFailsAndKeepsNothing() {
        // Simulates a bug (or a storage layer) that adds a chunk to the file between writing and publishing.
        val i = RasterInfo(24, 12, 2, 8); val d = tmp.newFolder()
        val input = file(d, "a.png", TestUtil.encodePng(i, TestUtil.randomRows(i, 3)))
        for (verify in listOf(true, false)) {           // the metadata audit is not optional, even when pixel verification is off
            val out = tmp.newFolder()
            val e = try { Jobs.stitch(listOf(input), DirFolder(out) { b -> inject(b, listOf("tEXt" to latin("Software\u0000TOKEN-SOFTWARE-2290"))) }, verify = verify); null } catch (e: EngineException) { e }
            assertNotNull("verify=$verify", e); assertEquals(ErrorCode.VERIFICATION_FAILED, e!!.code)
            assertEquals("nothing may be published or left behind (verify=$verify)", 0, out.list()!!.size)
        }
    }

    @Test fun metadataRemovalNeverTouchesPixelsAcrossManyShapes() {
        var n = 0
        for (ct in listOf(0, 2, 4, 6)) for (depth in listOf(8, 16)) for (w in listOf(1, 7, 64)) {
            val info = RasterInfo(w, 5, ct, depth); val rows = TestUtil.randomRows(info, ct * 100L + depth + w)
            val src = inject(TestUtil.encodePng(info, rows), metadataChunksBefore(), metadataChunksAfter(), trailer)
            val d = tmp.newFolder(); val out = tmp.newFolder()
            val r = Jobs.stitch(listOf(file(d, "p.png", src)), DirFolder(out))
            val bytes = File(out, r.outputName).readBytes(); assertCleanOutput(bytes, "ct=$ct depth=$depth w=$w")
            TestUtil.assertRowsEqual(rows, TestUtil.decodePng(bytes).second, "ct=$ct depth=$depth w=$w"); n++
        }
        assertEquals(24, n)
    }
}
