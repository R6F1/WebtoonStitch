package com.webtoonstitch.engine

import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.*
import java.util.zip.Deflater
import java.util.zip.DeflaterOutputStream

/**
 * Large-input test. Only runs when the JVM heap is small (so that a pass PROVES streaming):
 *   JVM_OPTS=-Xmx128m TESTS=LargeMemoryTest ./scripts/jvm-test.sh
 */
class LargeMemoryTest {
    @get:Rule val tmp = TemporaryFolder()

    private fun smallHeap() = assumeTrue("run with -Xmx128m or less", Runtime.getRuntime().maxMemory() <= 200L * 1024 * 1024)

    private class PeakSampler : Thread() {
        @Volatile var running = true; @Volatile var peak = 0L
        init { isDaemon = true }
        override fun run() { val rt = Runtime.getRuntime(); while (running) { peak = maxOf(peak, rt.totalMemory() - rt.freeMemory()); sleep(5) } }
    }

    private fun rowFor(k: Int, y: Int, n: Int, buf: ByteArray) {
        for (i in 0 until n) buf[i] = ((i * 3 + y * 7 + k * 31) and 0xFF).toByte()
        buf[(y * 13 + k) % n] = (y xor k).toByte()   // a marker per row so duplicated/missing rows cannot hide
    }

    @Test fun stitch4096x12000Rgba16InBoundedMemory() {
        smallHeap()
        val info = RasterInfo(4096, 3000, 6, 16)
        val files = (1..4).map { k ->
            val f = File(tmp.root, "%03d.png".format(k))
            BufferedOutputStream(FileOutputStream(f), 1 shl 16).use { o ->
                PngWriter(o, info, 1).use { w -> val row = ByteArray(info.rowBytes); for (y in 0 until 3000) { rowFor(k, y, row.size, row); w.writeRow(row) }; w.finish() }
            }
            FileImageInput(f)
        }
        val rawBytes = 4096L * 12000 * 8
        val sampler = PeakSampler().also { it.start() }
        val t0 = System.nanoTime()
        val plan = Stitcher.plan(files.reversed())
        val out = File(tmp.root, plan.outputName)
        var last = 0
        BufferedOutputStream(FileOutputStream(out), 1 shl 16).use { Stitcher.stitch(plan, it, progress = { d, t -> assertTrue(d <= t); last = d }) }
        val t1 = System.nanoTime()
        Stitcher.verify(plan, { BufferedInputStream(FileInputStream(out), 1 shl 16) })
        val t2 = System.nanoTime()
        sampler.running = false
        val oi = PngReader.readInfo(FileInputStream(out))
        assertEquals(4096, oi.width); assertEquals(12000, oi.height); assertEquals("6/16", oi.formatKey)
        assertEquals(12000, last)
        println("STITCH 4096x12000 RGBA16: raw=${rawBytes shr 20} MB, heap max=${Runtime.getRuntime().maxMemory() shr 20} MB, " +
            "peak used<=${sampler.peak shr 20} MB (upper bound, includes uncollected garbage), stitch=${(t1 - t0) / 1_000_000_000} s, " +
            "verify(pixel-exact, all 12000 rows)=${(t2 - t1) / 1_000_000_000} s, output=${out.length() shr 20} MB")
        assertTrue("peak heap must be far below raw image size", sampler.peak < rawBytes / 2)
    }

    /** Streaming TIFF generator: one strip containing the whole image, optionally Deflate-compressed. */
    private fun writeBigTiff(f: File, w: Int, h: Int, deflate: Boolean) {
        val rowBytes = w * 6
        RandomAccessFile(f, "rw").use { raf ->
            raf.write(byteArrayOf('M'.code.toByte(), 'M'.code.toByte(), 0, 42, 0, 0, 0, 0))
            val count = object : FilterOutputStream(BufferedOutputStream(FileOutputStream(raf.fd), 1 shl 16)) {
                var n = 0L
                override fun write(b: Int) { out.write(b); n++ }
                override fun write(b: ByteArray, o: Int, l: Int) { out.write(b, o, l); n += l }
            }
            val sink: OutputStream = if (deflate) DeflaterOutputStream(count, Deflater(1), 1 shl 16) else count
            val row = ByteArray(rowBytes)
            for (y in 0 until h) { rowFor(9, y, rowBytes, row); sink.write(row) }
            if (deflate) (sink as DeflaterOutputStream).finish(); sink.flush()
            val stripLen = count.n
            raf.seek(8 + stripLen)
            val ifd = ByteArrayOutputStream(); val d = DataOutputStream(ifd)
            fun e(tag: Int, type: Int, cnt: Int, value: Int) { d.writeShort(tag); d.writeShort(type); d.writeInt(cnt); if (type == 3 && cnt == 1) { d.writeShort(value); d.writeShort(0) } else d.writeInt(value) }
            val ifdPos = 8 + stripLen + 6 + 6   // after BitsPerSample array (3 shorts)
            val bpsPos = 8 + stripLen
            d.writeShort(11)
            e(256, 4, 1, w); e(257, 4, 1, h); e(258, 3, 3, bpsPos.toInt()); e(259, 3, 1, if (deflate) 8 else 1)
            e(262, 3, 1, 2); e(273, 4, 1, 8); e(277, 3, 1, 3); e(278, 4, 1, h); e(279, 4, 1, stripLen.toInt()); e(284, 3, 1, 1)
            e(274, 3, 1, 1)
            d.writeInt(0)
            raf.write(byteArrayOf(0, 16, 0, 16, 0, 16)); raf.write(byteArrayOf(0, 0, 0, 0, 0, 0))
            raf.write(ifd.toByteArray())
            raf.seek(4); raf.writeInt((8 + stripLen + 12).toInt())
        }
    }

    @Test fun convertSingleStripTiff4096x12000Rgb16InBoundedMemory() {
        smallHeap()
        for (deflate in listOf(false, true)) {
            val src = File(tmp.root, if (deflate) "big_deflate.tif" else "big_raw.tif")
            writeBigTiff(src, 4096, 12000, deflate)
            val input = FileImageInput(src)
            val png = File(tmp.root, if (deflate) "big_deflate.png" else "big_raw.png")
            val sampler = PeakSampler().also { it.start() }
            val t0 = System.nanoTime()
            BufferedOutputStream(FileOutputStream(png), 1 shl 16).use { TiffConverter.convert(input, it) }
            val t1 = System.nanoTime()
            TiffConverter.verify(input, { BufferedInputStream(FileInputStream(png), 1 shl 16) })
            val t2 = System.nanoTime()
            sampler.running = false
            val oi = PngReader.readInfo(FileInputStream(png))
            assertEquals(4096, oi.width); assertEquals(12000, oi.height); assertEquals("2/16", oi.formatKey)
            // independent expectation: regenerate rows from the formula and compare to the PNG
            PngReader.open(BufferedInputStream(FileInputStream(png))).use { r ->
                val exp = ByteArray(r.info.rowBytes); val got = ByteArray(r.info.rowBytes)
                for (y in 0 until 12000) { rowFor(9, y, exp.size, exp); r.readRow(got); assertTrue("row $y", exp.contentEquals(got)) }
            }
            println("TIFF->PNG 4096x12000 RGB16 ${if (deflate) "Deflate single strip" else "uncompressed single strip"}: decoded=${(4096L * 12000 * 6) shr 20} MB, " +
                "heap max=${Runtime.getRuntime().maxMemory() shr 20} MB, peak used<=${sampler.peak shr 20} MB, convert=${(t1 - t0) / 1_000_000_000} s, verify=${(t2 - t1) / 1_000_000_000} s")
            assertTrue(sampler.peak < 4096L * 12000 * 6 / 2)
        }
    }

    @Test fun orientedTiffTooLargeForMemoryFailsSafelyWithExplanation() {
        smallHeap()
        val src = File(tmp.root, "rot.tif")
        writeBigTiff(src, 4096, 12000, true)
        // patch Orientation (tag 274) from 1 to 6: find the IFD entry and rewrite its value
        RandomAccessFile(src, "rw").use { raf ->
            raf.seek(4); val ifd = raf.readInt().toLong()
            for (i in 0 until 11) { raf.seek(ifd + 2 + i * 12L); if (raf.readUnsignedShort() == 274) { raf.seek(ifd + 2 + i * 12L + 8); raf.writeShort(6) } }
        }
        try {
            BufferedOutputStream(FileOutputStream(File(tmp.root, "rot.png"))).use { TiffConverter.convert(FileImageInput(src), it) }
            fail("expected a clean out-of-memory error")
        } catch (e: EngineException) {
            assertEquals(ErrorCode.OUT_OF_MEMORY, e.code)
            println("Oriented-TIFF too large -> clean error: ${e.message}")
        }
    }
}
