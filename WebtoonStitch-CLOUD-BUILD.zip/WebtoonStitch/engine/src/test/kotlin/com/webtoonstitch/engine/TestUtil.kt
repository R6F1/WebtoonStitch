package com.webtoonstitch.engine

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.Random

object TestUtil {
    /** Deterministic pseudo-random raster in PNG byte layout, one ByteArray per row. */
    fun randomRows(info: RasterInfo, seed: Long, smooth: Boolean = false): List<ByteArray> {
        val r = Random(seed)
        return List(info.height) { y ->
            ByteArray(info.rowBytes).also {
                r.nextBytes(it)
                if (smooth) for (i in it.indices) it[i] = ((i / 3 + y) and 0xFF).toByte()
                // zero the padding bits of sub-byte rows so comparisons are exact
                val used = info.width * info.bitsPerPixel
                if (used % 8 != 0) it[it.size - 1] = (it[it.size - 1].toInt() and (0xFF shl (8 - used % 8))).toByte()
            }
        }
    }

    fun encodePng(info: RasterInfo, rows: List<ByteArray>, level: Int = 6): ByteArray {
        val bos = ByteArrayOutputStream()
        PngWriter(bos, info, level).use { w -> rows.forEach(w::writeRow); w.finish() }
        return bos.toByteArray()
    }

    fun decodePng(bytes: ByteArray): Pair<RasterInfo, List<ByteArray>> =
        PngReader.open(ByteArrayInputStream(bytes)).use { r ->
            val rows = List(r.info.height) { ByteArray(r.info.rowBytes).also(r::readRow) }
            r.info to rows
        }

    fun assertRowsEqual(expected: List<ByteArray>, actual: List<ByteArray>, what: String = "") {
        org.junit.Assert.assertEquals("$what row count", expected.size, actual.size)
        for (y in expected.indices) {
            if (!expected[y].contentEquals(actual[y])) {
                val x = expected[y].indices.first { expected[y][it] != actual[y][it] }
                org.junit.Assert.fail("$what: first difference at row $y, byte $x (expected ${expected[y][x].toInt() and 255}, got ${actual[y][x].toInt() and 255})")
            }
        }
    }
}
