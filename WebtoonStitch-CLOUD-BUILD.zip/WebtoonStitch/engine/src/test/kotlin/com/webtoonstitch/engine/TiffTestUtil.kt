package com.webtoonstitch.engine

import java.io.ByteArrayOutputStream
import java.util.zip.Deflater

/** Minimal independent TIFF *writer* used only to build test fixtures with exact control over tags. */
class TiffSpec(
    var w: Int, var h: Int, var spp: Int, var bps: Int, var photometric: Int,
    var compression: Int = 1, var predictor: Int = 1, var orientation: Int = 1, var le: Boolean = false,
    var extra: Int? = null, var icc: ByteArray? = null, var colormap: IntArray? = null,
    var rps: Int = h, var sampleFormat: Int? = null, var extraPages: Int = 0, var planar: Int = 1,
    var tiled: Boolean = false, var magic: Int = 42, var subfileType: Long? = null
)

object TiffTestUtil {
    /** [rows] hold the *file* sample values in big-endian PNG-style byte layout (what a TIFF decoder must return). */
    fun write(s: TiffSpec, rows: List<ByteArray>): ByteArray =
        writeMulti(List(1 + s.extraPages) { s to rows })

    /** A real multi-page file: each page has its own spec (size, depth, colour type, ICC ...) and its own pixel rows. */
    fun writeMulti(pages: List<Pair<TiffSpec, List<ByteArray>>>): ByteArray {
        val s0 = pages[0].first
        val bos = ByteArrayOutputStream()
        var s = s0
        fun u16(v: Int) { if (s.le) { bos.write(v); bos.write(v shr 8) } else { bos.write(v shr 8); bos.write(v) } }
        fun u32(v: Long) { if (s.le) { u16((v and 0xFFFF).toInt()); u16((v shr 16).toInt() and 0xFFFF) } else { u16((v shr 16).toInt() and 0xFFFF); u16((v and 0xFFFF).toInt()) } }
        bos.write(if (s.le) 'I'.code else 'M'.code); bos.write(if (s.le) 'I'.code else 'M'.code)
        u16(s.magic); u32(0)
        class E(val tag: Int, val type: Int, val count: Int, val data: ByteArray)
        fun shorts(vararg v: Int) = ByteArrayOutputStream().also { o -> for (x in v) if (s.le) { o.write(x); o.write(x shr 8) } else { o.write(x shr 8); o.write(x) } }.toByteArray()
        fun longs(v: LongArray) = ByteArrayOutputStream().also { o -> for (x in v) for (k in 0..3) o.write(((if (s.le) x shr (8 * k) else x shr (8 * (3 - k))) and 255).toInt()) }.toByteArray()
        val ifdOffsets = ArrayList<Long>(); val nextPos = ArrayList<Int>()
        for ((spec, rows) in pages) {
            s = spec
            val nStrips = (s.h + s.rps - 1) / s.rps
            val offs = LongArray(nStrips); val cnts = LongArray(nStrips)
            for (st in 0 until nStrips) {
                val raw = ByteArrayOutputStream()
                for (y in st * s.rps until minOf(s.h, (st + 1) * s.rps)) raw.write(encodeRow(s, rows[y]))
                val data = compress(s.compression, raw.toByteArray())
                offs[st] = bos.size().toLong(); cnts[st] = data.size.toLong()
                bos.write(data); if (bos.size() % 2 == 1) bos.write(0)
            }
            val es = ArrayList<E>()
            es += E(256, 4, 1, longs(longArrayOf(s.w.toLong()))); es += E(257, 4, 1, longs(longArrayOf(s.h.toLong())))
            es += E(258, 3, s.spp, shorts(*IntArray(s.spp) { s.bps }))
            es += E(259, 3, 1, shorts(s.compression)); es += E(262, 3, 1, shorts(s.photometric))
            es += E(273, 4, nStrips, longs(offs)); es += E(274, 3, 1, shorts(s.orientation)); es += E(277, 3, 1, shorts(s.spp))
            es += E(278, 4, 1, longs(longArrayOf(s.rps.toLong()))); es += E(279, 4, nStrips, longs(cnts)); es += E(284, 3, 1, shorts(s.planar))
            if (s.predictor != 1) es += E(317, 3, 1, shorts(s.predictor))
            s.colormap?.let { es += E(320, 3, it.size, shorts(*it)) }
            s.extra?.let { es += E(338, 3, 1, shorts(it)) }
            s.sampleFormat?.let { es += E(339, 3, s.spp, shorts(*IntArray(s.spp) { _ -> it })) }
            s.icc?.let { es += E(34675, 7, it.size, it) }
            s.subfileType?.let { es += E(254, 4, 1, longs(longArrayOf(it))) }
            if (s.tiled) { es += E(322, 3, 1, shorts(16)); es += E(323, 3, 1, shorts(16)) }
            es.sortBy { it.tag }
            val ext = HashMap<E, Long>()
            for (e in es) if (e.data.size > 4) { ext[e] = bos.size().toLong(); bos.write(e.data); if (bos.size() % 2 == 1) bos.write(0) }
            ifdOffsets += bos.size().toLong()
            u16(es.size)
            for (e in es) {
                u16(e.tag); u16(e.type); u32(e.count.toLong())
                if (e.data.size > 4) u32(ext[e]!!) else { bos.write(e.data); repeat(4 - e.data.size) { bos.write(0) } }
            }
            nextPos += bos.size()
            u32(0)  // next IFD, patched below
        }
        val out = bos.toByteArray()
        s = s0
        fun patch(pos: Int, v: Long) { for (k in 0..3) out[pos + k] = ((if (s.le) v shr (8 * k) else v shr (8 * (3 - k))) and 255).toByte() }
        patch(4, ifdOffsets[0])
        for (p in 0 until pages.size - 1) patch(nextPos[p], ifdOffsets[p + 1])
        return out
    }

    private fun encodeRow(s: TiffSpec, row: ByteArray): ByteArray {
        val r = row.copyOf()
        val ch = s.spp
        if (s.bps == 16 && s.le) { var i = 0; while (i < r.size) { val t = r[i]; r[i] = r[i + 1]; r[i + 1] = t; i += 2 } }
        if (s.predictor == 2) {
            if (s.bps == 8) { for (i in r.size - 1 downTo ch) r[i] = (r[i] - r[i - ch]).toByte() }
            else {
                fun g(o: Int) = if (s.le) (r[o].toInt() and 255) or ((r[o + 1].toInt() and 255) shl 8) else ((r[o].toInt() and 255) shl 8) or (r[o + 1].toInt() and 255)
                fun p(o: Int, v: Int) { if (s.le) { r[o] = v.toByte(); r[o + 1] = (v shr 8).toByte() } else { r[o] = (v shr 8).toByte(); r[o + 1] = v.toByte() } }
                for (i in s.w * ch - 1 downTo ch) p(i * 2, (g(i * 2) - g((i - ch) * 2)) and 0xFFFF)
            }
        }
        return r
    }

    private fun compress(c: Int, d: ByteArray): ByteArray = when (c) {
        1 -> d
        8, 32946 -> { val df = Deflater(6); df.setInput(d); df.finish(); val o = ByteArrayOutputStream(); val b = ByteArray(8192); while (!df.finished()) o.write(b, 0, df.deflate(b)); df.end(); o.toByteArray() }
        32773 -> packBits(d)
        else -> d  // unsupported codes (e.g. JPEG=7): payload is irrelevant, decoder must reject before reading it
    }

    private fun packBits(d: ByteArray): ByteArray {
        val o = ByteArrayOutputStream(); var i = 0
        while (i < d.size) {
            var run = 1
            while (i + run < d.size && run < 128 && d[i + run] == d[i]) run++
            if (run >= 2) { o.write(257 - run); o.write(d[i].toInt()); i += run }
            else {
                var lit = 1
                while (i + lit < d.size && lit < 128 && (i + lit + 1 >= d.size || d[i + lit] != d[i + lit + 1])) lit++
                o.write(lit - 1); o.write(d, i, lit); i += lit
            }
        }
        return o.toByteArray()
    }

    fun input(name: String, bytes: ByteArray, dir: java.io.File): FileImageInput {
        val f = java.io.File(dir, name); f.writeBytes(bytes); return FileImageInput(f)
    }

    fun decodeToRows(input: ImageInput): Pair<RasterInfo, List<ByteArray>> =
        Tiff.open(input).use { r -> r.info to List(r.info.height) { ByteArray(r.info.rowBytes).also(r::readRow) } }
}
