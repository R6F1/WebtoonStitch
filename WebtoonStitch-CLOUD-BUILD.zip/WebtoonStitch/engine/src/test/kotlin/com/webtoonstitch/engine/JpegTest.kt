package com.webtoonstitch.engine

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.awt.image.BufferedImage
import java.io.*
import java.security.MessageDigest
import java.util.Random
import java.util.zip.Inflater
import javax.imageio.ImageIO

/**
 * JPEG support, tested with the two files the user supplied:
 *   samples/itloads.png      - a genuine PNG (RGB 8-bit, Adobe RGB ICC profile)      -> already worked
 *   samples/doesnt_load.png  - a JPEG (baseline, 4:2:0, no profile) named ".png"      -> used to fail
 * plus ~40 fixtures written by Pillow/libjpeg-turbo (scripts/make-jpeg-fixtures.py).
 *
 * Independent oracles, neither of which shares code with the engine:
 *   1. the JDK's ImageIO decoders (libjpeg 6b for JPEG, java PNG decoder for PNG), compared pixel for pixel;
 *   2. SHA-256 checksums of Pillow/libjpeg-turbo decodes, stored in golden.txt.
 */
class JpegTest {
    @get:Rule val tmp = TemporaryFolder()

    // ------------------------------------------------------------------------------------------------ helpers

    private fun res(path: String): ByteArray =
        (JpegTest::class.java.getResourceAsStream("/$path") ?: fail("missing test resource $path").let { null })!!.use { it.readBytes() }

    private class Pix(val w: Int, val h: Int, val bands: Int, val data: ByteArray) {
        fun row(y: Int) = data.copyOfRange(y * w * bands, (y + 1) * w * bands)
        fun sha() = MessageDigest.getInstance("SHA-256").digest(data).joinToString("") { "%02x".format(it) }
    }

    /** Oracle: JDK ImageIO. Raw raster samples, no colour conversion applied by us. */
    private fun imageIo(bytes: ByteArray): Pix {
        val img = ImageIO.read(ByteArrayInputStream(bytes)) ?: fail("ImageIO could not read the file").let { null }!!
        val r = img.raster
        val ia = IntArray(r.width * r.height * r.numBands)
        r.getPixels(0, 0, r.width, r.height, ia)
        return Pix(r.width, r.height, r.numBands, ByteArray(ia.size) { ia[it].toByte() })
    }

    private fun engine(input: ImageInput): Pix = ImageDecoders.open(input).use { src ->
        val i = src.info
        val out = ByteArray(i.rowBytes * i.height)
        val row = ByteArray(i.rowBytes)
        for (y in 0 until i.height) { src.readRow(row); System.arraycopy(row, 0, out, y * i.rowBytes, i.rowBytes) }
        Pix(i.width, i.height, i.channels, out)
    }

    private fun engine(bytes: ByteArray, name: String = "x.png") = engine(BytesInput(name, bytes))

    private class BytesInput(override val name: String, val bytes: ByteArray) : ImageInput {
        override fun openStream(): InputStream = ByteArrayInputStream(bytes)
        override fun openRandomAccess(): RandomAccess = object : RandomAccess {
            override val length = bytes.size.toLong()
            override fun readAt(position: Long, buf: ByteArray, off: Int, len: Int): Int {
                if (position >= bytes.size) return -1
                val n = minOf(len.toLong(), bytes.size - position).toInt(); System.arraycopy(bytes, position.toInt(), buf, off, n); return n
            }
            override fun close() {}
        }
    }

    private fun assertSamePixels(expected: Pix, actual: Pix, what: String) {
        assertEquals("$what: width", expected.w, actual.w); assertEquals("$what: height", expected.h, actual.h)
        assertEquals("$what: channels", expected.bands, actual.bands)
        if (!expected.data.contentEquals(actual.data)) {
            val i = expected.data.indices.first { expected.data[it] != actual.data[it] }
            val px = i / expected.bands
            val total = expected.data.indices.count { expected.data[it] != actual.data[it] }
            fail("$what: $total of ${expected.data.size} samples differ; first at x=${px % expected.w}, y=${px / expected.w}, band ${i % expected.bands} " +
                "(expected ${expected.data[i].toInt() and 255}, got ${actual.data[i].toInt() and 255})")
        }
    }

    private fun golden(path: String): Map<String, List<String>> =
        String(res(path)).lines().filter { it.isNotBlank() && !it.startsWith("#") }.map { it.split(" ") }.associateBy { it[0] }

    private fun file(dir: File, name: String, bytes: ByteArray) = FileImageInput(File(dir, name).apply { writeBytes(bytes) })

    private fun fails(block: () -> Unit): EngineException = try { block(); fail("expected an EngineException"); throw AssertionError() } catch (e: EngineException) { e }

    /** Output folder with the same temp -> rename contract as the Android implementation. */
    private class DirFolder(val dir: File) : OutputFolder {
        override fun exists(name: String) = File(dir, name).exists()
        override fun removeStaleTemporaries() { dir.listFiles { f -> f.name.contains(TEMP_SUFFIX) }?.forEach { it.delete() } }
        override fun createTemporary(finalNameHint: String): OutputFile {
            val f = File(dir, finalNameHint + TEMP_SUFFIX); f.createNewFile()
            return object : OutputFile {
                override fun openOutput(): OutputStream = FileOutputStream(f)
                override fun openInput(): InputStream = FileInputStream(f)
                override fun commit(finalName: String) { check(!File(dir, finalName).exists()); check(f.renameTo(File(dir, finalName))) }
                override fun delete() { f.delete() }
            }
        }
    }

    private fun jpegBytes(w: Int, h: Int, seed: Long): ByteArray {
        val img = BufferedImage(w, h, BufferedImage.TYPE_INT_RGB); val r = Random(seed)
        for (y in 0 until h) for (x in 0 until w) img.setRGB(x, y, ((x * 3 + y) and 255 shl 16) or ((y * 5 and 255) shl 8) or (r.nextInt(60) + x % 190))
        return ByteArrayOutputStream().also { check(ImageIO.write(img, "jpg", it)) }.toByteArray()
    }

    // ------------------------------------------------------------------------------------------------ 1. what the files really are

    @Test fun signaturesDecideTheFormatNotTheExtension() {
        val png = res("samples/itloads.png"); val jpg = res("samples/doesnt_load.png")
        assertArrayEquals(byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47), png.copyOf(4))
        assertArrayEquals(byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte()), jpg.copyOf(3))
        val d = tmp.newFolder()
        assertEquals(DetectedFormat.PNG, ImageDecoders.detect(file(d, "itloads.png", png)))
        assertEquals(DetectedFormat.JPEG, ImageDecoders.detect(file(d, "doesnt_load.png", jpg)))          // ".png" but JPEG inside
        assertEquals(DetectedFormat.PNG, ImageDecoders.detect(file(d, "really_a_png.jpg", png)))          // ".jpg" but PNG inside
        assertEquals(DetectedFormat.UNKNOWN, ImageDecoders.detect(file(d, "w.png", "RIFF....WEBPVP8 ".toByteArray())))
        assertNull(ImageDecoders.label(DetectedFormat.PNG, "itloads.png"))
        assertEquals("JPEG (saved as .png)", ImageDecoders.label(DetectedFormat.JPEG, "doesnt_load.png"))
        assertEquals("JPEG (saved as .png)", ImageDecoders.label(DetectedFormat.JPEG, "UPPER.PNG"))
        assertEquals("JPEG", ImageDecoders.label(DetectedFormat.JPEG, "photo.jpg"))
    }

    // ------------------------------------------------------------------------------------------------ 2. the two user samples

    @Test fun workingPngSampleStillDecodesExactly() {
        val bytes = res("samples/itloads.png")
        val e = engine(bytes)
        assertEquals(940, e.w); assertEquals(1606, e.h); assertEquals(3, e.bands)
        assertSamePixels(imageIo(bytes), e, "itloads.png vs ImageIO")
        assertEquals("Pillow golden", golden("samples/golden.txt").getValue("itloads.png")[4], e.sha())
        val info = ImageDecoders.inspect(BytesInput("itloads.png", bytes))
        assertEquals(listOf("iCCP"), info.colorChunks.map { it.type })       // Adobe RGB profile still carried
    }

    @Test fun jpegSampleIsRecognisedAndDecodedExactlyLikeTheReferenceDecoders() {
        val bytes = res("samples/doesnt_load.png")
        val info = ImageDecoders.inspect(BytesInput("doesnt_load.png", bytes))
        assertEquals(940, info.width); assertEquals(1606, info.height)
        assertEquals(2, info.colorType); assertEquals(8, info.bitDepth); assertTrue(info.colorChunks.isEmpty())
        assertEquals("2/8", info.formatKey)
        val e = engine(bytes, "doesnt_load.png")
        assertSamePixels(imageIo(bytes), e, "doesnt_load.png: engine vs ImageIO (libjpeg 6b)")
        assertEquals("doesnt_load.png: engine vs Pillow/libjpeg-turbo SHA-256", golden("samples/golden.txt").getValue("doesnt_load.png")[4], e.sha())
    }

    // ------------------------------------------------------------------------------------------------ 3. decoder correctness on many files

    @Test fun everyFixtureMatchesImageIoAndPillowGoldenBitForBit() {
        val g = golden("jpeg/golden.txt")
        assertTrue("expected the full fixture set", g.size >= 35)
        for ((name, f) in g) {
            val bytes = res("jpeg/$name")
            val e = engine(bytes, name)
            assertEquals("$name width", f[2].toInt(), e.w); assertEquals("$name height", f[3].toInt(), e.h)
            assertEquals("$name channels", if (f[1] == "L") 1 else 3, e.bands)
            assertSamePixels(imageIo(bytes), e, "$name vs ImageIO")
            assertEquals("$name vs Pillow SHA-256", f[4], e.sha())
        }
    }

    @Test fun fixtureSetReallyCoversTheCodePaths() {
        fun hasMarker(b: ByteArray, m: Int) = (0 until b.size - 1).any { b[it] == 0xFF.toByte() && (b[it + 1].toInt() and 255) == m }
        assertTrue(hasMarker(res("jpeg/restart_420.jpg"), 0xDD)); assertTrue(hasMarker(res("jpeg/restart_444.jpg"), 0xDD))
        assertTrue(hasMarker(res("jpeg/restart_420.jpg"), 0xD0))                                  // restart markers inside the data
        assertTrue(hasMarker(res("jpeg/reject_progressive.jpg"), 0xC2))
        assertTrue(hasMarker(res("jpeg/s420_64x48.jpg"), 0xC0))
        // sampling factors written in the SOF header: 4:2:0 = Y 2x2, 4:2:2 = Y 2x1, 4:4:4 = Y 1x1
        fun yFactors(n: String): Int { val b = res("jpeg/$n"); val i = (0 until b.size - 1).first { b[it] == 0xFF.toByte() && b[it + 1] == 0xC0.toByte() }; return b[i + 11].toInt() and 255 }
        assertEquals(0x22, yFactors("s420_64x48.jpg")); assertEquals(0x21, yFactors("s422_64x48.jpg")); assertEquals(0x11, yFactors("s444_64x48.jpg"))
    }

    // ------------------------------------------------------------------------------------------------ 4. refusals are explicit, never degraded output

    @Test fun unsupportedJpegVariantsAreRejectedWithAReason() {
        val d = tmp.newFolder()
        fun reject(name: String, needle: String) {
            val e = fails { ImageDecoders.inspect(file(d, name, res("jpeg/$name"))) }
            assertEquals(name, ErrorCode.UNSUPPORTED, e.code); assertTrue("$name: ${e.message}", e.message!!.contains(needle, ignoreCase = true))
        }
        reject("reject_progressive.jpg", "progressive"); reject("reject_cmyk.jpg", "CMYK"); reject("reject_exif_orientation6.jpg", "orientation 6")
    }

    @Test fun truncatedJpegIsNeverPaddedAndNoOutputSurvives() {
        val full = res("samples/doesnt_load.png"); val d = tmp.newFolder(); val out = tmp.newFolder()
        for (cut in listOf(full.size / 2, full.size * 9 / 10, 300)) {
            val input = file(d, "t$cut.png", full.copyOf(cut))
            val e = fails { Jobs.stitch(listOf(input), DirFolder(out)) }
            assertEquals("cut at $cut", ErrorCode.UNREADABLE, e.code)
            assertTrue(e.message!!, e.message!!.contains("truncated", true) || e.message!!.contains("corrupt", true))
            assertEquals("nothing may be left behind: ${out.list()!!.toList()}", 0, out.list()!!.size)
        }
        // only the final EOI marker missing: all image data is present, so it still decodes (identically)
        assertSamePixels(engine(full), engine(full.copyOf(full.size - 2)), "missing EOI")
    }

    // ------------------------------------------------------------------------------------------------ 5. thumbnails

    @Test fun thumbnailOfTheJpegSampleIsBuiltFromTheExactDecodedPixels() {
        val bytes = res("samples/doesnt_load.png")
        val ref = imageIo(bytes)
        val t = ImageDecoders.open(BytesInput("doesnt_load.png", bytes)).use { Thumbnails.render(it, 256) }
        val step = (maxOf(940, 1606) + 255) / 256
        assertEquals((940 + step - 1) / step, t.width); assertEquals((1606 + step - 1) / step, t.height)
        var distinct = HashSet<Int>()
        for (oy in 0 until t.height) for (ox in 0 until t.width) {
            val o = ((oy * step) * 940 + ox * step) * 3
            val want = (255 shl 24) or ((ref.data[o].toInt() and 255) shl 16) or ((ref.data[o + 1].toInt() and 255) shl 8) or (ref.data[o + 2].toInt() and 255)
            assertEquals("thumbnail pixel ($ox,$oy)", want, t.argb[oy * t.width + ox]); distinct += want
        }
        assertTrue("thumbnail must show real image content, not a flat placeholder (${distinct.size} colours)", distinct.size > 500)
    }

    // ------------------------------------------------------------------------------------------------ 6. stitching

    private fun stitchTo(out: File, vararg inputs: ImageInput) = Jobs.stitch(inputs.toList(), DirFolder(out))

    @Test fun stitchingTheJpegSampleAloneWritesItsExactDecodedPixelsAsPng() {
        val bytes = res("samples/doesnt_load.png"); val d = tmp.newFolder(); val out = tmp.newFolder()
        val r = stitchTo(out, file(d, "doesnt_load.png", bytes))
        assertEquals(940, r.width); assertEquals(1606, r.height)
        assertEquals(listOf(r.outputName), out.list()!!.toList())                          // exactly one file, no leftovers
        val png = File(out, r.outputName).readBytes()
        assertArrayEquals(byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A), png.copyOf(8))
        val (info, _) = TestUtil.decodePng(png)
        assertEquals(2, info.colorType); assertEquals(8, info.bitDepth)                      // RGB, 8-bit, no alpha invented
        // independent PNG decoder (ImageIO) against independent JPEG decoder (ImageIO): the PNG holds the decoded JPEG pixels
        assertSamePixels(imageIo(bytes), imageIo(png), "output PNG vs decoded JPEG (ImageIO both sides)")
        assertEquals("Pillow golden", golden("samples/golden.txt").getValue("doesnt_load.png")[4], imageIo(png).sha())
        assertTrue("source untouched", File(d, "doesnt_load.png").readBytes().contentEquals(bytes))
    }

    @Test fun stitchingTwoJpegsPlacesEveryPixelInTheRightPosition() {
        val a = jpegBytes(940, 300, 11); val b = res("samples/doesnt_load.png")
        val d = tmp.newFolder(); val out = tmp.newFolder()
        // names chosen so natural order is 2 (generated, 300 px) then 10 (sample, 1606 px), regardless of the order given
        val r = stitchTo(out, file(d, "10.png", b), file(d, "2.png", a))
        assertEquals("2-10.png", r.outputName); assertEquals(1906, r.height)
        val got = imageIo(File(out, r.outputName).readBytes())
        val pa = imageIo(a); val pb = imageIo(b)
        assertEquals(1906, got.h)
        for (y in 0 until 300) assertArrayEquals("row $y (from 2.png)", pa.row(y), got.row(y))
        for (y in 0 until 1606) assertArrayEquals("row ${300 + y} (from 10.png)", pb.row(y), got.row(300 + y))
    }

    @Test fun aGenuinePngAndAJpegWithTheSameColourInterpretationStitchTogether() {
        // The realistic folder: files the app produced earlier (plain RGB PNG) next to JPEG-disguised-as-PNG files.
        val jpg = res("samples/doesnt_load.png"); val i = RasterInfo(940, 200, 2, 8)
        val rows = TestUtil.randomRows(i, 5, smooth = true)
        val d = tmp.newFolder(); val out = tmp.newFolder()
        val r = stitchTo(out, file(d, "01.png", TestUtil.encodePng(i, rows)), file(d, "02.png", jpg))
        assertEquals(1806, r.height)
        val got = TestUtil.decodePng(File(out, r.outputName).readBytes()).second
        TestUtil.assertRowsEqual(rows, got.subList(0, 200), "PNG part unchanged")
        val pj = engine(jpg)
        for (y in 0 until 1606) assertArrayEquals("jpeg row $y", pj.row(y), got[200 + y])
    }

    @Test fun pngWithAdobeProfileAndUntaggedJpegAreNotMixedSilently() {
        val d = tmp.newFolder()
        val a = file(d, "a.png", res("samples/itloads.png")); val b = file(d, "b.png", res("samples/doesnt_load.png"))
        val e = fails { Stitcher.plan(listOf(a, b)) }
        assertEquals(ErrorCode.FORMAT_MISMATCH, e.code); assertTrue(e.message!!, e.message!!.contains("colour profile", true))
        assertNotEquals(ImageDecoders.inspect(a).formatKey, ImageDecoders.inspect(b).formatKey)   // the picker detects it too
    }

    @Test fun existingPngBehaviourIsUnchangedForTheWorkingSample() {
        val bytes = res("samples/itloads.png"); val d = tmp.newFolder(); val out = tmp.newFolder()
        val r = stitchTo(out, file(d, "itloads.png", bytes))
        val png = File(out, r.outputName).readBytes()
        assertSamePixels(imageIo(bytes), imageIo(png), "PNG -> stitched PNG")
        assertEquals("Pillow golden", golden("samples/golden.txt").getValue("itloads.png")[4], imageIo(png).sha())
        assertEquals(ImageDecoders.inspect(BytesInput("a", bytes)).colorChunks, ImageDecoders.inspect(BytesInput("b", png)).colorChunks)   // iCCP kept byte for byte
    }

    @Test fun jpegIccProfileIsCarriedIntoThePng() {
        val jpg = res("jpeg/icc_srgb_420.jpg"); val profile = res("jpeg/profile.icc"); val d = tmp.newFolder(); val out = tmp.newFolder()
        val r = stitchTo(out, file(d, "p.png", jpg))
        val info = TestUtil.decodePng(File(out, r.outputName).readBytes()).first
        val chunk = info.colorChunks.single { it.type == "iCCP" }.data
        val z = chunk.indexOf(0.toByte()); val inf = Inflater().apply { setInput(chunk, z + 2, chunk.size - z - 2) }
        val buf = ByteArray(profile.size + 16); val n = inf.inflate(buf); inf.end()
        assertArrayEquals(profile, buf.copyOf(n))
        assertSamePixels(imageIo(jpg), imageIo(File(out, r.outputName).readBytes()), "ICC jpeg -> png pixels")
    }

    @Test fun grayJpegBecomesEightBitGrayPng() {
        val jpg = res("jpeg/gray_101x67.jpg"); val d = tmp.newFolder(); val out = tmp.newFolder()
        val r = stitchTo(out, file(d, "g.png", jpg))
        val (info, _) = TestUtil.decodePng(File(out, r.outputName).readBytes())
        assertEquals(0, info.colorType); assertEquals(8, info.bitDepth)
        assertSamePixels(imageIo(jpg), imageIo(File(out, r.outputName).readBytes()), "gray")
    }
}
