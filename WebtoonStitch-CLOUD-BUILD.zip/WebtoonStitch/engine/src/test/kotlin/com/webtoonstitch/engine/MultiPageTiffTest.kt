package com.webtoonstitch.engine

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.awt.color.ColorSpace
import java.awt.color.ICC_Profile
import java.io.*
import javax.imageio.ImageIO

/** Multi-page TIFF: every page becomes its own lossless PNG; stitching still needs single-page files. */
class MultiPageTiffTest {
    @get:Rule val tmp = TemporaryFolder()

    private class Dir(val dir: File) : OutputFolder {
        override fun exists(name: String) = File(dir, name).exists()
        override fun removeStaleTemporaries() { dir.listFiles { f -> f.name.contains(TEMP_SUFFIX) }?.forEach { it.delete() } }
        override fun createTemporary(finalNameHint: String): OutputFile {
            val f = File(dir, finalNameHint + TEMP_SUFFIX); f.createNewFile()
            return object : OutputFile {
                override fun openOutput(): OutputStream = FileOutputStream(f)
                override fun openInput(): InputStream = FileInputStream(f)
                override fun commit(finalName: String) { check(f.renameTo(File(dir, finalName))) }
                override fun delete() { f.delete() }
            }
        }
    }

    private fun rows(w: Int, h: Int, ct: Int, depth: Int, seed: Long) = TestUtil.randomRows(RasterInfo(w, h, ct, depth), seed)

    /** Three pages that differ in size, bit depth, colour type, alpha and ICC. */
    private fun mixed(): Triple<ByteArray, List<Pair<RasterInfo, List<ByteArray>>>, ByteArray> {
        val icc = ICC_Profile.getInstance(ColorSpace.CS_sRGB).data
        val p1 = TiffSpec(31, 17, 3, 8, 2, compression = 8, predictor = 2, icc = icc)
        val p2 = TiffSpec(9, 23, 1, 16, 1, compression = 8, le = false)
        val p3 = TiffSpec(12, 5, 4, 8, 2, extra = 2, compression = 32773)
        val r1 = rows(31, 17, 2, 8, 1); val r2 = rows(9, 23, 0, 16, 2); val r3 = rows(12, 5, 6, 8, 3)
        val bytes = TiffTestUtil.writeMulti(listOf(p1 to r1, p2 to r2, p3 to r3))
        val expected = listOf(RasterInfo(31, 17, 2, 8) to r1, RasterInfo(9, 23, 0, 16) to r2, RasterInfo(12, 5, 6, 8) to r3)
        return Triple(bytes, expected, icc)
    }

    @Test fun everyPageIsConvertedSeparatelyAndExactly() {
        val (bytes, expected, icc) = mixed()
        val input = TiffTestUtil.input("001-008.tif", bytes, tmp.root)
        assertEquals(3, Tiff.pageCount(input))
        val out = tmp.newFolder()
        val done = ArrayList<List<JobOutcome>>()
        val res = Jobs.convertTiffs(listOf(input), Dir(out), onFileDone = { done += it })
        assertEquals(1, done.size); assertEquals(3, res.size)
        assertEquals(listOf("001-008_p001.png", "001-008_p002.png", "001-008_p003.png"), out.list()!!.sorted())
        for ((i, o) in res.withIndex()) {
            o as JobOutcome.Success
            assertEquals(i + 1, o.page); assertEquals(3, o.pageCount)
            val (info, got) = TestUtil.decodePng(File(out, o.outputName).readBytes())
            assertEquals(expected[i].first.width, info.width); assertEquals(expected[i].first.height, info.height)
            assertEquals(expected[i].first.colorType, info.colorType); assertEquals(expected[i].first.bitDepth, info.bitDepth)
            TestUtil.assertRowsEqual(expected[i].second, got, "page ${i + 1}")
            if (i == 0) assertEquals(1, info.colorChunks.count { it.type == "iCCP" }) else assertEquals(0, info.colorChunks.count { it.type == "iCCP" })
        }
        // the embedded profile of page 1 is carried over unchanged
        val png0 = File(out, "001-008_p001.png").readBytes()
        val iccp = PngReader.open(ByteArrayInputStream(png0)).use { r -> r.info.colorChunks.first { it.type == "iCCP" } }
        val z = iccp.data; val nul = z.indexOf(0)
        val inf = java.util.zip.Inflater().also { it.setInput(z, nul + 2, z.size - nul - 2) }
        val dec = ByteArray(icc.size + 16); val n = inf.inflate(dec)
        assertArrayEquals(icc, dec.copyOf(n))
    }

    @Test fun pagesMatchTheJdkImageIoDecoder() {
        val (bytes, _, _) = mixed()
        val input = TiffTestUtil.input("m.tif", bytes, tmp.root)
        val reader = ImageIO.getImageReadersByFormatName("tiff").next()
        reader.input = ImageIO.createImageInputStream(ByteArrayInputStream(bytes))
        assertEquals(3, reader.getNumImages(true))
        for (p in 0 until 3) {
            val bi = reader.read(p)
            val (info, got) = Tiff.openPage(input, p).use { r -> r.info to List(r.info.height) { ByteArray(r.info.rowBytes).also(r::readRow) } }
            assertEquals(bi.width, info.width); assertEquals(bi.height, info.height)
            if (info.bitDepth == 8 && info.colorType == 2) {
                for (y in 0 until info.height) for (x in 0 until info.width) {
                    val rgb = bi.getRGB(x, y)
                    assertEquals((rgb shr 16) and 255, got[y][x * 3].toInt() and 255)
                    assertEquals((rgb shr 8) and 255, got[y][x * 3 + 1].toInt() and 255)
                    assertEquals(rgb and 255, got[y][x * 3 + 2].toInt() and 255)
                }
            }
        }
    }

    @Test fun singlePageKeepsPlainNameAndStillWorks() {
        val input = TiffTestUtil.input("071-079.tif", TiffTestUtil.write(TiffSpec(8, 8, 1, 8, 1), rows(8, 8, 0, 8, 7)), tmp.root)
        assertEquals(1, Tiff.pageCount(input))
        val out = tmp.newFolder()
        val res = Jobs.convertTiffs(listOf(input), Dir(out))
        assertEquals("071-079.png", (res.single() as JobOutcome.Success).outputName)
        assertEquals(listOf("071-079.png"), out.list()!!.toList())
    }

    @Test fun stitchingAndOpenStillRejectMultiPage() {
        val (bytes, _, _) = mixed()
        val input = TiffTestUtil.input("m.tif", bytes, tmp.root)
        val e = try { Tiff.open(input).close(); null } catch (x: EngineException) { x }!!
        assertEquals(ErrorCode.MULTI_PAGE, e.code)
    }

    @Test fun oneBadPageFailsAloneAndOthersConvert() {
        val good = TiffSpec(8, 8, 1, 8, 1); val bad = TiffSpec(8, 8, 4, 8, 5)   // CMYK page
        val bytes = TiffTestUtil.writeMulti(listOf(good to rows(8, 8, 0, 8, 1), bad to rows(8, 8, 6, 8, 2), good to rows(8, 8, 0, 8, 3)))
        val input = TiffTestUtil.input("x.tif", bytes, tmp.root)
        val out = tmp.newFolder()
        val res = Jobs.convertTiffs(listOf(input), Dir(out))
        assertEquals(3, res.size)
        assertTrue(res[0] is JobOutcome.Success); assertTrue(res[2] is JobOutcome.Success)
        val f = res[1] as JobOutcome.Failure
        assertEquals(2, f.page); assertEquals(ErrorCode.UNSUPPORTED, f.code)
        assertEquals(listOf("x_p001.png", "x_p003.png"), out.list()!!.sorted())
    }

    @Test fun namesAreCollisionSafe() {
        val one = rows(4, 4, 0, 8, 1)
        val s = TiffSpec(4, 4, 1, 8, 1)
        val a = TiffTestUtil.input("a.tif", TiffTestUtil.writeMulti(listOf(s to one, s to one)), tmp.root)
        val clash = TiffTestUtil.input("a_p001.tif", TiffTestUtil.write(s, one), tmp.root)   // single page whose output would be a_p001.png
        val out = tmp.newFolder(); File(out, "a_p002.png").writeText("keep")
        val res = Jobs.convertTiffs(listOf(a, clash), Dir(out)).map { (it as JobOutcome.Success).outputName }
        assertEquals(listOf("a_p001.png", "a_p002 (1).png", "a_p001 (1).png"), res)
        assertEquals("keep", File(out, "a_p002.png").readText())
        assertEquals(4, out.list()!!.size)
    }

    @Test fun pageNamesArePaddedAndSortable() {
        assertEquals("a.png", OutputNaming.tiffPageName("a.tif", 1, 1))
        assertEquals("a_p001.png", OutputNaming.tiffPageName("a.tif", 1, 2))
        assertEquals("a_p1000.png", OutputNaming.tiffPageName("a.tif", 1000, 1200))
        assertEquals("a_p0007.png", OutputNaming.tiffPageName("a.tif", 7, 1200))
    }

    @Test fun brokenDirectoryChainIsAnError() {
        val s = TiffSpec(4, 4, 1, 8, 1)
        val bytes = TiffTestUtil.writeMulti(listOf(s to rows(4, 4, 0, 8, 1), s to rows(4, 4, 0, 8, 1)))
        // make the second IFD's next pointer point back to the first IFD (a loop)
        val first = ((bytes[4].toInt() and 255) shl 24) or ((bytes[5].toInt() and 255) shl 16) or ((bytes[6].toInt() and 255) shl 8) or (bytes[7].toInt() and 255)
        val cnt = ((bytes[first].toInt() and 255) shl 8) or (bytes[first + 1].toInt() and 255)
        val next1 = first + 2 + cnt * 12
        val second = ((bytes[next1].toInt() and 255) shl 24) or ((bytes[next1 + 1].toInt() and 255) shl 16) or ((bytes[next1 + 2].toInt() and 255) shl 8) or (bytes[next1 + 3].toInt() and 255)
        val next2 = second + 2 + cnt * 12
        for (k in 0..3) bytes[next2 + k] = bytes[4 + k]
        val e = try { Tiff.pageCount(TiffTestUtil.input("loop.tif", bytes, tmp.root)); null } catch (x: EngineException) { x }!!
        assertEquals(ErrorCode.UNREADABLE, e.code)
    }

    @Test fun inspectPagesReportsEachPageWithOneOpen() {
        for (le in listOf(false, true)) {
            val good = TiffSpec(8, 6, 1, 8, 1, le = le); val big = TiffSpec(10, 4, 3, 16, 2, le = le); val bad = TiffSpec(8, 8, 4, 8, 5, le = le)
            val bytes = TiffTestUtil.writeMulti(listOf(good to rows(8, 6, 0, 8, 1), bad to rows(8, 8, 6, 8, 2), big to rows(10, 4, 2, 16, 3)))
            val pages = Tiff.inspectPages(TiffTestUtil.input("i$le.tif", bytes, tmp.root))
            assertEquals(3, pages.size)
            assertEquals(listOf(1, 2, 3), pages.map { it.page })
            assertEquals(8, pages[0].info!!.width); assertEquals(10, pages[2].info!!.width); assertEquals(16, pages[2].info!!.bitDepth)
            assertEquals(ErrorCode.UNSUPPORTED, pages[1].problem!!.code); assertNull(pages[1].info)
        }
    }
}
