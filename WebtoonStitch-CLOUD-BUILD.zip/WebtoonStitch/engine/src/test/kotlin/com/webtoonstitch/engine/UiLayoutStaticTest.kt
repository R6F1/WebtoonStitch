package com.webtoonstitch.engine

import org.junit.Assert.*
import org.junit.Test
import java.io.File

/**
 * The Compose UI cannot be compiled or run without the Android SDK, so the layout rules of the Stitch and TIFF screens are checked
 * on the SOURCE: exactly 3 columns in Stitch, a filename-only list in TIFF, and no 2/3-column toggle anywhere.
 */
class UiLayoutStaticTest {
    private val root: File = run {
        var d: File? = File("").absoluteFile
        while (d != null && !File(d, "app/src/main/kotlin").isDirectory) d = d.parentFile
        d ?: error("project root (with app/src/main/kotlin) not found from ${File("").absolutePath}")
    }
    private fun ui(name: String) = File(root, "app/src/main/kotlin/com/webtoonstitch/app/ui/$name").readText()
    private fun appSources() = File(root, "app/src/main").walkTopDown().filter { it.isFile && it.extension == "kt" }.toList()

    @Test fun noColumnToggleOrPreferenceRemains() {
        for (f in appSources()) {
            val t = f.readText()
            for (bad in listOf("ColumnsSwitch", "onColumns", "ViewPrefs", "setColumns", "KEY_COLUMNS"))
                assertFalse("${f.name} still contains $bad", t.contains(bad))
        }
        assertFalse(File(root, "app/src/main/kotlin/com/webtoonstitch/app/ViewPrefs.kt").exists())
        assertFalse("CompactTopBar must not take a columns parameter", Regex("""fun CompactTopBar\([^)]*columns""").containsMatchIn(ui("Components.kt")))
    }

    @Test fun stitchScreenIsExactlyThreeColumns() {
        val t = ui("StitchScreen.kt")
        assertTrue(t.contains("private const val STITCH_COLUMNS = 3"))
        assertTrue(t.contains("columns = STITCH_COLUMNS"))
        assertFalse("no stateful column count", Regex("""var\s+columns""").containsMatchIn(t))
        assertFalse(t.contains("filenameOnly"))
        assertTrue("thumbnails still come from the original input (display only)", t.contains("vm.inputFor(e)"))
    }

    @Test fun tiffScreenIsFilenameOnlyList() {
        val t = ui("TiffScreen.kt")
        assertTrue(t.contains("filenameOnly = true"))
        assertFalse(Regex("""var\s+columns""").containsMatchIn(t))
        assertFalse("no thumbnail input may be handed to the list", t.contains("inputFor"))
        assertFalse(t.contains("Thumb("))
        // list mode is one column and draws no Thumb
        val c = ui("Components.kt")
        assertTrue(c.contains("GridCells.Fixed(if (filenameOnly) 1 else columns)"))
        val row = c.substring(c.indexOf("private fun FileNameRow"), c.indexOf("fun MessageDialog"))
        assertFalse("FileNameRow must not draw thumbnails", row.contains("Thumb(") || row.contains("Image("))
    }

    @Test fun selectionAndDragSelectStayInTheSharedGrid() {
        val c = ui("Components.kt")
        for (needle in listOf("awaitFirstDown", "longPressTimeoutMillis", "currentOnDragSelect(keys, select)", "FileNameRow(shown", "PickerCell(shown"))
            assertTrue("missing: $needle", c.contains(needle))
        for (screen in listOf("StitchScreen.kt", "TiffScreen.kt")) {
            val t = ui(screen)
            assertTrue(t.contains("onClick = { cell -> vm.toggleKey(cell.key) }")); assertTrue(t.contains("onDragSelect = vm::dragSelect"))
        }
    }
}
