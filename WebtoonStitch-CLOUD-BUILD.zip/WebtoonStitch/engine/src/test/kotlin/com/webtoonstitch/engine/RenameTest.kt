package com.webtoonstitch.engine

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.awt.image.BufferedImage
import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import javax.imageio.ImageIO

/** Mass PNG rename: planning, collision protection, rollback, confirmation, byte-for-byte integrity. */
class RenameTest {
    @get:Rule val tmp = TemporaryFolder()

    /** Real file renames (java.nio, never replacing an existing file). Optional fault injection. */
    private class FsFolder(val dir: File, var failOnCall: Int = -1, var failAllAfter: Int = Int.MAX_VALUE) : RenameFolder {
        var calls = 0
        val log = ArrayList<String>()
        override fun exists(name: String) = File(dir, name).exists()
        override fun rename(from: String, to: String) {
            calls++
            log += "$from -> $to"
            if (calls == failOnCall || calls > failAllAfter) throw IOException("injected failure at call $calls")
            Files.move(File(dir, from).toPath(), File(dir, to).toPath())      // throws FileAlreadyExistsException instead of overwriting
        }
    }

    private fun sha(f: File) = MessageDigest.getInstance("SHA-256").digest(f.readBytes()).joinToString("") { "%02x".format(it) }
    private fun snapshot(dir: File) = dir.listFiles()!!.associate { it.name to sha(it) }

    private fun png(seed: Int): ByteArray {
        val img = BufferedImage(7 + seed, 5, BufferedImage.TYPE_INT_ARGB)
        for (y in 0 until 5) for (x in 0 until 7 + seed) img.setRGB(x, y, (seed * 40503 + x * 131 + y * 7919) or (0x80 shl 24))
        val bos = java.io.ByteArrayOutputStream(); ImageIO.write(img, "png", bos); return bos.toByteArray()
    }

    private fun makeDir(vararg names: String): File {
        val d = tmp.newFolder()
        for ((i, n) in names.withIndex()) File(d, n).writeBytes(png(i + 1))
        return d
    }

    private val range = listOf("001-008 (1).png", "009-017 (1).png", "018-026 (1).png", "027-035 (1).png", "036-044 (1).png", "045-053 (1).png")

    // 1 + 2
    @Test fun sortsNumericallyAndNumbersSequentiallyFromOne() {
        val shuffled = listOf("107-115 (1).png", "9-17.png", "018-026 (1).png", "001-008 (1).png", "027-035 (1).png", "100-106.png")
        val p = RenamePlanner.plan(shuffled, emptyList())
        assertEquals(listOf("001-008 (1).png", "9-17.png", "018-026 (1).png", "027-035 (1).png", "100-106.png", "107-115 (1).png"), p.items.map { it.originalName })
        assertEquals(listOf("001.png", "002.png", "003.png", "004.png", "005.png", "006.png"), p.items.map { it.newName })
        // a new plan always starts again at 001 (no memory of earlier operations)
        assertEquals("001.png", RenamePlanner.plan(listOf("500-510.png"), emptyList()).items.single().newName)
    }

    @Test fun selectionOrderDatesAndSizesAreIgnored() {
        val d = makeDir(*range.toTypedArray())
        range.forEachIndexed { i, n -> File(d, n).setLastModified(1_000_000_000L - i * 1000L) }   // newest = first range
        val p = RenamePlanner.plan(range.reversed(), d.list()!!.toList())
        assertEquals(range, p.items.map { it.originalName })
    }

    // 3
    @Test fun duplicateSuffixesAreIgnored() {
        for (n in listOf("001-008 (1).png", "001-008 (2).png", "001-008(12).png", "001-008.png", "001 - 008 (1).png"))
            assertEquals(n, NumericRange(1, 8), RenameNaming.parseRange(n))
        assertNull(RenameNaming.parseRange("001-008 (a).png"))
        assertNull(RenameNaming.parseRange("001-008 (1) (1).png"))
    }

    // 4
    @Test fun leadingZerosAreHandled() {
        assertEquals(NumericRange(9, 17), RenameNaming.parseRange("0009-00017.png"))
        assertEquals(NumericRange(1, 8), RenameNaming.parseRange("1-8.png"))
        val p = RenamePlanner.plan(listOf("010-019.png", "0002-0009.png", "001-008.png"), emptyList())
        assertEquals(listOf("001-008.png", "0002-0009.png", "010-019.png"), p.items.map { it.originalName })   // 1 < 2 < 10, not text order
        assertEquals("001.png", p.items[0].newName)
    }

    @Test fun extensionCaseDoesNotMatterAndNumberWidthGrowsPastNineHundredNinetyNine() {
        assertNotNull(RenameNaming.parseRange("009-017 (1).PNG"))
        assertNotNull(RenameNaming.parseRange("009-017.Png"))
        assertEquals("001.png", RenameNaming.targetName(1, 999))
        assertEquals("0001.png", RenameNaming.targetName(1, 1000))
        assertEquals("1000.png", RenameNaming.targetName(1000, 1000))
    }

    // 5
    @Test fun nonNumericNamesAreSkippedAndStayUntouched() {
        val d = makeDir("cover.png", "chapter.png", "image.png", "009-017 (1).png", "001-008 (1).png", "008-001.png", "001-008.jpg", "notes 001-008.png")
        val before = snapshot(d)
        val sel = d.list()!!.toList()
        val s = RenameSession(FsFolder(d), sel, sel)
        assertEquals(listOf("001-008 (1).png", "009-017 (1).png"), s.plan.items.map { it.originalName })
        assertEquals(setOf("cover.png", "chapter.png", "image.png", "008-001.png", "001-008.jpg", "notes 001-008.png"), s.plan.skipped.map { it.name }.toSet())
        val r = s.confirmAndRun()
        assertEquals(RenameStatus.DONE, r.status)
        val after = snapshot(d)
        for (n in s.plan.skipped.map { it.name }) assertEquals("$n unchanged", before[n], after[n])
        assertEquals(setOf("001.png", "002.png") + s.plan.skipped.map { it.name }, after.keys)
    }

    @Test fun onlySelectedFilesAreTouched() {
        val d = makeDir("001-008.png", "009-017.png", "018-026.png")
        val r = RenameSession(FsFolder(d), listOf("018-026.png", "001-008.png"), d.list()!!.toList()).confirmAndRun()
        assertEquals(RenameStatus.DONE, r.status)
        assertEquals(setOf("001.png", "002.png", "009-017.png"), d.list()!!.toSet())
    }

    // 6
    @Test fun duplicateRangesGetDistinctNumbersAndAreReported() {
        val d = makeDir("001-008.png", "001-008 (1).png", "009-017.png")
        val s = RenameSession(FsFolder(d), d.list()!!.toList(), d.list()!!.toList())
        assertEquals(3, s.plan.items.map { it.newName }.toSet().size)
        assertEquals(1, s.plan.duplicateRangeNotes.size)
        assertTrue(s.plan.duplicateRangeNotes[0].contains("001-008.png") && s.plan.duplicateRangeNotes[0].contains("001-008 (1).png"))
        val before = snapshot(d).values.toSet()
        assertEquals(RenameStatus.DONE, s.confirmAndRun().status)
        assertEquals(before, snapshot(d).values.toSet())     // all three files still exist, with their own contents
        assertEquals(3, d.list()!!.size)
        // deterministic: the same inputs always give the same plan
        val again = RenamePlanner.plan(listOf("001-008 (1).png", "009-017.png", "001-008.png"), emptyList())
        assertEquals(s.plan.items.map { it.originalName to it.newName }, again.items.map { it.originalName to it.newName })
    }

    // 7
    @Test fun existingDestinationBlocksEverythingAndChangesNothing() {
        for (clash in listOf("002.png", "002.PNG")) {
            val d = makeDir("001-008.png", "009-017.png", "018-026.png", clash)
            val before = snapshot(d)
            val sel = listOf("001-008.png", "009-017.png", "018-026.png")
            val f = FsFolder(d)
            val s = RenameSession(f, sel, d.list()!!.toList())
            assertFalse(s.plan.canExecute)
            assertEquals(listOf("002.png"), s.plan.conflicts.map { it.newName })
            val r = s.confirmAndRun()
            assertEquals(RenameStatus.REFUSED, r.status)
            assertEquals("no rename call may happen", 0, f.calls)
            assertEquals(before, snapshot(d))
        }
    }

    @Test fun folderChangedAfterPreviewIsDetectedBeforeAnythingMoves() {
        val d = makeDir("001-008.png", "009-017.png")
        val f = FsFolder(d)
        val s = RenameSession(f, listOf("001-008.png", "009-017.png"), d.list()!!.toList())
        File(d, "002.png").writeBytes(byteArrayOf(1, 2, 3))          // appears after the preview
        val before = snapshot(d)
        val r = s.confirmAndRun()
        assertEquals(RenameStatus.REFUSED, r.status); assertEquals(0, f.calls); assertEquals(before, snapshot(d))
        assertArrayEquals(byteArrayOf(1, 2, 3), File(d, "002.png").readBytes())
    }

    // 8
    @Test fun failureAtAnyStepRestoresEveryFile() {
        val names = listOf("001-008 (1).png", "009-017 (1).png", "018-026 (1).png", "027-035 (1).png")
        val total = names.size * 2   // two phases
        for (failAt in 1..total) {
            val d = makeDir(*names.toTypedArray())
            val before = snapshot(d)
            val f = FsFolder(d, failOnCall = failAt)
            val r = RenameSession(f, names, d.list()!!.toList()).confirmAndRun()
            assertEquals("fail at $failAt", RenameStatus.FAILED_RESTORED, r.status)
            assertEquals("fail at $failAt", before, snapshot(d))       // same names, same bytes, nothing extra left behind
        }
    }

    @Test fun failedRollbackReportsStrandedFilesAndDeletesNothing() {
        val names = listOf("001-008.png", "009-017.png", "018-026.png")
        val d = makeDir(*names.toTypedArray())
        val bytesBefore = snapshot(d).values.toSet()
        // phase 1 succeeds for all (3 calls), the first final rename (call 4) fails, and from call 5 on every rename fails (rollback too)
        val f = FsFolder(d, failOnCall = 4, failAllAfter = 4)
        val r = RenameSession(f, names, d.list()!!.toList()).confirmAndRun()
        assertEquals(RenameStatus.FAILED_NOT_RESTORED, r.status)
        assertEquals(3, r.stranded.size)
        assertEquals(bytesBefore, snapshot(d).values.toSet())          // every file's bytes still exist
        assertEquals(3, d.list()!!.size)
        for ((orig, now) in r.stranded) assertTrue("$orig is reported under its real current name $now", File(d, now).exists())
    }

    // 9
    @Test fun nothingIsRenamedBeforeConfirmation() {
        val d = makeDir(*range.toTypedArray())
        val before = snapshot(d)
        val f = FsFolder(d)
        val s = RenameSession(f, range, d.list()!!.toList())
        assertEquals(6, s.plan.items.size)                    // the preview exists ...
        assertEquals(0, f.calls); assertEquals(before, snapshot(d))   // ... and the folder is untouched
        assertEquals(RenameStatus.DONE, s.confirmAndRun().status)
        assertEquals(setOf("001.png", "002.png", "003.png", "004.png", "005.png", "006.png"), d.list()!!.toSet())
        val calls = f.calls
        assertEquals(RenameStatus.REFUSED, s.confirmAndRun().status)   // the confirmation is single-use
        assertEquals(calls, f.calls)
    }

    // 10
    @Test fun renamedPngsAreByteForByteIdentical() {
        val d = makeDir(*range.toTypedArray())
        val originals = range.map { it to File(d, it).readBytes() }
        val r = RenameSession(FsFolder(d), range.reversed(), d.list()!!.toList()).confirmAndRun()
        assertEquals(RenameStatus.DONE, r.status)
        for ((i, p) in originals.withIndex()) {
            val renamed = File(d, "%03d.png".format(i + 1)).readBytes()
            assertArrayEquals("${p.first} content", p.second, renamed)
            // and it still decodes to the same size
            val a = ImageIO.read(p.second.inputStream()); val b = ImageIO.read(renamed.inputStream())
            assertEquals(a.width, b.width); assertEquals(a.height, b.height)
        }
    }

    @Test fun planHasNoImageDependency() {
        // The planner and executor only ever see names: they cannot decode or re-encode anything.
        val p = RenamePlanner.plan(listOf("001-008.png"), emptyList())
        assertEquals("001.png", p.items.single().newName)
        assertTrue(p.canExecute)
        assertFalse(RenamePlanner.plan(listOf("cover.png"), emptyList()).canExecute)    // nothing recognised -> nothing to run
    }

    // ================= Standalone numeric names ("116.png") =================

    // 1. recognition
    @Test fun standaloneNumericNamesAreRecognised() {
        for ((n, v) in listOf("116.png" to 116L, "146.png" to 146L, "001.png" to 1L, "000146.png" to 146L, "7.PNG" to 7L, "009.Png" to 9L))
            assertEquals(n, v, RenameNaming.parseStandalone(n))
        // ranges are not standalone and standalone names are not ranges
        assertNull(RenameNaming.parseStandalone("001-009.png")); assertNull(RenameNaming.parseRange("116.png"))
        val p = RenamePlanner.plan(listOf("116.png", "001-009.png", "000146.png"), emptyList())
        assertEquals(listOf(false, true, true), p.items.map { it.standalone })
        assertTrue(p.skipped.isEmpty())
    }

    // 2. numeric order, not text order
    @Test fun standaloneFilesSortByNumericValue() {
        val p = RenamePlanner.plan(listOf("1000.png", "99.png", "100.png", "9.png", "0010.png"), emptyList())
        assertEquals(listOf("9.png", "0010.png", "99.png", "100.png", "1000.png"), p.items.map { it.originalName })
        // leading zeros must not change the value-based order, and equal digits-with-padding must not beat a smaller number
        val q = RenamePlanner.plan(listOf("0200.png", "30.png", "00031.png", "2.png"), emptyList())
        assertEquals(listOf("2.png", "30.png", "00031.png", "0200.png"), q.items.map { it.originalName })
    }

    // 3. ranges first, whatever the numbers are
    @Test fun rangeFilesAlwaysPrecedeStandaloneFiles() {
        val p = RenamePlanner.plan(listOf("001.png", "002.png", "500-510.png", "900-910.png"), emptyList())
        assertEquals(listOf("500-510.png", "900-910.png", "001.png", "002.png"), p.items.map { it.originalName })
    }

    // 4. the example from the specification + mixed numbering
    @Test fun mixedRangeAndStandaloneNumberingIsSequential() {
        val p = RenamePlanner.plan(listOf("146.png", "019-027.png", "116.png", "001-009.png", "010-018.png"), emptyList())
        assertEquals(
            listOf("001-009.png" to "001.png", "010-018.png" to "002.png", "019-027.png" to "003.png", "116.png" to "004.png", "146.png" to "005.png"),
            p.items.map { it.originalName to it.newName }
        )
        assertEquals(listOf("001.png"), RenamePlanner.plan(listOf("146.png"), emptyList()).items.map { it.newName })   // every operation starts at 001
    }

    // 5. leading zeros
    @Test fun standaloneLeadingZerosAreNumericNotTextual() {
        val p = RenamePlanner.plan(listOf("0100.png", "000009.png", "10.png"), emptyList())
        assertEquals(listOf("000009.png", "10.png", "0100.png"), p.items.map { it.originalName })
        assertEquals(listOf("001.png", "002.png", "003.png"), p.items.map { it.newName })
    }

    // 6. unrelated names
    @Test fun nonNumericPngNamesAreStillSkipped() {
        val names = listOf("cover.png", "chapter.png", "image-final.png", "116 final.png", "116_.png", "116.jpg", "116.png.png", "1 6.png", "-116.png", "116-.png", "a116.png", "116 (1).png", "116png", ".png", "png", "116", "116.pn")
        val p = RenamePlanner.plan(names + "146.png", emptyList())
        assertEquals(listOf("146.png"), p.items.map { it.originalName })
        assertEquals(names.toSet(), p.skipped.map { it.name }.toSet())
    }

    // 7. selection order
    @Test fun mixedSelectionOrderDatesAndSizesNeverMatter() {
        val names = listOf("001-009.png", "010-018.png", "019-027.png", "116.png", "146.png")
        val d = makeDir(*names.toTypedArray())
        names.forEachIndexed { i, n -> File(d, n).setLastModified(2_000_000_000L - i * 5000L) }       // reversed dates
        val expected = RenamePlanner.plan(names, d.list()!!.toList()).items.map { it.originalName to it.newName }
        assertEquals(names, expected.map { it.first })
        val rnd = java.util.Random(7)
        repeat(25) {
            val shuffled = names.shuffled(rnd)
            assertEquals(expected, RenamePlanner.plan(shuffled, d.list()!!.toList()).items.map { it.originalName to it.newName })
        }
        assertEquals(expected, RenamePlanner.plan(names.reversed(), d.list()!!.toList()).items.map { it.originalName to it.newName })
    }

    // 8. duplicate numeric values
    @Test fun duplicateStandaloneValuesGetDistinctDeterministicNumbers() {
        val d = makeDir("1.png", "001.png", "0001.png", "5.png")
        val sel = d.list()!!.toList()
        val s = RenameSession(FsFolder(d), sel, sel)
        assertEquals(4, s.plan.items.map { it.newName }.toSet().size)
        assertEquals(1, s.plan.duplicateRangeNotes.size)
        assertTrue(s.plan.duplicateRangeNotes[0].contains("Number 1 ") && s.plan.duplicateRangeNotes[0].contains("3 times"))
        val a = RenamePlanner.plan(listOf("5.png", "0001.png", "1.png", "001.png"), emptyList()).items.map { it.originalName to it.newName }
        val b = RenamePlanner.plan(listOf("001.png", "1.png", "5.png", "0001.png"), emptyList()).items.map { it.originalName to it.newName }
        assertEquals(a, b)
        val before = snapshot(d).values.toSet()
        assertEquals(RenameStatus.DONE, s.confirmAndRun().status)
        assertEquals(before, snapshot(d).values.toSet())      // four files, four distinct contents, none lost
        assertEquals(setOf("001.png", "002.png", "003.png", "004.png"), d.list()!!.toSet())
    }

    // 9. collisions
    @Test fun standaloneCollisionWithUnselectedFileBlocksEverything() {
        val d = makeDir("001-009.png", "116.png", "146.png", "003.png")          // 003.png is NOT selected and is a destination
        val before = snapshot(d)
        val f = FsFolder(d)
        val s = RenameSession(f, listOf("001-009.png", "116.png", "146.png"), d.list()!!.toList())
        assertFalse(s.plan.canExecute)
        assertEquals(listOf("003.png"), s.plan.conflicts.map { it.newName })
        assertEquals(RenameStatus.REFUSED, s.confirmAndRun().status)
        assertEquals(0, f.calls); assertEquals(before, snapshot(d))
    }

    @Test fun selectedFilesMayTakeEachOthersCurrentNamesThroughTemporaryNames() {
        // already-numbered files: 001.png is a destination, but it is itself selected and is moved away first -> allowed
        val d = makeDir("001.png", "002.png", "003.png")
        val originals = listOf("001.png", "002.png", "003.png").map { File(d, it).readBytes() }
        val s = RenameSession(FsFolder(d), listOf("003.png", "001.png", "002.png"), d.list()!!.toList())
        assertTrue(s.plan.conflicts.isEmpty())
        assertEquals(RenameStatus.DONE, s.confirmAndRun().status)
        listOf("001.png", "002.png", "003.png").forEachIndexed { i, n -> assertArrayEquals(originals[i], File(d, n).readBytes()) }
        // gaps close up: 116 / 146 become 001 / 002 even though 001 / 002 ... are held by other selected files
        val d2 = makeDir("002.png", "116.png", "001-009.png")
        val b2 = mapOf("001-009.png" to File(d2, "001-009.png").readBytes(), "002.png" to File(d2, "002.png").readBytes(), "116.png" to File(d2, "116.png").readBytes())
        val r = RenameSession(FsFolder(d2), d2.list()!!.toList(), d2.list()!!.toList()).confirmAndRun()
        assertEquals(RenameStatus.DONE, r.status)
        assertArrayEquals(b2["001-009.png"], File(d2, "001.png").readBytes())    // range first
        assertArrayEquals(b2["002.png"], File(d2, "002.png").readBytes())        // 2 < 116
        assertArrayEquals(b2["116.png"], File(d2, "003.png").readBytes())
    }

    @Test fun skippedSelectedFileStillBlocksItsOwnName() {
        // "001.png" is recognised, but an UNRECOGNISED selected file never moves, so a destination held by it is still a conflict
        val d = makeDir("116.png", "cover.png")
        val s = RenameSession(FsFolder(d), listOf("116.png", "cover.png"), d.list()!!.toList())
        assertTrue(s.plan.canExecute)                                          // 001.png is free
        val d2 = makeDir("116.png", "001.PNG", "cover.png")                    // case-insensitive clash with an unselected file
        val s2 = RenameSession(FsFolder(d2), listOf("116.png"), d2.list()!!.toList())
        assertFalse(s2.plan.canExecute)
    }

    @Test fun failureWhileRenamingStandaloneFilesRestoresEveryFile() {
        val names = listOf("001-009.png", "010-018.png", "116.png", "146.png")
        for (failAt in 1..names.size * 2) {
            val d = makeDir(*names.toTypedArray())
            val before = snapshot(d)
            val r = RenameSession(FsFolder(d, failOnCall = failAt), names, d.list()!!.toList()).confirmAndRun()
            assertEquals("fail at $failAt", RenameStatus.FAILED_RESTORED, r.status)
            assertEquals("fail at $failAt", before, snapshot(d))
        }
        // the same with a name swap (every destination is another selected file's current name)
        val sw = listOf("1.png", "2.png", "3.png")
        for (failAt in 1..sw.size * 2) {
            val d = makeDir(*sw.toTypedArray()); val before = snapshot(d)
            val r = RenameSession(FsFolder(d, failOnCall = failAt), sw, d.list()!!.toList()).confirmAndRun()
            assertEquals("swap fail at $failAt", RenameStatus.FAILED_RESTORED, r.status)
            assertEquals("swap fail at $failAt", before, snapshot(d))
        }
    }

    // 10. bytes
    @Test fun mixedRenameKeepsEveryFileByteIdentical() {
        val names = listOf("001-009.png", "010-018.png", "019-027.png", "146.png", "116.png")
        val d = makeDir(*names.toTypedArray())
        val bytes = names.associateWith { File(d, it).readBytes() }
        val order = listOf("001-009.png", "010-018.png", "019-027.png", "116.png", "146.png")
        val r = RenameSession(FsFolder(d), names.reversed(), d.list()!!.toList()).confirmAndRun()
        assertEquals(RenameStatus.DONE, r.status)
        order.forEachIndexed { i, n -> assertArrayEquals("$n", bytes.getValue(n), File(d, "%03d.png".format(i + 1)).readBytes()) }
        assertEquals(5, d.list()!!.size)
    }

    @Test fun renameSourcesDoNotTouchImageCodecs() {
        // Filesystem-only guarantee, checked on the source: Rename.kt must not mention any decoder / encoder / image API.
        var dir: File? = File("").absoluteFile
        while (dir != null && !File(dir, "engine/src/main/kotlin/com/webtoonstitch/engine/Rename.kt").exists()) dir = dir.parentFile
        val src = File(dir ?: error("project root not found"), "engine/src/main/kotlin/com/webtoonstitch/engine/Rename.kt").readText()
        for (bad in listOf("ImageIO", "BufferedImage", "PngDecoder", "PngEncoder", "Decoders", "Stitcher", "readBytes", "FileInputStream", "FileOutputStream", "InputStream", "OutputStream"))
            assertFalse("Rename.kt must not use $bad", src.contains(bad))
    }
}
