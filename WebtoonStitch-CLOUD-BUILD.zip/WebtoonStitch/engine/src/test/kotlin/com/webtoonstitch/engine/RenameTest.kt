package com.webtoonstitch.engine

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.awt.image.BufferedImage
import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import javax.imageio.ImageIO

/** Mass PNG rename: planning, collision protection, rollback, confirmation, byte-for-byte integrity. */
class RenameTest {
    @get:Rule val tmp = TemporaryFolder()

    /** Real file renames (java.nio, never replacing an existing file). Optional fault injection. */
    private class FsFolder(val dir: File, var failOnCall: Int = -1, var failAllAfter: Int = Int.MAX_VALUE) : RenameFolder {
        var calls = 0
        val log = ArrayList<String>()
        override fun exists(name: String) = File(dir, name).exists()
        override fun rename(from: String, to: String) {
            calls++
            log += "$from -> $to"
            if (calls == failOnCall || calls > failAllAfter) throw IOException("injected failure at call $calls")
            Files.move(File(dir, from).toPath(), File(dir, to).toPath())      // throws FileAlreadyExistsException instead of overwriting
        }
    }

    private fun sha(f: File) = MessageDigest.getInstance("SHA-256").digest(f.readBytes()).joinToString("") { "%02x".format(it) }
    private fun snapshot(dir: File) = dir.listFiles()!!.associate { it.name to sha(it) }

    private fun png(seed: Int): ByteArray {
        val img = BufferedImage(7 + seed, 5, BufferedImage.TYPE_INT_ARGB)
        for (y in 0 until 5) for (x in 0 until 7 + seed) img.setRGB(x, y, (seed * 40503 + x * 131 + y * 7919) or (0x80 shl 24))
        val bos = java.io.ByteArrayOutputStream(); ImageIO.write(img, "png", bos); return bos.toByteArray()
    }

    private fun makeDir(vararg names: String): File {
        val d = tmp.newFolder()
        for ((i, n) in names.withIndex()) File(d, n).writeBytes(png(i + 1))
        return d
    }

    private val range = listOf("001-008 (1).png", "009-017 (1).png", "018-026 (1).png", "027-035 (1).png", "036-044 (1).png", "045-053 (1).png")

    // 1 + 2
    @Test fun sortsNumericallyAndNumbersSequentiallyFromOne() {
        val shuffled = listOf("107-115 (1).png", "9-17.png", "018-026 (1).png", "001-008 (1).png", "027-035 (1).png", "100-106.png")
        val p = RenamePlanner.plan(shuffled, emptyList())
        assertEquals(listOf("001-008 (1).png", "9-17.png", "018-026 (1).png", "027-035 (1).png", "100-106.png", "107-115 (1).png"), p.items.map { it.originalName })
        assertEquals(listOf("001.png", "002.png", "003.png", "004.png", "005.png", "006.png"), p.items.map { it.newName })
        // a new plan always starts again at 001 (no memory of earlier operations)
        assertEquals("001.png", RenamePlanner.plan(listOf("500-510.png"), emptyList()).items.single().newName)
    }

    @Test fun selectionOrderDatesAndSizesAreIgnored() {
        val d = makeDir(*range.toTypedArray())
        range.forEachIndexed { i, n -> File(d, n).setLastModified(1_000_000_000L - i * 1000L) }   // newest = first range
        val p = RenamePlanner.plan(range.reversed(), d.list()!!.toList())
        assertEquals(range, p.items.map { it.originalName })
    }

    // 3
    @Test fun duplicateSuffixesAreIgnored() {
        for (n in listOf("001-008 (1).png", "001-008 (2).png", "001-008(12).png", "001-008.png", "001 - 008 (1).png"))
            assertEquals(n, NumericRange(1, 8), RenameNaming.parseRange(n))
        assertNull(RenameNaming.parseRange("001-008 (a).png"))
        assertNull(RenameNaming.parseRange("001-008 (1) (1).png"))
    }

    // 4
    @Test fun leadingZerosAreHandled() {
        assertEquals(NumericRange(9, 17), RenameNaming.parseRange("0009-00017.png"))
        assertEquals(NumericRange(1, 8), RenameNaming.parseRange("1-8.png"))
        val p = RenamePlanner.plan(listOf("010-019.png", "0002-0009.png", "001-008.png"), emptyList())
        assertEquals(listOf("001-008.png", "0002-0009.png", "010-019.png"), p.items.map { it.originalName })   // 1 < 2 < 10, not text order
        assertEquals("001.png", p.items[0].newName)
    }

    @Test fun extensionCaseDoesNotMatterAndNumberWidthGrowsPastNineHundredNinetyNine() {
        assertNotNull(RenameNaming.parseRange("009-017 (1).PNG"))
        assertNotNull(RenameNaming.parseRange("009-017.Png"))
        assertEquals("001.png", RenameNaming.targetName(1, 999))
        assertEquals("0001.png", RenameNaming.targetName(1, 1000))
        assertEquals("1000.png", RenameNaming.targetName(1000, 1000))
    }

    // 5
    @Test fun nonNumericNamesAreSkippedAndStayUntouched() {
        val d = makeDir("cover.png", "chapter.png", "image.png", "009-017 (1).png", "001-008 (1).png", "008-001.png", "001-008.jpg", "notes 001-008.png")
        val before = snapshot(d)
        val sel = d.list()!!.toList()
        val s = RenameSession(FsFolder(d), sel, sel)
        assertEquals(listOf("001-008 (1).png", "009-017 (1).png"), s.plan.items.map { it.originalName })
        assertEquals(setOf("cover.png", "chapter.png", "image.png", "008-001.png", "001-008.jpg", "notes 001-008.png"), s.plan.skipped.map { it.name }.toSet())
        val r = s.confirmAndRun()
        assertEquals(RenameStatus.DONE, r.status)
        val after = snapshot(d)
        for (n in s.plan.skipped.map { it.name }) assertEquals("$n unchanged", before[n], after[n])
        assertEquals(setOf("001.png", "002.png") + s.plan.skipped.map { it.name }, after.keys)
    }

    @Test fun onlySelectedFilesAreTouched() {
        val d = makeDir("001-008.png", "009-017.png", "018-026.png")
        val r = RenameSession(FsFolder(d), listOf("018-026.png", "001-008.png"), d.list()!!.toList()).confirmAndRun()
        assertEquals(RenameStatus.DONE, r.status)
        assertEquals(setOf("001.png", "002.png", "009-017.png"), d.list()!!.toSet())
    }

    // 6
    @Test fun duplicateRangesGetDistinctNumbersAndAreReported() {
        val d = makeDir("001-008.png", "001-008 (1).png", "009-017.png")
        val s = RenameSession(FsFolder(d), d.list()!!.toList(), d.list()!!.toList())
        assertEquals(3, s.plan.items.map { it.newName }.toSet().size)
        assertEquals(1, s.plan.duplicateRangeNotes.size)
        assertTrue(s.plan.duplicateRangeNotes[0].contains("001-008.png") && s.plan.duplicateRangeNotes[0].contains("001-008 (1).png"))
        val before = snapshot(d).values.toSet()
        assertEquals(RenameStatus.DONE, s.confirmAndRun().status)
        assertEquals(before, snapshot(d).values.toSet())     // all three files still exist, with their own contents
        assertEquals(3, d.list()!!.size)
        // deterministic: the same inputs always give the same plan
        val again = RenamePlanner.plan(listOf("001-008 (1).png", "009-017.png", "001-008.png"), emptyList())
        assertEquals(s.plan.items.map { it.originalName to it.newName }, again.items.map { it.originalName to it.newName })
    }

    // 7
    @Test fun existingDestinationBlocksEverythingAndChangesNothing() {
        for (clash in listOf("002.png", "002.PNG")) {
            val d = makeDir("001-008.png", "009-017.png", "018-026.png", clash)
            val before = snapshot(d)
            val sel = listOf("001-008.png", "009-017.png", "018-026.png")
            val f = FsFolder(d)
            val s = RenameSession(f, sel, d.list()!!.toList())
            assertFalse(s.plan.canExecute)
            assertEquals(listOf("002.png"), s.plan.conflicts.map { it.newName })
            val r = s.confirmAndRun()
            assertEquals(RenameStatus.REFUSED, r.status)
            assertEquals("no rename call may happen", 0, f.calls)
            assertEquals(before, snapshot(d))
        }
    }

    @Test fun folderChangedAfterPreviewIsDetectedBeforeAnythingMoves() {
        val d = makeDir("001-008.png", "009-017.png")
        val f = FsFolder(d)
        val s = RenameSession(f, listOf("001-008.png", "009-017.png"), d.list()!!.toList())
        File(d, "002.png").writeBytes(byteArrayOf(1, 2, 3))          // appears after the preview
        val before = snapshot(d)
        val r = s.confirmAndRun()
        assertEquals(RenameStatus.REFUSED, r.status); assertEquals(0, f.calls); assertEquals(before, snapshot(d))
        assertArrayEquals(byteArrayOf(1, 2, 3), File(d, "002.png").readBytes())
    }

    // 8
    @Test fun failureAtAnyStepRestoresEveryFile() {
        val names = listOf("001-008 (1).png", "009-017 (1).png", "018-026 (1).png", "027-035 (1).png")
        val total = names.size * 2   // two phases
        for (failAt in 1..total) {
            val d = makeDir(*names.toTypedArray())
            val before = snapshot(d)
            val f = FsFolder(d, failOnCall = failAt)
            val r = RenameSession(f, names, d.list()!!.toList()).confirmAndRun()
            assertEquals("fail at $failAt", RenameStatus.FAILED_RESTORED, r.status)
            assertEquals("fail at $failAt", before, snapshot(d))       // same names, same bytes, nothing extra left behind
        }
    }

    @Test fun failedRollbackReportsStrandedFilesAndDeletesNothing() {
        val names = listOf("001-008.png", "009-017.png", "018-026.png")
        val d = makeDir(*names.toTypedArray())
        val bytesBefore = snapshot(d).values.toSet()
        // phase 1 succeeds for all (3 calls), the first final rename (call 4) fails, and from call 5 on every rename fails (rollback too)
        val f = FsFolder(d, failOnCall = 4, failAllAfter = 4)
        val r = RenameSession(f, names, d.list()!!.toList()).confirmAndRun()
        assertEquals(RenameStatus.FAILED_NOT_RESTORED, r.status)
        assertEquals(3, r.stranded.size)
        assertEquals(bytesBefore, snapshot(d).values.toSet())          // every file's bytes still exist
        assertEquals(3, d.list()!!.size)
        for ((orig, now) in r.stranded) assertTrue("$orig is reported under its real current name $now", File(d, now).exists())
    }

    // 9
    @Test fun nothingIsRenamedBeforeConfirmation() {
        val d = makeDir(*range.toTypedArray())
        val before = snapshot(d)
        val f = FsFolder(d)
        val s = RenameSession(f, range, d.list()!!.toList())
        assertEquals(6, s.plan.items.size)                    // the preview exists ...
        assertEquals(0, f.calls); assertEquals(before, snapshot(d))   // ... and the folder is untouched
        assertEquals(RenameStatus.DONE, s.confirmAndRun().status)
        assertEquals(setOf("001.png", "002.png", "003.png", "004.png", "005.png", "006.png"), d.list()!!.toSet())
        val calls = f.calls
        assertEquals(RenameStatus.REFUSED, s.confirmAndRun().status)   // the confirmation is single-use
        assertEquals(calls, f.calls)
    }

    // 10
    @Test fun renamedPngsAreByteForByteIdentical() {
        val d = makeDir(*range.toTypedArray())
        val originals = range.map { it to File(d, it).readBytes() }
        val r = RenameSession(FsFolder(d), range.reversed(), d.list()!!.toList()).confirmAndRun()
        assertEquals(RenameStatus.DONE, r.status)
        for ((i, p) in originals.withIndex()) {
            val renamed = File(d, "%03d.png".format(i + 1)).readBytes()
            assertArrayEquals("${p.first} content", p.second, renamed)
            // and it still decodes to the same size
            val a = ImageIO.read(p.second.inputStream()); val b = ImageIO.read(renamed.inputStream())
            assertEquals(a.width, b.width); assertEquals(a.height, b.height)
        }
    }

    @Test fun planHasNoImageDependency() {
        // The planner and executor only ever see names: they cannot decode or re-encode anything.
        val p = RenamePlanner.plan(listOf("001-008.png"), emptyList())
        assertEquals("001.png", p.items.single().newName)
        assertTrue(p.canExecute)
        assertFalse(RenamePlanner.plan(listOf("cover.png"), emptyList()).canExecute)    // nothing recognised -> nothing to run
    }
}
