import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.kotlin.jvm)
}

// No third-party runtime dependencies: only the Kotlin stdlib and java.util.zip.
java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

dependencies {
    testImplementation(libs.junit)
}

tasks.test {
    maxHeapSize = "1g"   // the stitch tests build a few 690x12000 RGBA images in memory for ImageIO cross-checks
    // The large-image tests only run under a small heap (see largeInputTest); they skip themselves here.
    filter { excludeTestsMatching("*LargeMemoryTest") }
}

// Proves streaming: ~375 MB of raw pixel data is stitched/converted inside a 128 MB heap.
//   ./gradlew :engine:largeInputTest
tasks.register<Test>("largeInputTest") {
    group = "verification"
    testClassesDirs = sourceSets.test.get().output.classesDirs
    classpath = sourceSets.test.get().runtimeClasspath
    maxHeapSize = "128m"
    filter { includeTestsMatching("*LargeMemoryTest") }
    testLogging { showStandardStreams = true }
}
