# The engine is plain Kotlin and uses no reflection; default shrinking rules are sufficient.
-keep class com.webtoonstitch.engine.** { *; }
