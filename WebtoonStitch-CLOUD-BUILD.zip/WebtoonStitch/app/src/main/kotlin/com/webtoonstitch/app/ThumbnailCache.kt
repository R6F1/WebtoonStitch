package com.webtoonstitch.app

import android.graphics.Bitmap
import com.webtoonstitch.engine.CancelCheck
import com.webtoonstitch.engine.ImageDecoders
import com.webtoonstitch.engine.ImageInput
import com.webtoonstitch.engine.PreviewCache
import com.webtoonstitch.engine.Thumbnails
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext

/**
 * Display-only previews. They are rendered by the engine's streaming sampler (never by decoding a full Bitmap); very tall
 * images get a balanced top + bottom preview. They are never used to produce an output file.
 */
object ThumbnailCache {
    private const val MAX_BYTES = 40L * 1024 * 1024
    private val cache = PreviewCache<Bitmap>(MAX_BYTES) { it.byteCount.toLong() }
    private val failures = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val gate = Semaphore(2)   // at most two previews decode at once -> bounded CPU and memory

    private fun k(key: String, side: Int) = "$key@$side"

    /** Already-rendered preview, if any. Cheap and non-blocking: safe to call while composing. */
    fun peek(key: String, side: Int): Bitmap? = cache.peek(k(key, side))

    /**
     * Gives memory back when Android asks (see MainActivity.onTrimMemory). Previews are only a cache: they are rebuilt on demand.
     * Bitmaps are not recycled explicitly (a cell may still be drawing one); dropping the references lets the GC free them.
     * Levels are the ComponentCallbacks2 constants: RUNNING_LOW 10, RUNNING_CRITICAL 15, UI_HIDDEN 20, BACKGROUND 40.
     */
    fun trimMemory(level: Int) {
        when {
            level >= 40 || level == 15 -> { cache.clear(); failures.clear() }
            level >= 10 -> cache.trimTo(MAX_BYTES / 2)
        }
    }

    /** Why the last preview attempt for [key] failed, or null. Shown in the cell so a failure is not mistaken for "still loading". */
    fun failureOf(key: String, side: Int): String? = failures[k(key, side)]

    /**
     * Renders (or returns the cached) display preview whose longest side is at most [side] px. Display only: the preview is
     * never used to create an output file. Cancelling the caller (the cell scrolled away) stops a waiting or running decode.
     */
    suspend fun get(key: String, input: ImageInput, side: Int): Bitmap? {
        val ck = k(key, side)
        cache.get(ck)?.let { return it }
        if (failures.containsKey(ck)) return null    // known failure: do not decode the whole file again on every scroll
        return withContext(Dispatchers.IO) {
            val job = coroutineContext[kotlinx.coroutines.Job]
            // A cell that scrolled away cancels its request: waiting requests never start and a running decode stops within ~32 rows.
            val cancel = CancelCheck { if (job != null && !job.isActive) throw kotlinx.coroutines.CancellationException("scrolled away") }
            gate.withPermit {
                cache.get(ck) ?: try {
                    cancel.check()
                    val t = ImageDecoders.openPreview(input).use { Thumbnails.renderPreview(it, side, cancel) }
                    Bitmap.createBitmap(t.argb, t.width, t.height, Bitmap.Config.ARGB_8888).also { cache.put(ck, it); failures.remove(ck) }
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e   // the cell scrolled away: not a failure
                } catch (e: Exception) {
                    // a preview failure never blocks selection; it is remembered so the cell can say why it has no preview
                    failures[ck] = e.message ?: e.javaClass.simpleName
                    null
                }
            }
        }
    }
}
