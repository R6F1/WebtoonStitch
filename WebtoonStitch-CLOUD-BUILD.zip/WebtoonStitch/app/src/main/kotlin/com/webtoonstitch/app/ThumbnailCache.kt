package com.webtoonstitch.app

import android.graphics.Bitmap
import android.util.LruCache
import com.webtoonstitch.engine.ImageDecoders
import com.webtoonstitch.engine.ImageInput
import com.webtoonstitch.engine.Thumbnails
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/**
 * Display-only previews. They are rendered by the engine's streaming sampler (never by decoding a full Bitmap)
 * and are never used to produce an output file.
 */
object ThumbnailCache {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    private val failures = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val gate = Semaphore(2)   // at most two previews decode at once -> bounded CPU and memory

    /** Why the last preview attempt for [key] failed, or null. Shown in the cell so a failure is not mistaken for "still loading". */
    fun failureOf(key: String): String? = failures[key]

    suspend fun get(key: String, input: ImageInput): Bitmap? {
        cache.get(key)?.let { return it }
        return withContext(Dispatchers.IO) {
            gate.withPermit {
                cache.get(key) ?: try {
                    val t = ImageDecoders.open(input).use { Thumbnails.render(it, 256) }
                    Bitmap.createBitmap(t.argb, t.width, t.height, Bitmap.Config.ARGB_8888).also { cache.put(key, it); failures.remove(key) }
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e   // the cell scrolled away: not a failure
                } catch (e: Exception) {
                    // a preview failure never blocks selection; it is remembered so the cell can say why it has no preview
                    failures[key] = e.message ?: e.javaClass.simpleName
                    null
                }
            }
        }
    }
}
