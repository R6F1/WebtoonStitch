package com.webtoonstitch.app.ui

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.changedToUpIgnoreConsumed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.webtoonstitch.app.ThumbnailCache
import com.webtoonstitch.engine.ImageInput
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest

/** What the grid needs to draw one cell, independent of which tool is showing it. */
data class CellModel(
    val key: String,
    val name: String,
    val isDir: Boolean,
    val selected: Boolean,
    val subtitle: String?,
    val status: String?,
    val statusIsError: Boolean,
    val input: ImageInput?
)

@Composable
fun KeepScreenOn(on: Boolean) {
    val view = LocalView.current
    DisposableEffect(on) {
        view.keepScreenOn = on
        onDispose { view.keepScreenOn = false }
    }
}

@Composable
fun BackBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text("‹ Back") }
        Text(title, style = MaterialTheme.typography.titleLarge)
    }
}

/** How long after the last scroll movement the bars come back. */
private const val BARS_REAPPEAR_DELAY_MS = 600L

/**
 * Full-screen picker layout. The grid fills the whole screen and NEVER changes size; the top and bottom bars are overlays
 * that slide away while the grid scrolls (or while a drag-selection is in progress) and slide back [BARS_REAPPEAR_DELAY_MS]
 * after it stops. They stay visible while [keepVisible] (e.g. a job with a progress bar and a Cancel button is running).
 *
 * [content] receives the padding that keeps the first and last row clear of the bars at rest, and a callback the grid uses to
 * report that a drag-selection is active. The bars also respect the display cut-out / system-bar insets when those are shown.
 */
@Composable
fun AutoHidingBars(
    gridState: LazyGridState,
    keepVisible: Boolean,
    top: @Composable () -> Unit,
    bottom: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable (contentPadding: PaddingValues, onDragActive: (Boolean) -> Unit) -> Unit
) {
    var scrolling by remember { mutableStateOf(false) }      // from the first scroll movement until the delay after it ends
    var dragActive by remember { mutableStateOf(false) }
    LaunchedEffect(gridState) {
        snapshotFlow { gridState.isScrollInProgress }.collectLatest { inProgress ->
            if (inProgress) scrolling = true
            else { delay(BARS_REAPPEAR_DELAY_MS); scrolling = false }   // cancelled (collectLatest) if scrolling starts again meanwhile
        }
    }
    val visible = keepVisible || !(scrolling || dragActive)

    var topPx by remember { mutableIntStateOf(0) }
    var bottomPx by remember { mutableIntStateOf(0) }
    val density = LocalDensity.current
    val barColor = MaterialTheme.colorScheme.background.copy(alpha = 0.95f)

    Box(modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal))) {
            content(
                PaddingValues(top = with(density) { topPx.toDp() }, bottom = with(density) { bottomPx.toDp() }),
                { active -> dragActive = active }
            )
        }
        AnimatedVisibility(
            visible = visible,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut() + slideOutVertically { -it }
        ) {
            Surface(color = barColor, modifier = Modifier.fillMaxWidth().onSizeChanged { topPx = it.height }) {
                Box(Modifier.windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal))) { top() }
            }
        }
        AnimatedVisibility(
            visible = visible,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn() + slideInVertically { it },
            exit = fadeOut() + slideOutVertically { it }
        ) {
            Surface(color = barColor, modifier = Modifier.fillMaxWidth().onSizeChanged { bottomPx = it.height }) {
                Box(Modifier.windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal))) { bottom() }
            }
        }
    }
}

private class ThumbResult(val bitmap: Bitmap?, val error: String?)

@Composable
fun Thumb(cellKey: String, input: ImageInput?, modifier: Modifier = Modifier) {
    val result: State<ThumbResult?> = produceState<ThumbResult?>(null, cellKey) {
        value = if (input != null) {
            val b = ThumbnailCache.get(cellKey, input)
            ThumbResult(b, if (b == null) ThumbnailCache.failureOf(cellKey) else null)
        } else null
    }
    val r = result.value
    if (r?.bitmap != null) {
        Image(bitmap = r.bitmap.asImageBitmap(), contentDescription = null, modifier = modifier, contentScale = ContentScale.Fit)
    } else if (r?.error != null) {
        // not "still loading": say what went wrong (the file can still be selected; its real error is shown on selection)
        Text("No preview: ${r.error}", style = MaterialTheme.typography.labelSmall, maxLines = 5, overflow = TextOverflow.Ellipsis, modifier = modifier.padding(6.dp))
    }
}

/**
 * Thumbnail grid. Tap = select / deselect (folders open). LONG-PRESS an image and then DRAG across others to select (or, if the
 * long-pressed image was already selected, to deselect) all images the finger passes over; near the top/bottom edge the grid
 * scrolls by itself. An ordinary swipe still scrolls. The images touched are handed over together, in touch order, at the end.
 */
@Composable
fun PickerGrid(
    cells: List<CellModel>,
    onClick: (CellModel) -> Unit,
    onDragSelect: (keys: List<String>, select: Boolean) -> Unit,
    onDragActive: (Boolean) -> Unit,
    dragEnabled: Boolean,
    state: LazyGridState,
    contentPadding: PaddingValues,
    modifier: Modifier = Modifier
) {
    val currentCells by rememberUpdatedState(cells)
    val currentOnDragSelect by rememberUpdatedState(onDragSelect)
    val currentOnDragActive by rememberUpdatedState(onDragActive)
    val currentDragEnabled by rememberUpdatedState(dragEnabled)
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    val gapPx = with(density) { 6.dp.toPx() }

    // On-screen bounds (root coordinates) of the cells that are currently composed. Used only for hit-testing the finger.
    val bounds = remember { HashMap<String, Rect>() }
    var gridCoords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    val dragKeys = remember { mutableStateListOf<String>() }
    var dragSelecting by remember { mutableStateOf(true) }
    var dragging by remember { mutableStateOf(false) }
    var pointer by remember { mutableStateOf(Offset.Zero) }
    var autoScroll by remember { mutableFloatStateOf(0f) }

    fun cellAt(local: Offset): CellModel? {
        val root = gridCoords?.localToRoot(local) ?: return null
        val key = bounds.entries.firstOrNull { it.value.inflate(gapPx).contains(root) }?.key ?: return null
        return currentCells.firstOrNull { it.key == key }
    }

    fun touch(local: Offset) {
        val c = cellAt(local)
        if (c != null && !c.isDir && c.key !in dragKeys) dragKeys.add(c.key)
    }

    // While the finger rests near an edge the grid scrolls; the cell under the (stationary) finger changes, so test again.
    LaunchedEffect(dragging) {
        while (dragging) {
            val step = autoScroll
            if (step != 0f) {
                state.scrollBy(step)
                touch(pointer)
            }
            withFrameNanos { }
        }
    }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(140.dp),
        state = state,
        modifier = modifier
            .onGloballyPositioned { gridCoords = it }
            .pointerInput(Unit) {
                awaitEachGesture {
                    // Watch (without consuming) in the Initial pass so that taps and normal scrolling work unchanged.
                    val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    if (!currentDragEnabled) return@awaitEachGesture
                    val slop = viewConfiguration.touchSlop
                    val heldLongEnough = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                        while (true) {
                            val change = awaitPointerEvent(PointerEventPass.Initial).changes.firstOrNull { it.id == down.id }
                                ?: return@withTimeoutOrNull
                            if (change.changedToUpIgnoreConsumed() || (change.position - down.position).getDistance() > slop) return@withTimeoutOrNull
                        }
                    } == null
                    if (!heldLongEnough) return@awaitEachGesture            // a tap or a scroll: not ours

                    val start = cellAt(down.position)
                    if (start == null || start.isDir) return@awaitEachGesture

                    // From here on the gesture is a drag-selection: consume everything so the grid does not scroll or click.
                    dragSelecting = !start.selected
                    dragKeys.clear(); dragKeys.add(start.key)
                    pointer = down.position
                    dragging = true
                    currentOnDragActive(true)
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    val edge = 72.dp.toPx()
                    val maxStep = 26.dp.toPx()
                    while (true) {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        val change = event.changes.firstOrNull { it.id == down.id }
                        if (change == null || change.changedToUpIgnoreConsumed() || !change.pressed) {
                            event.changes.forEach { it.consume() }
                            break
                        }
                        change.consume()
                        pointer = change.position
                        touch(change.position)
                        val y = change.position.y
                        val h = size.height.toFloat()
                        autoScroll = when {
                            y < edge -> -maxStep * ((edge - y) / edge).coerceIn(0f, 1f)
                            y > h - edge -> maxStep * ((y - (h - edge)) / edge).coerceIn(0f, 1f)
                            else -> 0f
                        }
                    }
                    autoScroll = 0f
                    dragging = false
                    val keys = dragKeys.toList()
                    val select = dragSelecting
                    dragKeys.clear()
                    currentOnDragSelect(keys, select)
                    currentOnDragActive(false)
                }
            },
        contentPadding = PaddingValues(
            start = 8.dp, end = 8.dp,
            top = contentPadding.calculateTopPadding() + 8.dp,
            bottom = contentPadding.calculateBottomPadding() + 8.dp
        ),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(cells, key = { it.key }) { cell ->
            DisposableEffect(cell.key) { onDispose { bounds.remove(cell.key) } }
            // while dragging, cells the finger has passed over already show their coming state
            val shown = if (cell.key in dragKeys) cell.copy(selected = dragSelecting) else cell
            PickerCell(
                shown,
                onClick = { onClick(cell) },
                modifier = Modifier.onGloballyPositioned { bounds[cell.key] = it.boundsInRoot() }
            )
        }
    }
}

@Composable
private fun PickerCell(cell: CellModel, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth().clickable(onClick = onClick),
        border = if (cell.selected) BorderStroke(3.dp, MaterialTheme.colorScheme.primary) else null
    ) {
        Box(
            Modifier.fillMaxWidth().height(150.dp).background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            if (cell.isDir) {
                Text("FOLDER", style = MaterialTheme.typography.labelLarge)
            } else {
                Thumb(cell.key, cell.input, Modifier.fillMaxSize())
                Checkbox(checked = cell.selected, onCheckedChange = null, modifier = Modifier.align(Alignment.TopEnd))
            }
        }
        Column(Modifier.padding(8.dp)) {
            Text(cell.name, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
            cell.subtitle?.let { Text(it, style = MaterialTheme.typography.labelSmall) }
            cell.status?.let {
                Text(
                    it, style = MaterialTheme.typography.labelSmall, maxLines = 4, overflow = TextOverflow.Ellipsis,
                    color = if (cell.statusIsError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
fun MessageDialog(message: String?, isError: Boolean, onDismiss: () -> Unit) {
    if (message == null) return
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isError) "Can't continue" else "Done") },
        text = { Text(message) },
        confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } }
    )
}
