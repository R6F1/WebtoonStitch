package com.webtoonstitch.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.changedToUpIgnoreConsumed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.webtoonstitch.app.ThumbnailCache
import com.webtoonstitch.engine.ImageInput
import kotlinx.coroutines.delay

/** What the grid needs to draw one cell, independent of which tool is showing it. */
@Immutable
data class CellModel(
    val key: String,
    val name: String,
    val isDir: Boolean,
    val selected: Boolean,
    val subtitle: String?,
    val status: String?,
    val statusIsError: Boolean,
    val input: ImageInput?
)

@Composable
fun KeepScreenOn(on: Boolean) {
    val view = LocalView.current
    DisposableEffect(on) {
        view.keepScreenOn = on
        onDispose { view.keepScreenOn = false }
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// Compact building blocks. They are plain Box/Text so that they are exactly as tall as their content (Material buttons keep
// a 48dp minimum touch height, which made the old bars about twice as tall as necessary). Touch targets stay >= 40dp.
// ---------------------------------------------------------------------------------------------------------------------

private val BarHeight = 40.dp

@Composable
fun BarAction(label: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Box(
        modifier
            .defaultMinSize(minWidth = 40.dp)
            .height(BarHeight)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1,
            color = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
        )
    }
}

@Composable
fun ActionButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, filled: Boolean = true) {
    val scheme = MaterialTheme.colorScheme
    val bg = when { !enabled -> scheme.onSurface.copy(alpha = 0.12f); filled -> scheme.primary; else -> Color.Transparent }
    val fg = when { !enabled -> scheme.onSurface.copy(alpha = 0.38f); filled -> scheme.onPrimary; else -> scheme.primary }
    Box(
        modifier
            .height(BarHeight)
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = fg, maxLines = 1) }
}

/** Title row for screens that have no grid yet (folder not chosen). */
@Composable
fun BackBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        BarAction("‹ Back", onBack)
        Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 1)
    }
}

/** 2 | 3 column switch. The current mode is highlighted. */
@Composable
private fun ColumnsSwitch(columns: Int, onChange: (Int) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Row(Modifier.clip(RoundedCornerShape(8.dp)).background(scheme.surfaceVariant)) {
        for (n in intArrayOf(2, 3)) {
            val on = n == columns
            Box(
                Modifier.height(30.dp).defaultMinSize(minWidth = 34.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (on) scheme.primary else Color.Transparent)
                    .clickable(role = Role.RadioButton) { onChange(n) },
                contentAlignment = Alignment.Center
            ) { Text("$n", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = if (on) scheme.onPrimary else scheme.onSurfaceVariant) }
        }
    }
}

/** One slim row: back, title + current folder, optional up, 2|3 view switch, change folder. About 44dp tall. */
@Composable
fun CompactTopBar(
    title: String, folderPath: String, canGoUp: Boolean, busy: Boolean,
    columns: Int, onColumns: (Int) -> Unit,
    onBack: () -> Unit, onUp: () -> Unit, onChangeFolder: () -> Unit
) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        BarAction("‹", onBack, enabled = true)
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(folderPath, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (canGoUp) BarAction("↑", onUp, enabled = !busy)
        ColumnsSwitch(columns, onColumns)
        BarAction("Folder", onChangeFolder, enabled = !busy)
    }
}

/**
 * Compact bottom panel shared by both tools: one summary line (+ optional capacity bar), one action row. While a job runs the
 * action row becomes "progress text + Cancel" with a thin progress bar.
 */
@Composable
fun CompactPanel(
    summary: String, capacityFraction: Float?, output: String, busy: Boolean, jobTitle: String?, jobFraction: Float,
    clearEnabled: Boolean, primaryLabel: String, primaryEnabled: Boolean,
    onChangeOutput: () -> Unit, onClear: () -> Unit, onPrimary: () -> Unit, onCancel: () -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp).padding(top = 4.dp, bottom = 2.dp)) {
        Text(summary, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (capacityFraction != null) {
            LinearProgressIndicator(progress = { capacityFraction.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(top = 3.dp).height(3.dp))
        }
        if (busy) {
            Text(jobTitle ?: "", fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp))
            LinearProgressIndicator(progress = { jobFraction.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(top = 2.dp).height(3.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { ActionButton("Cancel", onCancel, filled = false) }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("Output: $output", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                BarAction("Change", onChangeOutput)
                ActionButton("Clear", onClear, enabled = clearEnabled, filled = false)
                ActionButton(primaryLabel, onPrimary, enabled = primaryEnabled)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// Scroll-direction aware chrome
// ---------------------------------------------------------------------------------------------------------------------

private const val HIDE_AFTER_DP = 24f     // finger travel (while scrolling down) before the UI hides
private const val SHOW_AFTER_DP = 6f      // finger travel (while scrolling up) before the UI returns: deliberately small = "fast"

/**
 * Full-screen layout: the grid fills the screen. The top bar and the bottom panel are overlays that
 *  - slide away completely when the user scrolls DOWN through the list,
 *  - slide back quickly as soon as the user scrolls UP (or the list is at its very top),
 *  - leave NO space behind: the grid is never padded or resized. At rest the first/last row are kept clear of the bars by spacer
 *    ITEMS inside the grid (see [PickerGrid]) which simply scroll away with the content.
 * A drag-selection hides them too and brings them back when it ends. When a job starts, [keepVisible] turns true and they are
 * shown again once; after that they follow the scroll direction like normal.
 *
 * [content] receives the heights of the two bars (for the grid's spacer items) and a callback reporting drag-selection activity.
 */
@Composable
fun AutoHidingBars(
    gridState: LazyGridState,
    keepVisible: Boolean,
    top: @Composable () -> Unit,
    bottom: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable (topSpace: Dp, bottomSpace: Dp, onDragActive: (Boolean) -> Unit) -> Unit
) {
    val density = LocalDensity.current
    val visible = remember { mutableStateOf(true) }
    var dragActive by remember { mutableStateOf(false) }
    var topPx by remember { androidx.compose.runtime.mutableIntStateOf(0) }
    var bottomPx by remember { androidx.compose.runtime.mutableIntStateOf(0) }

    val hidePx = with(density) { HIDE_AFTER_DP.dp.toPx() }
    val showPx = with(density) { SHOW_AFTER_DP.dp.toPx() }
    val connection = remember(hidePx, showPx) {
        object : NestedScrollConnection {
            private var travel = 0f      // signed finger travel since the direction last changed; negative = content moving up (scrolling down)
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                val dy = available.y
                if (dy == 0f) return Offset.Zero
                if (travel * dy < 0f) travel = 0f
                travel += dy
                if (travel <= -hidePx) { if (visible.value) visible.value = false }
                else if (travel >= showPx) { if (!visible.value) visible.value = true }
                return Offset.Zero       // never consumes: the grid scrolls exactly as before
            }
        }
    }

    // At the very top the bars are always shown (the first row sits below them; hiding there would leave an empty strip).
    LaunchedEffect(gridState) {
        snapshotFlow { gridState.canScrollBackward }.collect { canBack -> if (!canBack) visible.value = true }
    }
    LaunchedEffect(keepVisible) { if (keepVisible) visible.value = true }

    val show = visible.value && !dragActive
    val barColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f)
    val enter = 140; val exit = 170

    Box(modifier.fillMaxSize().nestedScroll(connection)) {
        Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal))) {
            content(
                with(density) { topPx.toDp() }, with(density) { bottomPx.toDp() },
                { active -> dragActive = active; if (!active) visible.value = true }
            )
        }
        AnimatedVisibility(
            visible = show,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn(tween(enter)) + slideInVertically(tween(enter)) { -it },
            exit = fadeOut(tween(exit)) + slideOutVertically(tween(exit)) { -it }
        ) {
            Surface(color = barColor, modifier = Modifier.fillMaxWidth().onSizeChanged { topPx = it.height }) {
                Box(Modifier.windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal))) { top() }
            }
        }
        AnimatedVisibility(
            visible = show,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(tween(enter)) + slideInVertically(tween(enter)) { it },
            exit = fadeOut(tween(exit)) + slideOutVertically(tween(exit)) { it }
        ) {
            Surface(color = barColor, modifier = Modifier.fillMaxWidth().onSizeChanged { bottomPx = it.height }) {
                Box(Modifier.windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal))) { bottom() }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// Grid
// ---------------------------------------------------------------------------------------------------------------------

private class ThumbResult(val bitmap: android.graphics.Bitmap?, val error: String?)

/**
 * Display-only preview. A cached preview is shown immediately (no flash, no work). Otherwise a decode is requested after a short
 * delay: cells that a fast fling passes over leave the composition before the delay ends, so they cost nothing. The request is
 * cancelled when the cell leaves the screen. The preview is never used for output files.
 */
@Composable
fun Thumb(cellKey: String, input: ImageInput?, side: Int, modifier: Modifier = Modifier) {
    val result: State<ThumbResult?> = produceState<ThumbResult?>(
        initialValue = ThumbnailCache.peek(cellKey, side)?.let { ThumbResult(it, null) },
        cellKey, side
    ) {
        if (input == null || value != null) return@produceState
        delay(50)
        val b = ThumbnailCache.get(cellKey, input, side)
        value = ThumbResult(b, if (b == null) ThumbnailCache.failureOf(cellKey, side) else null)
    }
    val r = result.value
    val bmp = r?.bitmap
    if (bmp != null) {
        val image = remember(bmp) { bmp.asImageBitmap() }
        Image(bitmap = image, contentDescription = null, modifier = modifier, contentScale = ContentScale.Fit)
    } else if (r?.error != null) {
        // not "still loading": say what went wrong (the file can still be selected; its real error is shown on selection)
        Text("No preview: ${r.error}", style = MaterialTheme.typography.labelSmall, maxLines = 5, overflow = TextOverflow.Ellipsis, modifier = modifier.padding(6.dp))
    }
}

/**
 * Thumbnail grid. Tap = select / deselect (folders open). LONG-PRESS an image and then DRAG across others to select (or, if the
 * long-pressed image was already selected, to deselect) all images the finger passes over; near the top/bottom edge the grid
 * scrolls by itself. An ordinary swipe still scrolls. The images touched are handed over together, in touch order, at the end.
 *
 * [topSpace]/[bottomSpace] are the heights of the overlay bars. They are realised as full-width spacer ITEMS (not content padding),
 * so when the bars are hidden nothing is reserved: the grid simply uses the whole screen.
 *
 * Hit-testing uses the grid's own layout info (no per-cell position callbacks): the grid has no content padding, so item offsets
 * are in the same coordinate space as the pointer.
 */
@Composable
fun PickerGrid(
    cells: List<CellModel>,
    columns: Int,
    thumbSide: Int,
    onClick: (CellModel) -> Unit,
    onDragSelect: (keys: List<String>, select: Boolean) -> Unit,
    onDragActive: (Boolean) -> Unit,
    dragEnabled: Boolean,
    state: LazyGridState,
    topSpace: Dp,
    bottomSpace: Dp,
    modifier: Modifier = Modifier
) {
    val cellsByKey = remember(cells) { cells.associateBy { it.key } }
    val currentCells by rememberUpdatedState(cellsByKey)
    val currentOnDragSelect by rememberUpdatedState(onDragSelect)
    val currentOnDragActive by rememberUpdatedState(onDragActive)
    val currentDragEnabled by rememberUpdatedState(dragEnabled)
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    val gap = 6.dp
    val gapPx = with(density) { gap.toPx() }

    val dragOrder = remember { ArrayList<String>() }                       // touch order (not observed)
    var dragSet by remember { mutableStateOf(emptySet<String>()) }         // observed by the cells that must show the coming state
    var dragSelecting by remember { mutableStateOf(true) }
    var dragging by remember { mutableStateOf(false) }
    var pointer by remember { mutableStateOf(Offset.Zero) }
    var autoScroll by remember { mutableFloatStateOf(0f) }

    fun cellAt(p: Offset): CellModel? {
        for (item in state.layoutInfo.visibleItemsInfo) {
            val key = item.key as? String ?: continue
            val cell = currentCells[key] ?: continue                        // spacer items are not cells
            val l = item.offset.x - gapPx; val t = item.offset.y - gapPx
            if (p.x >= l && p.x < item.offset.x + item.size.width + gapPx && p.y >= t && p.y < item.offset.y + item.size.height + gapPx) return cell
        }
        return null
    }

    fun touch(p: Offset) {
        val c = cellAt(p)
        if (c != null && !c.isDir && c.key !in dragSet) { dragOrder.add(c.key); dragSet = dragSet + c.key }
    }

    // While the finger rests near an edge the grid scrolls; the cell under the (stationary) finger changes, so test again.
    LaunchedEffect(dragging) {
        while (dragging) {
            val step = autoScroll
            if (step != 0f) {
                state.scrollBy(step)
                touch(pointer)
            }
            withFrameNanos { }
        }
    }

    LazyVerticalGrid(
        columns = GridCells.Fixed(columns),
        state = state,
        modifier = modifier
            .padding(horizontal = gap)
            .pointerInput(Unit) {
                awaitEachGesture {
                    // Watch (without consuming) in the Initial pass so that taps and normal scrolling work unchanged.
                    val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    if (!currentDragEnabled) return@awaitEachGesture
                    val slop = viewConfiguration.touchSlop
                    val heldLongEnough = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                        while (true) {
                            val change = awaitPointerEvent(PointerEventPass.Initial).changes.firstOrNull { it.id == down.id }
                                ?: return@withTimeoutOrNull
                            if (change.changedToUpIgnoreConsumed() || (change.position - down.position).getDistance() > slop) return@withTimeoutOrNull
                        }
                    } == null
                    if (!heldLongEnough) return@awaitEachGesture            // a tap or a scroll: not ours

                    val start = cellAt(down.position)
                    if (start == null || start.isDir) return@awaitEachGesture

                    // From here on the gesture is a drag-selection: consume everything so the grid does not scroll or click.
                    dragSelecting = !start.selected
                    dragOrder.clear(); dragOrder.add(start.key); dragSet = setOf(start.key)
                    pointer = down.position
                    dragging = true
                    currentOnDragActive(true)
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    val edge = 72.dp.toPx()
                    val maxStep = 26.dp.toPx()
                    while (true) {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        val change = event.changes.firstOrNull { it.id == down.id }
                        if (change == null || change.changedToUpIgnoreConsumed() || !change.pressed) {
                            event.changes.forEach { it.consume() }
                            break
                        }
                        change.consume()
                        pointer = change.position
                        touch(change.position)
                        val y = change.position.y
                        val h = size.height.toFloat()
                        autoScroll = when {
                            y < edge -> -maxStep * ((edge - y) / edge).coerceIn(0f, 1f)
                            y > h - edge -> maxStep * ((y - (h - edge)) / edge).coerceIn(0f, 1f)
                            else -> 0f
                        }
                    }
                    autoScroll = 0f
                    dragging = false
                    val keys = dragOrder.toList()
                    val select = dragSelecting
                    dragOrder.clear(); dragSet = emptySet()
                    currentOnDragSelect(keys, select)
                    currentOnDragActive(false)
                }
            },
        horizontalArrangement = Arrangement.spacedBy(gap),
        verticalArrangement = Arrangement.spacedBy(gap)
    ) {
        item(key = "__top", span = { GridItemSpan(maxLineSpan) }, contentType = "space") { Spacer(Modifier.height(topSpace)) }
        items(cells, key = { it.key }, contentType = { if (it.isDir) "dir" else "image" }) { cell ->
            // while dragging, cells the finger has passed over already show their coming state
            val shown = if (dragging && cell.key in dragSet) cell.copy(selected = dragSelecting) else cell
            PickerCell(shown, thumbSide, onClick = { onClick(cell) })
        }
        item(key = "__bottom", span = { GridItemSpan(maxLineSpan) }, contentType = "space") { Spacer(Modifier.height(bottomSpace)) }
    }
}

@Composable
private fun PickerCell(cell: CellModel, thumbSide: Int, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth().clickable(onClick = onClick),
        border = if (cell.selected) BorderStroke(3.dp, MaterialTheme.colorScheme.primary) else null
    ) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(1f).background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            if (cell.isDir) {
                Text("FOLDER", style = MaterialTheme.typography.labelLarge)
            } else {
                Thumb(cell.key, cell.input, thumbSide, Modifier.fillMaxSize())
                Checkbox(checked = cell.selected, onCheckedChange = null, modifier = Modifier.align(Alignment.TopEnd))
            }
        }
        Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
            Text(cell.name, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
            cell.subtitle?.let { Text(it, style = MaterialTheme.typography.labelSmall) }
            cell.status?.let {
                Text(
                    it, style = MaterialTheme.typography.labelSmall, maxLines = 4, overflow = TextOverflow.Ellipsis,
                    color = if (cell.statusIsError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
fun MessageDialog(message: String?, isError: Boolean, onDismiss: () -> Unit) {
    if (message == null) return
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isError) "Can't continue" else "Done") },
        text = { Text(message) },
        confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } }
    )
}
