package com.webtoonstitch.app.vm

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.webtoonstitch.app.saf.DirEntry
import com.webtoonstitch.app.saf.FolderRef
import com.webtoonstitch.app.saf.Saf
import com.webtoonstitch.app.saf.SafImageInput
import com.webtoonstitch.app.saf.SafOutputFolder
import com.webtoonstitch.engine.AddResult
import com.webtoonstitch.engine.Candidate
import com.webtoonstitch.engine.CancelCheck
import com.webtoonstitch.engine.DetectedFormat
import com.webtoonstitch.engine.EngineException
import com.webtoonstitch.engine.ImageDecoders
import com.webtoonstitch.engine.Jobs
import com.webtoonstitch.engine.MAX_STITCH_HEIGHT
import com.webtoonstitch.engine.NaturalFilenameComparator
import com.webtoonstitch.engine.StitchSelection
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext

/** [formatLabel] is decided from the file's first bytes (not its extension), e.g. "JPEG (saved as .png)"; null for a plain PNG. */
data class PickerEntry(val key: String, val name: String, val isDir: Boolean, val dimensions: String?, val selected: Boolean, val formatLabel: String? = null)

data class JobUi(val title: String, val fraction: Float)

data class StitchUiState(
    val hasFolder: Boolean = false,
    val folderPath: String = "",
    val canGoUp: Boolean = false,
    val entries: List<PickerEntry> = emptyList(),
    val selectedCount: Int = 0,
    val totalHeight: Int = 0,
    val remainingHeight: Int = MAX_STITCH_HEIGHT,
    val maxHeight: Int = MAX_STITCH_HEIGHT,
    val outputLabel: String = "",
    val job: JobUi? = null,
    /** Shown in a dialog: rejected selections and job results. */
    val message: String? = null,
    val messageIsError: Boolean = true,
    val loading: Boolean = false
)

class StitchViewModel(app: Application) : AndroidViewModel(app) {
    private val resolver = app.contentResolver
    private val cacheDir = app.cacheDir

    private val selection = StitchSelection()           // main-thread only
    private val inputs = java.util.concurrent.ConcurrentHashMap<String, SafImageInput>() // key -> input (read by the UI thread and by IO workers)
    private val formats = HashMap<String, DetectedFormat>()   // key -> real format, main-thread only
    private var sniffJob: Job? = null
    private val dims = HashMap<String, String>()
    private val inspecting = HashSet<String>()      // keys whose header is being read (guards double taps)
    private var stack: List<FolderRef> = emptyList()
    private var rawEntries: List<DirEntry> = emptyList()
    private var explicitOutput: FolderRef? = null   // chosen by the user
    private var selectionFolder: FolderRef? = null  // folder the first selected image came from (default output)
    private var job: Job? = null

    private val _ui = MutableStateFlow(StitchUiState())
    val ui: StateFlow<StitchUiState> = _ui.asStateFlow()

    /** Provides previews for the grid. */
    fun inputFor(entry: PickerEntry): SafImageInput? = inputs[entry.key] ?: rawEntries.firstOrNull { it.uri.toString() == entry.key }?.let { input(it) }

    private fun input(e: DirEntry) = inputs.getOrPut(e.uri.toString()) { SafImageInput(resolver, e.uri, e.name, cacheDir) }

    fun openTree(tree: Uri) {
        Saf.persist(resolver, tree)
        val root = Saf.root(resolver, tree)
        stack = listOf(root)
        refresh()
    }

    fun setOutputTree(tree: Uri) {
        Saf.persist(resolver, tree)
        explicitOutput = Saf.root(resolver, tree)
        publish()
    }

    fun openFolder(entry: PickerEntry) {
        val raw = rawEntries.firstOrNull { it.uri.toString() == entry.key && it.isDir } ?: return
        stack = stack + Saf.child(stack.last(), raw)
        refresh()
    }

    fun goUp() {
        if (stack.size > 1) { stack = stack.dropLast(1); refresh() }
    }

    private fun refresh() {
        _ui.update { it.copy(loading = true) }
        viewModelScope.launch {
            val folder = stack.last()
            val listed = try {
                withContext(Dispatchers.IO) { Saf.list(resolver, folder) }
            } catch (e: Exception) {
                _ui.update { it.copy(loading = false, message = "Could not read this folder: ${e.message}", messageIsError = true) }
                return@launch
            }
            rawEntries = listed
                .filter { it.isDir || Saf.isPngOrTiff(it) }
                .sortedWith(compareBy<DirEntry> { !it.isDir }.thenComparator { a, b -> NaturalFilenameComparator.compare(a.name, b.name) })
            publish()
            sniffFormats(rawEntries)
        }
    }

    /** Reads the first bytes of every listed file to learn what it REALLY is. Cheap (4 bytes each); labels appear as they arrive. */
    private fun sniffFormats(entries: List<DirEntry>) {
        sniffJob?.cancel()
        val todo = entries.filter { !it.isDir && it.uri.toString() !in formats }
        if (todo.isEmpty()) return
        sniffJob = viewModelScope.launch {
            var sinceLastPublish = 0
            for (e in todo) {
                val f = withContext(Dispatchers.IO) {
                    try { ImageDecoders.detect(SafImageInput(resolver, e.uri, e.name, cacheDir)) } catch (_: Exception) { null }
                }
                if (f != null) { formats[e.uri.toString()] = f; if (++sinceLastPublish >= 8) { publish(); sinceLastPublish = 0 } }
            }
            if (sinceLastPublish > 0) publish()
        }
    }

    fun toggle(entry: PickerEntry) {
        if (entry.isDir) { openFolder(entry); return }
        if (_ui.value.job != null) return
        if (selection.contains(entry.key)) {
            selection.remove(entry.key)
            publish()
            return
        }
        val raw = rawEntries.firstOrNull { it.uri.toString() == entry.key } ?: return
        viewModelScope.launch {
            val problem = tryAdd(raw)
            if (problem != null) _ui.update { it.copy(message = problem, messageIsError = true) } else publish()
        }
    }

    /**
     * Header-only inspection (pixel data is never decoded here) + the selection rules (width, format, 12,000 px).
     * Returns null when the image is selected (or already was / is being inspected), otherwise the message to show. Main thread.
     */
    private suspend fun tryAdd(raw: DirEntry): String? {
        val key = raw.uri.toString()
        if (selection.contains(key)) return null
        if (!inspecting.add(key)) return null          // guards double taps and overlapping drags
        try {
            var formatFound: DetectedFormat? = null
            val candidate = try {
                withContext(Dispatchers.IO) {
                    val inp = input(raw)
                    val fmt = ImageDecoders.detect(inp)
                    val info = ImageDecoders.inspect(inp)
                    formatFound = fmt
                    Candidate(key, raw.name, info.width, info.height, info.formatKey)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: EngineException) {
                return e.message ?: "${raw.name}: could not be read."
            } catch (e: Exception) {
                return "${raw.name}: could not read the image size (${e.message})."
            }
            formatFound?.let { formats[key] = it }
            dims[key] = "${candidate.width} × ${candidate.height}"
            val wasEmpty = selection.count == 0
            return when (val r = selection.tryAdd(candidate)) {
                is AddResult.Accepted -> { if (wasEmpty) selectionFolder = stack.lastOrNull(); null }
                is AddResult.Rejected -> r.message
            }
        } finally {
            inspecting.remove(key)
        }
    }

    /**
     * Drag-select. [keys] are the images the finger passed over, in the order they were touched.
     * select = true: they are added one after the other with the normal rules, and the first rejection (limit, width, format)
     * stops the batch and is explained; everything before it stays selected. select = false: they are removed.
     */
    fun dragSelect(keys: List<String>, select: Boolean) {
        if (_ui.value.job != null) return
        if (!select) { keys.forEach { selection.remove(it) }; publish(); return }
        viewModelScope.launch {
            var problem: String? = null
            for (key in keys) {
                val raw = rawEntries.firstOrNull { it.uri.toString() == key && !it.isDir } ?: continue
                problem = tryAdd(raw)
                if (problem != null) break
            }
            publish()
            if (problem != null) _ui.update { it.copy(message = problem, messageIsError = true) }
        }
    }

    fun clearSelection() { selection.clear(); publish() }
    fun dismissMessage() = _ui.update { it.copy(message = null) }

    fun cancel() { job?.cancel() }

    fun stitch() {
        if (selection.count == 0 || job != null) return
        val target = explicitOutput ?: selectionFolder ?: stack.lastOrNull() ?: return
        val picked = selection.items.map { c -> inputs.getValue(c.id) }
        val jpegCount = selection.items.count { formats[it.id] == DetectedFormat.JPEG }
        _ui.update { it.copy(job = JobUi("Preparing…", 0f), message = null) }
        job = viewModelScope.launch {
            val self = coroutineContext[Job]
            val cancelCheck = CancelCheck { self?.takeIf { !it.isActive }?.let { throw CancellationException("Cancelled") } }
            try {
                val result = withContext(Dispatchers.IO) {
                    Jobs.stitch(picked, SafOutputFolder(resolver, target), { p ->
                        val title = when (p.phase) {
                            Jobs.Phase.PLANNING -> "Checking images…"
                            Jobs.Phase.WRITING -> "Stitching…"
                            Jobs.Phase.VERIFYING -> "Verifying pixels…"
                        }
                        // writing = first half of the bar, verifying = second half
                        val f = if (p.phase == Jobs.Phase.VERIFYING) 0.5f + p.fraction / 2 else p.fraction / 2
                        _ui.update { it.copy(job = JobUi(title, f)) }
                    }, cancelCheck)
                }
                selection.clear()
                finish("Saved ${result.outputName}\n${result.width} × ${result.height} px · ${result.format} · ${result.sourceCount} images\nVerified identical to the source pixels." +
                    if (jpegCount > 0) "\n$jpegCount JPEG source(s) were decoded; the PNG holds exactly those decoded pixel values (no resizing, no further lossy step)." else "", false)
            } catch (e: CancellationException) {
                finish("Cancelled. No output file was kept.", false)
            } catch (e: EngineException) {
                finish(e.message ?: "Stitching failed.", true)
            } catch (e: OutOfMemoryError) {
                finish("Not enough memory to process these images. Nothing was written.", true)
            } catch (e: Exception) {
                finish("Stitching failed: ${e.message}", true)
            }
        }
    }

    private fun finish(text: String, error: Boolean) {
        job = null
        _ui.update { it.copy(job = null, message = text, messageIsError = error) }
        publish()
    }

    private fun publish() {
        val folder = stack.lastOrNull()
        _ui.update {
            it.copy(
                hasFolder = folder != null,
                folderPath = stack.joinToString(" / ") { f -> f.label },
                canGoUp = stack.size > 1,
                loading = false,
                entries = rawEntries.map { e ->
                    val key = e.uri.toString()
                    PickerEntry(key, e.name, e.isDir, dims[key], selection.contains(key), if (e.isDir) null else formats[key]?.let { f -> ImageDecoders.label(f, e.name) })
                },
                selectedCount = selection.count,
                totalHeight = selection.totalHeight,
                remainingHeight = selection.remainingHeight,
                outputLabel = (explicitOutput ?: selectionFolder ?: folder)?.label ?: ""
            )
        }
    }
}
