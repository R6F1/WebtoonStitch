package com.webtoonstitch.app.vm

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.webtoonstitch.app.saf.DirEntry
import com.webtoonstitch.app.saf.FolderRef
import com.webtoonstitch.app.saf.Saf
import com.webtoonstitch.app.saf.SafImageInput
import com.webtoonstitch.app.saf.SafOutputFolder
import com.webtoonstitch.engine.AddResult
import com.webtoonstitch.engine.Candidate
import com.webtoonstitch.engine.CancelCheck
import com.webtoonstitch.engine.EngineException
import com.webtoonstitch.engine.ImageDecoders
import com.webtoonstitch.engine.Jobs
import com.webtoonstitch.engine.MAX_STITCH_HEIGHT
import com.webtoonstitch.engine.NaturalFilenameComparator
import com.webtoonstitch.engine.StitchSelection
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext

data class PickerEntry(val key: String, val name: String, val isDir: Boolean, val dimensions: String?, val selected: Boolean)

data class JobUi(val title: String, val fraction: Float)

data class StitchUiState(
    val hasFolder: Boolean = false,
    val folderPath: String = "",
    val canGoUp: Boolean = false,
    val entries: List<PickerEntry> = emptyList(),
    val selectedCount: Int = 0,
    val totalHeight: Int = 0,
    val remainingHeight: Int = MAX_STITCH_HEIGHT,
    val maxHeight: Int = MAX_STITCH_HEIGHT,
    val outputLabel: String = "",
    val job: JobUi? = null,
    /** Shown in a dialog: rejected selections and job results. */
    val message: String? = null,
    val messageIsError: Boolean = true,
    val loading: Boolean = false
)

class StitchViewModel(app: Application) : AndroidViewModel(app) {
    private val resolver = app.contentResolver
    private val cacheDir = app.cacheDir

    private val selection = StitchSelection()           // main-thread only
    private val inputs = HashMap<String, SafImageInput>() // key -> input
    private val dims = HashMap<String, String>()
    private val inspecting = HashSet<String>()      // keys whose header is being read (guards double taps)
    private var stack: List<FolderRef> = emptyList()
    private var rawEntries: List<DirEntry> = emptyList()
    private var explicitOutput: FolderRef? = null   // chosen by the user
    private var selectionFolder: FolderRef? = null  // folder the first selected image came from (default output)
    private var job: Job? = null

    private val _ui = MutableStateFlow(StitchUiState())
    val ui: StateFlow<StitchUiState> = _ui.asStateFlow()

    /** Provides previews for the grid. */
    fun inputFor(entry: PickerEntry): SafImageInput? = inputs[entry.key] ?: rawEntries.firstOrNull { it.uri.toString() == entry.key }?.let { input(it) }

    private fun input(e: DirEntry) = inputs.getOrPut(e.uri.toString()) { SafImageInput(resolver, e.uri, e.name, cacheDir) }

    fun openTree(tree: Uri) {
        Saf.persist(resolver, tree)
        val root = Saf.root(resolver, tree)
        stack = listOf(root)
        refresh()
    }

    fun setOutputTree(tree: Uri) {
        Saf.persist(resolver, tree)
        explicitOutput = Saf.root(resolver, tree)
        publish()
    }

    fun openFolder(entry: PickerEntry) {
        val raw = rawEntries.firstOrNull { it.uri.toString() == entry.key && it.isDir } ?: return
        stack = stack + Saf.child(stack.last(), raw)
        refresh()
    }

    fun goUp() {
        if (stack.size > 1) { stack = stack.dropLast(1); refresh() }
    }

    private fun refresh() {
        _ui.update { it.copy(loading = true) }
        viewModelScope.launch {
            val folder = stack.last()
            val listed = try {
                withContext(Dispatchers.IO) { Saf.list(resolver, folder) }
            } catch (e: Exception) {
                _ui.update { it.copy(loading = false, message = "Could not read this folder: ${e.message}", messageIsError = true) }
                return@launch
            }
            rawEntries = listed
                .filter { it.isDir || Saf.isPngOrTiff(it) }
                .sortedWith(compareBy<DirEntry> { !it.isDir }.thenComparator { a, b -> NaturalFilenameComparator.compare(a.name, b.name) })
            publish()
        }
    }

    fun toggle(entry: PickerEntry) {
        if (entry.isDir) { openFolder(entry); return }
        if (_ui.value.job != null) return
        if (selection.contains(entry.key)) {
            selection.remove(entry.key)
            publish()
            return
        }
        val raw = rawEntries.firstOrNull { it.uri.toString() == entry.key } ?: return
        if (!inspecting.add(entry.key)) return
        viewModelScope.launch {
            val candidate = try {
                withContext(Dispatchers.IO) {
                    // Header-only inspection: pixel data is never decoded here.
                    val info = ImageDecoders.inspect(input(raw))
                    Candidate(raw.uri.toString(), raw.name, info.width, info.height, info.formatKey)
                }
            } catch (e: EngineException) {
                inspecting.remove(entry.key)
                _ui.update { it.copy(message = e.message, messageIsError = true) }
                return@launch
            } catch (e: Exception) {
                inspecting.remove(entry.key)
                _ui.update { it.copy(message = "${raw.name}: could not read the image size (${e.message}).", messageIsError = true) }
                return@launch
            }
            inspecting.remove(entry.key)
            dims[entry.key] = "${candidate.width} × ${candidate.height}"
            val wasEmpty = selection.count == 0
            when (val r = selection.tryAdd(candidate)) {
                is AddResult.Accepted -> { if (wasEmpty) selectionFolder = stack.lastOrNull(); publish() }
                is AddResult.Rejected -> _ui.update { it.copy(message = r.message, messageIsError = true) }
            }
        }
    }

    fun clearSelection() { selection.clear(); publish() }
    fun dismissMessage() = _ui.update { it.copy(message = null) }

    fun cancel() { job?.cancel() }

    fun stitch() {
        if (selection.count == 0 || job != null) return
        val target = explicitOutput ?: selectionFolder ?: stack.lastOrNull() ?: return
        val picked = selection.items.map { c -> inputs.getValue(c.id) }
        _ui.update { it.copy(job = JobUi("Preparing…", 0f), message = null) }
        job = viewModelScope.launch {
            val self = coroutineContext[Job]
            val cancelCheck = CancelCheck { self?.takeIf { !it.isActive }?.let { throw CancellationException("Cancelled") } }
            try {
                val result = withContext(Dispatchers.IO) {
                    Jobs.stitch(picked, SafOutputFolder(resolver, target), { p ->
                        val title = when (p.phase) {
                            Jobs.Phase.PLANNING -> "Checking images…"
                            Jobs.Phase.WRITING -> "Stitching…"
                            Jobs.Phase.VERIFYING -> "Verifying pixels…"
                        }
                        // writing = first half of the bar, verifying = second half
                        val f = if (p.phase == Jobs.Phase.VERIFYING) 0.5f + p.fraction / 2 else p.fraction / 2
                        _ui.update { it.copy(job = JobUi(title, f)) }
                    }, cancelCheck)
                }
                selection.clear()
                finish("Saved ${result.outputName}\n${result.width} × ${result.height} px · ${result.format} · ${result.sourceCount} images\nVerified identical to the source pixels.", false)
            } catch (e: CancellationException) {
                finish("Cancelled. No output file was kept.", false)
            } catch (e: EngineException) {
                finish(e.message ?: "Stitching failed.", true)
            } catch (e: OutOfMemoryError) {
                finish("Not enough memory to process these images. Nothing was written.", true)
            } catch (e: Exception) {
                finish("Stitching failed: ${e.message}", true)
            }
        }
    }

    private fun finish(text: String, error: Boolean) {
        job = null
        _ui.update { it.copy(job = null, message = text, messageIsError = error) }
        publish()
    }

    private fun publish() {
        val folder = stack.lastOrNull()
        _ui.update {
            it.copy(
                hasFolder = folder != null,
                folderPath = stack.joinToString(" / ") { f -> f.label },
                canGoUp = stack.size > 1,
                loading = false,
                entries = rawEntries.map { e ->
                    val key = e.uri.toString()
                    PickerEntry(key, e.name, e.isDir, dims[key], selection.contains(key))
                },
                selectedCount = selection.count,
                totalHeight = selection.totalHeight,
                remainingHeight = selection.remainingHeight,
                outputLabel = (explicitOutput ?: selectionFolder ?: folder)?.label ?: ""
            )
        }
    }
}
