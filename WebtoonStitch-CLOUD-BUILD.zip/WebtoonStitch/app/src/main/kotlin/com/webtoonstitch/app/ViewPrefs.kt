package com.webtoonstitch.app

import android.content.Context

/** Remembers the grid view mode (2 or 3 columns) across launches. Local only; nothing leaves the device. */
object ViewPrefs {
    private const val FILE = "view"
    private const val KEY_COLUMNS = "columns"

    fun columns(context: Context): Int = try {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getInt(KEY_COLUMNS, 2).let { if (it == 3) 3 else 2 }
    } catch (_: Exception) { 2 }

    fun setColumns(context: Context, columns: Int) {
        try { context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putInt(KEY_COLUMNS, if (columns == 3) 3 else 2).apply() } catch (_: Exception) {}
    }

    /** Longest side (px) of the display-only preview for a view mode: 2 columns have larger cells and get a larger preview. */
    fun thumbSide(columns: Int): Int = if (columns == 3) 320 else 512
}
