package com.webtoonstitch.app.vm

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.webtoonstitch.app.saf.DirEntry
import com.webtoonstitch.app.saf.FolderRef
import com.webtoonstitch.app.saf.Saf
import com.webtoonstitch.app.saf.SafImageInput
import com.webtoonstitch.app.saf.SafOutputFolder
import com.webtoonstitch.engine.CancelCheck
import com.webtoonstitch.engine.EngineException
import com.webtoonstitch.engine.JobOutcome
import com.webtoonstitch.engine.Jobs
import com.webtoonstitch.engine.NaturalFilenameComparator
import com.webtoonstitch.engine.Tiff
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext

enum class FileState { READY, CONVERTING, DONE, FAILED }

data class TiffEntry(
    val key: String, val name: String, val isDir: Boolean, val selected: Boolean,
    val info: String?, val state: FileState?, val statusText: String?
)

data class TiffUiState(
    val hasFolder: Boolean = false,
    val folderPath: String = "",
    val canGoUp: Boolean = false,
    val entries: List<TiffEntry> = emptyList(),
    val selectedCount: Int = 0,
    val outputLabel: String = "",
    val job: JobUi? = null,
    val message: String? = null,
    val messageIsError: Boolean = true,
    val loading: Boolean = false
)

class TiffViewModel(app: Application) : AndroidViewModel(app) {
    private val resolver = app.contentResolver
    private val cacheDir = app.cacheDir

    private val selected = LinkedHashSet<String>()
    private val inputs = java.util.concurrent.ConcurrentHashMap<String, SafImageInput>()   // read by the UI thread and by IO workers
    private val info = HashMap<String, String>()
    private val names = HashMap<String, String>()
    private val inspecting = HashSet<String>()      // guards double taps while a header is being read
    private val states = java.util.concurrent.ConcurrentHashMap<String, Pair<FileState, String?>>()   // written by the worker thread
    private var stack: List<FolderRef> = emptyList()
    private var rawEntries: List<DirEntry> = emptyList()
    private var rawByKey: Map<String, DirEntry> = emptyMap()   // O(1) lookup; rebuilt with rawEntries
    private var explicitOutput: FolderRef? = null
    private var selectionFolder: FolderRef? = null
    private var job: Job? = null

    private val _ui = MutableStateFlow(TiffUiState())
    val ui: StateFlow<TiffUiState> = _ui.asStateFlow()

    private fun input(e: DirEntry) = inputs.getOrPut(e.uri.toString()) { SafImageInput(resolver, e.uri, e.name, cacheDir) }
    fun inputFor(entry: TiffEntry): SafImageInput? = inputs[entry.key] ?: rawByKey[entry.key]?.let { input(it) }

    fun openTree(tree: Uri) {
        Saf.persist(resolver, tree)
        val root = Saf.root(resolver, tree)
        stack = listOf(root)
        refresh()
    }

    fun setOutputTree(tree: Uri) {
        Saf.persist(resolver, tree)
        explicitOutput = Saf.root(resolver, tree)
        publish()
    }

    fun goUp() { if (stack.size > 1) { stack = stack.dropLast(1); refresh() } }

    private fun refresh() {
        _ui.update { it.copy(loading = true) }
        viewModelScope.launch {
            val listed = try {
                withContext(Dispatchers.IO) { Saf.list(resolver, stack.last()) }
            } catch (e: Exception) {
                _ui.update { it.copy(loading = false, message = "Could not read this folder: ${e.message}", messageIsError = true) }
                return@launch
            }
            rawEntries = listed.filter { it.isDir || Saf.isTiff(it) }
                .sortedWith(compareBy<DirEntry> { !it.isDir }.thenComparator { a, b -> NaturalFilenameComparator.compare(a.name, b.name) })
            rawByKey = rawEntries.associateBy { it.uri.toString() }
            publish()
        }
    }

    fun toggle(entry: TiffEntry) = toggleKey(entry.key)

    /** Tap on a grid cell: open a folder, or select / deselect a file. */
    fun toggleKey(key: String) {
        if (_ui.value.job != null) return
        val raw = rawByKey[key] ?: return
        if (raw.isDir) { stack = stack + Saf.child(stack.last(), raw); refresh(); return }
        if (key in selected) { selected.remove(key); publish(); return }
        viewModelScope.launch {
            val problem = tryAdd(raw)
            if (problem != null) _ui.update { it.copy(message = problem, messageIsError = true) } else publish()   // e.g. multi-page / unsupported format, with the reason
        }
    }

    /** Header/IFD-only inspection. Returns null when the file is selected (or already was / is being inspected), else the message to show. Main thread. */
    private suspend fun tryAdd(raw: DirEntry): String? {
        val key = raw.uri.toString()
        if (key in selected) return null
        if (!inspecting.add(key)) return null          // guards double taps and overlapping drags
        try {
            val pages = withContext(Dispatchers.IO) { Tiff.inspectPages(input(raw)) }
            val ok = pages.filter { it.info != null }
            // a file is selectable when at least one page can be converted exactly; pages that cannot are reported when converting
            if (ok.isEmpty()) return pages.firstOrNull()?.problem?.message ?: "${raw.name}: contains no readable page."
            val first = ok.first().info!!
            val same = ok.all { p -> p.info!!.let { i -> i.width == first.width && i.height == first.height && i.formatLabel == first.formatLabel } }
            val skipped = pages.size - ok.size
            info[key] = when {
                pages.size == 1 -> "${first.width} × ${first.height} · ${first.formatLabel}"
                same && skipped == 0 -> "${pages.size} pages · ${first.width} × ${first.height} · ${first.formatLabel}"
                else -> "${pages.size} pages · sizes/formats differ" + if (skipped > 0) " · $skipped unsupported" else ""
            }
            states.remove(key)
            if (selected.isEmpty()) selectionFolder = stack.lastOrNull()
            names[key] = raw.name
            selected.add(key)
            return null
        } catch (e: CancellationException) {
            throw e
        } catch (e: EngineException) {
            return e.message ?: "${raw.name}: could not be read."
        } catch (e: Exception) {
            return "${raw.name}: could not be read (${e.message})."
        } finally {
            inspecting.remove(key)
        }
    }

    /**
     * Drag-select: [keys] are the files the finger passed over, in touch order. Files are independent here, so a file that cannot
     * be used (multi-page, unsupported format ...) does not stop the others; all problems are reported together.
     */
    fun dragSelect(keys: List<String>, select: Boolean) {
        if (_ui.value.job != null) return
        if (!select) { keys.forEach { selected.remove(it) }; publish(); return }
        viewModelScope.launch {
            val problems = ArrayList<String>()
            for (key in keys) {
                val raw = rawByKey[key]?.takeIf { !it.isDir } ?: continue
                tryAdd(raw)?.let { problems += it }
            }
            publish()
            if (problems.isNotEmpty()) {
                val shown = problems.take(3).joinToString("\n\n")
                val more = if (problems.size > 3) "\n\n…and ${problems.size - 3} more file(s) could not be added." else ""
                _ui.update { it.copy(message = shown + more, messageIsError = true) }
            }
        }
    }

    fun clearSelection() { selected.clear(); publish() }
    fun dismissMessage() = _ui.update { it.copy(message = null) }
    fun cancel() { job?.cancel() }

    fun convert() {
        if (selected.isEmpty() || job != null) return
        val target = explicitOutput ?: selectionFolder ?: stack.lastOrNull() ?: return
        // deterministic processing order (natural filename order), independent of the order files were tapped
        val keys = selected.sortedWith { a, b -> NaturalFilenameComparator.compare(names[a] ?: a, names[b] ?: b) }
        val picked = keys.map { inputs.getValue(it) }
        keys.forEach { states[it] = FileState.READY to null }
        _ui.update { it.copy(job = JobUi("Preparing…", 0f), message = null) }
        publish()
        job = viewModelScope.launch {
            val self = coroutineContext[Job]
            val cancelCheck = CancelCheck { self?.takeIf { !it.isActive }?.let { throw CancellationException("Cancelled") } }
            try {
                var finished = 0   // per-file results arrive strictly in input order
                val perFile = ArrayList<List<JobOutcome>>()
                val results = withContext(Dispatchers.IO) {
                    Jobs.convertTiffs(picked, SafOutputFolder(resolver, target),
                        onProgress = { p ->
                            val key = keys[p.fileIndex]
                            states[key] = FileState.CONVERTING to null
                            val overall = (p.fileIndex + p.fraction) / p.fileCount
                            _ui.update { it.copy(job = JobUi("Converting ${p.fileIndex + 1} of ${p.fileCount}: ${p.fileName}", overall)) }
                        },
                        onFileDone = { outcomes ->
                            val key = keys[finished++]
                            perFile += outcomes
                            states[key] = summarize(outcomes)
                            viewModelScope.launch(Dispatchers.Main) { publish() }   // publish() reads main-thread state
                        },
                        cancel = cancelCheck)
                }
                val ok = results.count { it is JobOutcome.Success }
                val bad = results.size - ok
                // a file leaves the selection only when ALL of its pages were converted
                val doneKeys = perFile.indices.filter { i -> perFile[i].isNotEmpty() && perFile[i].all { it is JobOutcome.Success } }.map { keys[it] }
                selected.removeAll(doneKeys.toSet())
                val noun = if (results.size == 1) "image" else "images"
                finish("Converted $ok of ${results.size} $noun (${perFile.size} file${if (perFile.size == 1) "" else "s"}; every page of a multi-page TIFF becomes its own PNG)." +
                    if (bad > 0) "\n$bad failed - see the list for the reason of each." else "\nAll outputs verified against the source pixels.", bad > 0)
            } catch (e: CancellationException) {
                clearUnfinished(keys)
                finish("Cancelled. Files already finished were kept; the file in progress was removed.", false)
            } catch (e: Exception) {
                clearUnfinished(keys)
                finish("Conversion stopped: ${e.message}", true)
            }
        }
    }

    /** One status line per input file from its per-page outcomes. */
    private fun summarize(outcomes: List<JobOutcome>): Pair<FileState, String?> {
        val good = outcomes.filterIsInstance<JobOutcome.Success>()
        val bad = outcomes.filterIsInstance<JobOutcome.Failure>()
        return when {
            bad.isEmpty() && good.size == 1 -> FileState.DONE to "→ ${good[0].outputName} (verified)"
            bad.isEmpty() -> FileState.DONE to "→ ${good.size} PNGs: ${good.first().outputName} … ${good.last().outputName} (verified)"
            good.isEmpty() -> FileState.FAILED to bad.joinToString("\n") { if (it.page > 0 && it.pageCount > 1) "Page ${it.page}: ${it.message}" else it.message }
            else -> FileState.FAILED to "${good.size} of ${outcomes.size} pages converted (${good.first().outputName} …). " +
                bad.joinToString(" ") { "Page ${it.page}: ${it.message}" }
        }
    }

    /** Files that never ran must not stay labelled "Waiting…" / "Converting…". */
    private fun clearUnfinished(keys: List<String>) {
        for (k in keys) { val st = states[k]?.first; if (st == FileState.READY || st == FileState.CONVERTING) states.remove(k) }
    }

    private fun finish(text: String, error: Boolean) {
        job = null
        _ui.update { it.copy(job = null, message = text, messageIsError = error) }
        publish()
    }

    private fun publish() {
        val folder = stack.lastOrNull()
        _ui.update {
            it.copy(
                hasFolder = folder != null,
                folderPath = stack.joinToString(" / ") { f -> f.label },
                canGoUp = stack.size > 1,
                loading = false,
                entries = rawEntries.map { e ->
                    val k = e.uri.toString()
                    TiffEntry(k, e.name, e.isDir, k in selected, info[k], states[k]?.first, states[k]?.second)
                },
                selectedCount = selected.size,
                outputLabel = (explicitOutput ?: selectionFolder ?: folder)?.label ?: ""
            )
        }
    }
}
