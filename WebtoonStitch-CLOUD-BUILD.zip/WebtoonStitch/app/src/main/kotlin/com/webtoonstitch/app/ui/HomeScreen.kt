package com.webtoonstitch.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(modifier: Modifier = Modifier, onStitch: () -> Unit, onTiff: () -> Unit, onRename: () -> Unit) {
    Column(
        modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Webtoon Stitch", style = MaterialTheme.typography.headlineLarge)
        Text(
            "Preserve the original image. Nothing is resized, cropped, resampled or recompressed lossily.",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 8.dp)
        )
        Spacer(Modifier.height(28.dp))
        ToolCard(
            title = "Image Stitching",
            description = "Join PNG panels (same width) top-to-bottom into one gapless PNG. Up to 12,000 px combined height.",
            button = "Select Images",
            onClick = onStitch
        )
        Spacer(Modifier.height(16.dp))
        ToolCard(
            title = "TIFF to PNG",
            description = "Convert single-page TIFF files to PNG with identical pixels, bit depth and colour profile.",
            button = "Select TIFF Files",
            onClick = onTiff
        )
        Spacer(Modifier.height(16.dp))
        ToolCard(
            title = "Mass PNG Rename",
            description = "Rename files like 001-008 (1).png to 001.png, 002.png … in place. Only the name changes; the image bytes are never touched.",
            button = "Select PNG Folder",
            onClick = onRename
        )
    }
}

@Composable
private fun ToolCard(title: String, description: String, button: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            Text(description, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 8.dp))
            Button(onClick = onClick, modifier = Modifier.fillMaxWidth()) { Text(button) }
        }
    }
}
