package com.webtoonstitch.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.webtoonstitch.app.ViewPrefs
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.webtoonstitch.app.vm.StitchViewModel
import com.webtoonstitch.engine.StitchSelection

@Composable
fun StitchScreen(modifier: Modifier = Modifier, onBack: () -> Unit, vm: StitchViewModel = viewModel()) {
    val ui by vm.ui.collectAsState()
    val pickInput = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let(vm::openTree) }
    val pickOutput = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let(vm::setOutputTree) }
    val busy = ui.job != null

    KeepScreenOn(busy)
    BackHandler { if (ui.canGoUp && !busy) vm.goUp() else onBack() }

    if (!ui.hasFolder) {
        Column(modifier.fillMaxSize().safeDrawingPadding()) {
            BackBar("Image Stitching", onBack)
            Column(
                Modifier.weight(1f).fillMaxWidth().padding(24.dp),
                verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Choose the folder that contains your PNG panels.", style = MaterialTheme.typography.bodyLarge)
                Text(
                    "Images are always stitched in natural filename order (001, 002, 010 …), top to bottom. " +
                        "Tip: tap an image to select it, or long-press an image and drag across others to select many at once.",
                    style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp)
                )
                Button(onClick = { pickInput.launch(null) }) { Text("Select Images") }
            }
        }
    } else {
        val gridState = rememberLazyGridState()
        val context = LocalContext.current
        var columns by remember { mutableIntStateOf(ViewPrefs.columns(context)) }
        val cells = remember(ui.entries) {
            ui.entries.map { e ->
                CellModel(e.key, e.name, e.isDir, e.selected, listOfNotNull(e.formatLabel, e.dimensions?.plus(" px")).joinToString(" · ").ifEmpty { null }, null, false, if (e.isDir) null else vm.inputFor(e))
            }
        }
        AutoHidingBars(
            gridState = gridState,
            keepVisible = busy,
            modifier = modifier,
            top = {
                CompactTopBar(
                    title = "Image Stitching", folderPath = ui.folderPath, canGoUp = ui.canGoUp, busy = busy,
                    columns = columns, onColumns = { columns = it; ViewPrefs.setColumns(context, it) },
                    onBack = onBack, onUp = vm::goUp, onChangeFolder = { pickInput.launch(null) }
                )
            },
            bottom = {
                CompactPanel(
                    summary = "${ui.selectedCount} selected · ${StitchSelection.fmt(ui.totalHeight)} / ${StitchSelection.fmt(ui.maxHeight)} px (${StitchSelection.fmt(ui.remainingHeight)} left)",
                    capacityFraction = ui.totalHeight.toFloat() / ui.maxHeight,
                    output = ui.outputLabel, busy = busy, jobTitle = ui.job?.title, jobFraction = ui.job?.fraction ?: 0f,
                    clearEnabled = ui.selectedCount > 0, primaryLabel = "Stitch to PNG", primaryEnabled = ui.selectedCount > 0,
                    onChangeOutput = { pickOutput.launch(null) }, onClear = vm::clearSelection, onPrimary = vm::stitch, onCancel = vm::cancel
                )
            }
        ) { topSpace, bottomSpace, setDragActive ->
            PickerGrid(
                cells = cells,
                columns = columns,
                thumbSide = ViewPrefs.thumbSide(columns),
                onClick = { cell -> vm.toggleKey(cell.key) },
                onDragSelect = vm::dragSelect,
                onDragActive = setDragActive,
                dragEnabled = !busy,
                state = gridState,
                topSpace = topSpace,
                bottomSpace = bottomSpace,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
    MessageDialog(ui.message, ui.messageIsError, vm::dismissMessage)
}
