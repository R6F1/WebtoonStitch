package com.webtoonstitch.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.webtoonstitch.app.vm.StitchViewModel
import com.webtoonstitch.engine.StitchSelection

@Composable
fun StitchScreen(modifier: Modifier = Modifier, onBack: () -> Unit, vm: StitchViewModel = viewModel()) {
    val ui by vm.ui.collectAsState()
    val pickInput = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let(vm::openTree) }
    val pickOutput = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let(vm::setOutputTree) }
    val busy = ui.job != null

    KeepScreenOn(busy)
    BackHandler { if (ui.canGoUp && !busy) vm.goUp() else onBack() }

    if (!ui.hasFolder) {
        Column(modifier.fillMaxSize().safeDrawingPadding()) {
            BackBar("Image Stitching", onBack)
            Column(
                Modifier.weight(1f).fillMaxWidth().padding(24.dp),
                verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Choose the folder that contains your PNG panels.", style = MaterialTheme.typography.bodyLarge)
                Text(
                    "Images are always stitched in natural filename order (001, 002, 010 …), top to bottom. " +
                        "Tip: tap an image to select it, or long-press an image and drag across others to select many at once.",
                    style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp)
                )
                Button(onClick = { pickInput.launch(null) }) { Text("Select Images") }
            }
        }
    } else {
        val gridState = rememberLazyGridState()
        AutoHidingBars(
            gridState = gridState,
            keepVisible = busy,
            modifier = modifier,
            top = {
                Column {
                    BackBar("Image Stitching", onBack)
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (ui.canGoUp) TextButton(onClick = vm::goUp, enabled = !busy) { Text("↑ Up") }
                        Text(ui.folderPath, style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f), maxLines = 1)
                        TextButton(onClick = { pickInput.launch(null) }, enabled = !busy) { Text("Change folder") }
                    }
                }
            },
            bottom = {
                SummaryPanel(
                    selectedCount = ui.selectedCount,
                    totalHeight = ui.totalHeight,
                    remaining = ui.remainingHeight,
                    maxHeight = ui.maxHeight,
                    output = ui.outputLabel,
                    jobTitle = ui.job?.title,
                    jobFraction = ui.job?.fraction ?: 0f,
                    busy = busy,
                    onChangeOutput = { pickOutput.launch(null) },
                    onClear = vm::clearSelection,
                    onStitch = vm::stitch,
                    onCancel = vm::cancel
                )
            }
        ) { padding, setDragActive ->
            PickerGrid(
                cells = ui.entries.map { e ->
                    CellModel(e.key, e.name, e.isDir, e.selected, listOfNotNull(e.formatLabel, e.dimensions?.plus(" px")).joinToString(" · ").ifEmpty { null }, null, false, if (e.isDir) null else vm.inputFor(e))
                },
                onClick = { cell -> ui.entries.firstOrNull { it.key == cell.key }?.let(vm::toggle) },
                onDragSelect = vm::dragSelect,
                onDragActive = setDragActive,
                dragEnabled = !busy,
                state = gridState,
                contentPadding = padding,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
    MessageDialog(ui.message, ui.messageIsError, vm::dismissMessage)
}

@Composable
private fun SummaryPanel(
    selectedCount: Int, totalHeight: Int, remaining: Int, maxHeight: Int, output: String,
    jobTitle: String?, jobFraction: Float, busy: Boolean,
    onChangeOutput: () -> Unit, onClear: () -> Unit, onStitch: () -> Unit, onCancel: () -> Unit
) {
    Card(Modifier.fillMaxWidth().padding(8.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("$selectedCount image${if (selectedCount == 1) "" else "s"} selected", style = MaterialTheme.typography.titleMedium)
            Text("Selected height: ${StitchSelection.fmt(totalHeight)} / ${StitchSelection.fmt(maxHeight)} px")
            Text("Remaining: ${StitchSelection.fmt(remaining)} px")
            LinearProgressIndicator(
                progress = { (totalHeight.toFloat() / maxHeight).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Output folder: $output", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f), maxLines = 1)
                TextButton(onClick = onChangeOutput, enabled = !busy) { Text("Change") }
            }
            if (busy) {
                Text(jobTitle ?: "", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
                LinearProgressIndicator(progress = { jobFraction.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
            } else {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onClear, enabled = selectedCount > 0) { Text("Clear") }
                    Button(onClick = onStitch, enabled = selectedCount > 0, modifier = Modifier.weight(1f)) { Text("Stitch to PNG") }
                }
            }
        }
    }
}
