package com.webtoonstitch.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.webtoonstitch.app.ui.AppTheme
import com.webtoonstitch.app.ui.HomeScreen
import com.webtoonstitch.app.ui.StitchScreen
import com.webtoonstitch.app.ui.TiffScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Remove spool files that a killed process may have left behind (only used for providers without seekable descriptors).
        cacheDir.listFiles { f -> f.name.startsWith("tiff") && f.name.endsWith(".tmp") }?.forEach { it.delete() }
        setContent {
            AppTheme {
                Surface(Modifier.fillMaxSize()) {
                    App()
                }
            }
        }
        SystemBars.hide(window)
    }

    /** Dialogs and the system folder picker can bring the bars back; hide them again whenever we regain the focus. */
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) SystemBars.hide(window)
    }
}

@Composable
private fun App() {
    var screen by rememberSaveable { mutableStateOf("home") }
    // The picker screens handle the system insets themselves (their grid may extend behind the hidden bars).
    when (screen) {
        "stitch" -> StitchScreen(onBack = { screen = "home" })
        "tiff" -> TiffScreen(onBack = { screen = "home" })
        else -> HomeScreen(modifier = Modifier.safeDrawingPadding(), onStitch = { screen = "stitch" }, onTiff = { screen = "tiff" })
    }
}
