package com.webtoonstitch.app.saf

import android.content.ContentResolver
import android.content.Intent
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import com.webtoonstitch.engine.ImageInput
import com.webtoonstitch.engine.OutputFile
import com.webtoonstitch.engine.OutputFolder
import com.webtoonstitch.engine.RandomAccess
import com.webtoonstitch.engine.TEMP_SUFFIX
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer

/** A folder inside a Storage Access Framework document tree the user granted access to. */
data class FolderRef(val tree: Uri, val docId: String, val label: String) {
    val documentUri: Uri get() = DocumentsContract.buildDocumentUriUsingTree(tree, docId)
}

data class DirEntry(val docId: String, val name: String, val mime: String, val isDir: Boolean, val uri: Uri, val size: Long)

object Saf {
    private val PROJECTION = arrayOf(
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
        DocumentsContract.Document.COLUMN_MIME_TYPE,
        DocumentsContract.Document.COLUMN_SIZE
    )

    fun persist(resolver: ContentResolver, tree: Uri) {
        try {
            resolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        } catch (_: SecurityException) {
            // Some providers do not offer persistable grants; the grant then lasts for this session only.
        }
    }

    fun root(resolver: ContentResolver, tree: Uri): FolderRef {
        val docId = DocumentsContract.getTreeDocumentId(tree)
        val docUri = DocumentsContract.buildDocumentUriUsingTree(tree, docId)
        var label = docId.substringAfterLast(':').substringAfterLast('/').ifEmpty { "Folder" }
        try {
            resolver.query(docUri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.let { label = it }
            }
        } catch (_: Exception) { /* keep fallback label */ }
        return FolderRef(tree, docId, label)
    }

    fun child(folder: FolderRef, entry: DirEntry) = FolderRef(folder.tree, entry.docId, entry.name)

    fun list(resolver: ContentResolver, folder: FolderRef): List<DirEntry> {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(folder.tree, folder.docId)
        val out = ArrayList<DirEntry>()
        resolver.query(children, PROJECTION, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                val mime = c.getString(2) ?: ""
                out += DirEntry(
                    docId = id, name = name, mime = mime,
                    isDir = mime == DocumentsContract.Document.MIME_TYPE_DIR,
                    uri = DocumentsContract.buildDocumentUriUsingTree(folder.tree, id),
                    size = if (c.isNull(3)) -1L else c.getLong(3)
                )
            }
        }
        return out
    }

    fun isPngOrTiff(e: DirEntry): Boolean {
        val ext = e.name.substringAfterLast('.', "").lowercase()
        return ext == "png" || ext == "tif" || ext == "tiff" || e.mime == "image/png" || e.mime == "image/tiff"
    }

    fun isTiff(e: DirEntry): Boolean {
        val ext = e.name.substringAfterLast('.', "").lowercase()
        return ext == "tif" || ext == "tiff" || e.mime == "image/tiff"
    }
}

/** An image the user picked, readable through its content URI (no copy is made, except the fallback noted below). */
class SafImageInput(
    private val resolver: ContentResolver,
    val uri: Uri,
    override val name: String,
    private val cacheDir: File
) : ImageInput {

    override fun openStream(): InputStream =
        resolver.openInputStream(uri) ?: throw FileNotFoundException("$name could not be opened")

    override fun openRandomAccess(): RandomAccess {
        val pfd = resolver.openFileDescriptor(uri, "r") ?: throw FileNotFoundException("$name could not be opened")
        // AutoCloseInputStream owns the descriptor: closing it closes the channel AND the pfd exactly once.
        val stream = ParcelFileDescriptor.AutoCloseInputStream(pfd)
        try {
            val channel = stream.channel
            val size = channel.size()
            // Probe that positional reads work (they do not for pipes / some network providers).
            channel.read(ByteBuffer.allocate(1), 0)
            return object : RandomAccess {
                override val length: Long = size
                override fun readAt(position: Long, buf: ByteArray, off: Int, len: Int): Int =
                    channel.read(ByteBuffer.wrap(buf, off, len), position)

                override fun close() = stream.close()
            }
        } catch (e: IOException) {
            try { stream.close() } catch (_: IOException) {}
            return copyToTempRandomAccess()
        }
    }

    /** Fallback ONLY for providers without seekable descriptors: spools to a cache file that is deleted on close. */
    private fun copyToTempRandomAccess(): RandomAccess {
        val tmp = File.createTempFile("tiff", ".tmp", cacheDir)
        try {
            openStream().use { input -> tmp.outputStream().use { input.copyTo(it, 1 shl 16) } }
            val raf = RandomAccessFile(tmp, "r")
            return object : RandomAccess {
                override val length: Long get() = raf.length()
                override fun readAt(position: Long, buf: ByteArray, off: Int, len: Int): Int {
                    raf.seek(position); return raf.read(buf, off, len)
                }
                override fun close() { try { raf.close() } finally { tmp.delete() } }
            }
        } catch (e: Throwable) {
            tmp.delete(); throw e
        }
    }
}

/**
 * Output folder implemented with the Storage Access Framework.
 *
 * Atomic save: every output is first created as `<final name>.webtoonstitch.part`, fully written and verified, and only
 * then renamed to its final name with [DocumentsContract.renameDocument]. If the process is killed (or anything fails) the
 * final name never exists in a half-written state. Existing documents are never opened for writing.
 */
class SafOutputFolder(private val resolver: ContentResolver, private val folder: FolderRef) : OutputFolder {

    override fun exists(name: String): Boolean =
        Saf.list(resolver, folder).any { it.name.equals(name, ignoreCase = true) }

    override fun createTemporary(finalNameHint: String): OutputFile {
        val taken = Saf.list(resolver, folder).map { it.name.lowercase() }.toSet()
        var tmpName = finalNameHint + TEMP_SUFFIX
        var n = 0
        while (tmpName.lowercase() in taken) tmpName = "$finalNameHint.${++n}$TEMP_SUFFIX"
        // application/octet-stream on purpose: with an image MIME type some providers (e.g. the system
        // ExternalStorageProvider) would append ".png" to a name whose extension does not match, breaking the marker.
        val uri = DocumentsContract.createDocument(resolver, folder.documentUri, "application/octet-stream", tmpName)
            ?: throw IOException("The output folder refused to create a temporary file")
        return object : OutputFile {
            override fun openOutput(): OutputStream =
                resolver.openOutputStream(uri, "w") ?: throw IOException("Cannot write to the temporary file")

            override fun openInput(): InputStream =
                resolver.openInputStream(uri) ?: throw IOException("Cannot read back the temporary file")

            override fun commit(finalName: String) {
                // Never fall back to copy+delete: that would not be atomic. If rename is unsupported, fail and let the
                // engine delete the temporary file.
                val renamed = try {
                    DocumentsContract.renameDocument(resolver, uri, finalName)
                } catch (e: UnsupportedOperationException) {
                    throw e
                } catch (e: IllegalStateException) {
                    throw UnsupportedOperationException(e.message, e)
                }
                if (renamed == null) throw IOException("The storage provider could not rename the file")
            }

            override fun delete() {
                try { DocumentsContract.deleteDocument(resolver, uri) } catch (_: Exception) { /* best effort */ }
            }
        }
    }

    override fun removeStaleTemporaries() {
        try {
            for (e in Saf.list(resolver, folder)) {
                if (!e.isDir && e.name.contains(TEMP_SUFFIX)) {
                    try { DocumentsContract.deleteDocument(resolver, e.uri) } catch (_: Exception) { }
                }
            }
        } catch (_: Exception) { /* best effort */ }
    }
}
