package com.webtoonstitch.app.vm

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.webtoonstitch.app.saf.DirEntry
import com.webtoonstitch.app.saf.FolderRef
import com.webtoonstitch.app.saf.Saf
import com.webtoonstitch.app.saf.SafRenameFolder
import com.webtoonstitch.engine.NaturalFilenameComparator
import com.webtoonstitch.engine.RenameConflict
import com.webtoonstitch.engine.RenameItem
import com.webtoonstitch.engine.RenamePlan
import com.webtoonstitch.engine.RenamePlanner
import com.webtoonstitch.engine.RenameSession
import com.webtoonstitch.engine.RenameStatus
import com.webtoonstitch.engine.SkippedFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class RenameFileRow(val name: String, val selected: Boolean)

/** What the confirmation screen shows. Nothing has been renamed while this is visible. */
data class RenamePreviewUi(
    val items: List<RenameItem>,
    val skipped: List<SkippedFile>,
    val conflicts: List<RenameConflict>,
    val duplicateNotes: List<String>,
    val canExecute: Boolean
)

data class RenameUiState(
    val hasFolder: Boolean = false,
    val folderLabel: String = "",
    val files: List<RenameFileRow> = emptyList(),
    val selectedCount: Int = 0,
    val preview: RenamePreviewUi? = null,
    val loading: Boolean = false,
    val running: Boolean = false,
    val message: String? = null,
    val messageIsError: Boolean = true
)

/**
 * Mass PNG rename. Lists the PNG files of one folder (names only: no bitmaps, no thumbnails), builds a preview from the names
 * and renames only after the user confirms. File contents are never read.
 */
class RenameViewModel(app: Application) : AndroidViewModel(app) {
    private val resolver = app.contentResolver
    private var folder: FolderRef? = null
    private var entries: List<DirEntry> = emptyList()          // everything in the folder (collision checks)
    private val selected = LinkedHashSet<String>()
    private var previewPlan: RenamePlan? = null

    private val _ui = MutableStateFlow(RenameUiState())
    val ui: StateFlow<RenameUiState> = _ui.asStateFlow()

    fun openTree(uri: Uri) {
        viewModelScope.launch {
            _ui.update { it.copy(loading = true) }
            try {
                val root = withContext(Dispatchers.IO) { Saf.persist(resolver, uri); Saf.root(resolver, uri) }
                folder = root
                selected.clear(); previewPlan = null
                reload()
                _ui.update { it.copy(hasFolder = true, folderLabel = root.label, preview = null, loading = false) }
            } catch (e: Exception) {
                _ui.update { it.copy(loading = false, message = "Could not open the folder: ${e.message ?: e.javaClass.simpleName}", messageIsError = true) }
            }
        }
    }

    private suspend fun reload() {
        val f = folder ?: return
        entries = withContext(Dispatchers.IO) { Saf.list(resolver, f) }
        selected.retainAll(pngNames().toSet())
        publish()
    }

    private fun pngNames(): List<String> =
        entries.filter { !it.isDir && (it.name.endsWith(".png", ignoreCase = true) || it.mime == "image/png") }
            .map { it.name }.sortedWith(NaturalFilenameComparator)

    private fun publish() {
        val names = pngNames()
        _ui.update { it.copy(files = names.map { n -> RenameFileRow(n, n in selected) }, selectedCount = selected.size) }
    }

    fun toggle(name: String) {
        if (_ui.value.running || _ui.value.preview != null) return
        if (!selected.remove(name)) selected.add(name)
        publish()
    }

    fun selectAll() { if (!_ui.value.running) { selected.addAll(pngNames()); publish() } }
    fun clearSelection() { if (!_ui.value.running) { selected.clear(); publish() } }

    /** Builds the preview from names only. Renames nothing. */
    fun showPreview() {
        if (selected.isEmpty() || _ui.value.running) return
        val plan = RenamePlanner.plan(selected.toList(), entries.map { it.name })
        previewPlan = plan
        _ui.update { it.copy(preview = plan.toUi()) }
    }

    fun cancelPreview() { if (!_ui.value.running) { previewPlan = null; _ui.update { it.copy(preview = null) } } }

    /** The user confirmed the preview. Re-checks the folder first; renames only if the plan is still exactly what was shown. */
    fun confirm() {
        val shown = previewPlan ?: return
        val f = folder ?: return
        if (_ui.value.running || !shown.canExecute) return
        _ui.update { it.copy(running = true) }
        val names = selected.toList()
        viewModelScope.launch {
            try {
                val fresh = withContext(Dispatchers.IO) { Saf.list(resolver, f) }
                val session = RenameSession(SafRenameFolder(resolver, fresh), names, fresh.map { it.name })
                if (session.plan.items != shown.items || !session.plan.canExecute) {
                    entries = fresh; previewPlan = session.plan; publish()
                    _ui.update {
                        it.copy(running = false, preview = session.plan.toUi(), messageIsError = true,
                            message = "The folder changed after the preview. Nothing was renamed. Please review the new preview and confirm again.")
                    }
                    return@launch
                }
                val result = withContext(Dispatchers.IO) { session.confirmAndRun() }
                val ok = result.status == RenameStatus.DONE
                if (ok) selected.clear()
                previewPlan = null
                reload()
                val text = if (ok) {
                    "Renamed ${result.renamed.size} file(s) in place (names only; image data was not touched)." +
                        if (result.skipped.isNotEmpty()) "\nSkipped ${result.skipped.size} file(s) without a numeric range; they were not changed." else ""
                } else result.message
                _ui.update { it.copy(running = false, preview = null, message = text, messageIsError = !ok) }
            } catch (e: Exception) {
                runCatching { reload() }
                _ui.update { it.copy(running = false, preview = null, message = "Renaming failed: ${e.message ?: e.javaClass.simpleName}. Please check the folder.", messageIsError = true) }
            }
        }
    }

    fun dismissMessage() { _ui.update { it.copy(message = null) } }

    private fun RenamePlan.toUi() = RenamePreviewUi(items, skipped, conflicts, duplicateRangeNotes, canExecute)
}
