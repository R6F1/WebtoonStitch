package com.webtoonstitch.app.saf

import android.content.ContentResolver
import android.net.Uri
import android.provider.DocumentsContract
import com.webtoonstitch.engine.RenameFolder
import com.webtoonstitch.engine.StrandedRenameException
import java.io.FileNotFoundException
import java.io.IOException

/**
 * [RenameFolder] on a Storage Access Framework folder. Uses only DocumentsContract.renameDocument: a metadata operation of the
 * storage provider. The file's bytes are never opened, read, decoded or copied.
 *
 * A renamed document may get a new URI, so the name -> URI map is kept up to date after every rename. Providers may also pick a
 * different name than requested (for example to avoid a clash); every rename is therefore verified by reading the display name
 * back, and a different name is treated as a failure (and undone) instead of being accepted silently.
 */
class SafRenameFolder(private val resolver: ContentResolver, entries: Collection<DirEntry>) : RenameFolder {
    private val byName = HashMap<String, Uri>()

    init { for (e in entries) byName[e.name] = e.uri }

    override fun exists(name: String): Boolean = byName.keys.any { it.equals(name, ignoreCase = true) }

    override fun rename(from: String, to: String) {
        val uri = byName[from] ?: throw FileNotFoundException("$from is not in the folder")
        if (!from.equals(to, ignoreCase = true) && exists(to)) throw IOException("$to already exists")
        // null can mean "renamed, document id unchanged": then the old URI is still the document. The name read-back decides.
        val result: Uri = try {
            DocumentsContract.renameDocument(resolver, uri, to) ?: uri
        } catch (e: Exception) {
            throw IOException(e.message ?: e.javaClass.simpleName, e)
        }
        val actual = displayName(result)
        if (actual == to) {
            byName.remove(from); byName[to] = result
            return
        }
        if (actual == from) throw IOException("The storage provider did not rename the file")
        // The provider chose another name. Try to put the file back under its previous name.
        byName.remove(from)
        if (actual != null) {
            val back = try { DocumentsContract.renameDocument(resolver, result, from) ?: result } catch (_: Exception) { null }
            if (back != null && displayName(back) == from) {
                byName[from] = back
                throw IOException("The storage provider renamed the file to \"$actual\" instead of \"$to\"")
            }
        }
        val now = actual ?: to
        byName[now] = result
        throw StrandedRenameException(from, now, "The storage provider renamed the file to \"$now\" instead of \"$to\" and it could not be put back")
    }

    private fun displayName(uri: Uri): String? = try {
        resolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Exception) { null }
}
