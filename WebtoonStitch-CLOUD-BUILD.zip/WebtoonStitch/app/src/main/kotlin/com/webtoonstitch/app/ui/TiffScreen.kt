package com.webtoonstitch.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.webtoonstitch.app.ViewPrefs
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.webtoonstitch.app.vm.FileState
import com.webtoonstitch.app.vm.TiffViewModel

@Composable
fun TiffScreen(modifier: Modifier = Modifier, onBack: () -> Unit, vm: TiffViewModel = viewModel()) {
    val ui by vm.ui.collectAsState()
    val pickInput = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let(vm::openTree) }
    val pickOutput = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let(vm::setOutputTree) }
    val busy = ui.job != null

    KeepScreenOn(busy)
    BackHandler { if (ui.canGoUp && !busy) vm.goUp() else onBack() }

    if (!ui.hasFolder) {
        Column(modifier.fillMaxSize().safeDrawingPadding()) {
            BackBar("TIFF to PNG", onBack)
            Column(
                Modifier.weight(1f).fillMaxWidth().padding(24.dp),
                verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Choose the folder that contains your .tif / .tiff files.", style = MaterialTheme.typography.bodyLarge)
                Text(
                    "Each file becomes its own PNG with the same name. A multi-page TIFF becomes one PNG per page (name_p001.png, name_p002.png …); pages are never merged or flattened. Files are never stitched here. TIFFs stored rotated or mirrored (Orientation other than top-left) need extra memory; if one does not fit, it is rejected rather than downscaled. " +
                        "Tip: tap a file to select it, or long-press a file and drag across others to select many at once.",
                    style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp)
                )
                Button(onClick = { pickInput.launch(null) }) { Text("Select TIFF Files") }
            }
        }
    } else {
        val gridState = rememberLazyGridState()
        val context = LocalContext.current
        var columns by remember { mutableIntStateOf(ViewPrefs.columns(context)) }
        val cells = remember(ui.entries) {
            ui.entries.map { e ->
                val status = when (e.state) {
                    FileState.READY -> "Waiting…"
                    FileState.CONVERTING -> "Converting…"
                    FileState.DONE -> e.statusText
                    FileState.FAILED -> "Failed: ${e.statusText}"
                    null -> null
                }
                CellModel(e.key, e.name, e.isDir, e.selected, e.info, status, e.state == FileState.FAILED, if (e.isDir) null else vm.inputFor(e))
            }
        }
        AutoHidingBars(
            gridState = gridState,
            keepVisible = busy,
            modifier = modifier,
            top = {
                CompactTopBar(
                    title = "TIFF to PNG", folderPath = ui.folderPath, canGoUp = ui.canGoUp, busy = busy,
                    columns = columns, onColumns = { columns = it; ViewPrefs.setColumns(context, it) },
                    onBack = onBack, onUp = vm::goUp, onChangeFolder = { pickInput.launch(null) }
                )
            },
            bottom = {
                CompactPanel(
                    summary = "${ui.selectedCount} file${if (ui.selectedCount == 1) "" else "s"} selected",
                    capacityFraction = null,
                    output = ui.outputLabel, busy = busy, jobTitle = ui.job?.title, jobFraction = ui.job?.fraction ?: 0f,
                    clearEnabled = ui.selectedCount > 0, primaryLabel = "Convert to PNG", primaryEnabled = ui.selectedCount > 0,
                    onChangeOutput = { pickOutput.launch(null) }, onClear = vm::clearSelection, onPrimary = vm::convert, onCancel = vm::cancel
                )
            }
        ) { topSpace, bottomSpace, setDragActive ->
            PickerGrid(
                cells = cells,
                columns = columns,
                thumbSide = ViewPrefs.thumbSide(columns),
                onClick = { cell -> vm.toggleKey(cell.key) },
                onDragSelect = vm::dragSelect,
                onDragActive = setDragActive,
                dragEnabled = !busy,
                state = gridState,
                topSpace = topSpace,
                bottomSpace = bottomSpace,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
    MessageDialog(ui.message, ui.messageIsError, vm::dismissMessage)
}
