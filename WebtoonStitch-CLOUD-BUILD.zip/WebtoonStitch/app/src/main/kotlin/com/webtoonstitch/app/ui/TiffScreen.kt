package com.webtoonstitch.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.webtoonstitch.app.vm.FileState
import com.webtoonstitch.app.vm.TiffViewModel

@Composable
fun TiffScreen(modifier: Modifier = Modifier, onBack: () -> Unit, vm: TiffViewModel = viewModel()) {
    val ui by vm.ui.collectAsState()
    val pickInput = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let(vm::openTree) }
    val pickOutput = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let(vm::setOutputTree) }
    val busy = ui.job != null

    KeepScreenOn(busy)
    BackHandler { if (ui.canGoUp && !busy) vm.goUp() else onBack() }

    if (!ui.hasFolder) {
        Column(modifier.fillMaxSize().safeDrawingPadding()) {
            BackBar("TIFF to PNG", onBack)
            Column(
                Modifier.weight(1f).fillMaxWidth().padding(24.dp),
                verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Choose the folder that contains your .tif / .tiff files.", style = MaterialTheme.typography.bodyLarge)
                Text(
                    "Each file becomes its own PNG with the same name. Single-page TIFF only. Files are never stitched here. TIFFs stored rotated or mirrored (Orientation other than top-left) need extra memory; if one does not fit, it is rejected rather than downscaled. " +
                        "Tip: tap a file to select it, or long-press a file and drag across others to select many at once.",
                    style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp)
                )
                Button(onClick = { pickInput.launch(null) }) { Text("Select TIFF Files") }
            }
        }
    } else {
        val gridState = rememberLazyGridState()
        AutoHidingBars(
            gridState = gridState,
            keepVisible = busy,
            modifier = modifier,
            top = {
                Column {
                    BackBar("TIFF to PNG", onBack)
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (ui.canGoUp) TextButton(onClick = vm::goUp, enabled = !busy) { Text("↑ Up") }
                        Text(ui.folderPath, style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f), maxLines = 1)
                        TextButton(onClick = { pickInput.launch(null) }, enabled = !busy) { Text("Change folder") }
                    }
                }
            },
            bottom = {
                Card(Modifier.fillMaxWidth().padding(8.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("${ui.selectedCount} file${if (ui.selectedCount == 1) "" else "s"} selected", style = MaterialTheme.typography.titleMedium)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Output folder: ${ui.outputLabel}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f), maxLines = 1)
                            TextButton(onClick = { pickOutput.launch(null) }, enabled = !busy) { Text("Change") }
                        }
                        val job = ui.job
                        if (job != null) {
                            Text(job.title, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp), maxLines = 2)
                            LinearProgressIndicator(progress = { job.fraction.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                            OutlinedButton(onClick = vm::cancel, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
                        } else {
                            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = vm::clearSelection, enabled = ui.selectedCount > 0) { Text("Clear") }
                                Button(onClick = vm::convert, enabled = ui.selectedCount > 0, modifier = Modifier.weight(1f)) { Text("Convert to PNG") }
                            }
                        }
                    }
                }
            }
        ) { padding, setDragActive ->
            PickerGrid(
                cells = ui.entries.map { e ->
                    val status = when (e.state) {
                        FileState.READY -> "Waiting…"
                        FileState.CONVERTING -> "Converting…"
                        FileState.DONE -> e.statusText
                        FileState.FAILED -> "Failed: ${e.statusText}"
                        null -> null
                    }
                    CellModel(e.key, e.name, e.isDir, e.selected, e.info, status, e.state == FileState.FAILED, if (e.isDir) null else vm.inputFor(e))
                },
                onClick = { cell -> ui.entries.firstOrNull { it.key == cell.key }?.let(vm::toggle) },
                onDragSelect = vm::dragSelect,
                onDragActive = setDragActive,
                dragEnabled = !busy,
                state = gridState,
                contentPadding = padding,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
    MessageDialog(ui.message, ui.messageIsError, vm::dismissMessage)
}
