package com.webtoonstitch.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.webtoonstitch.app.vm.RenamePreviewUi
import com.webtoonstitch.app.vm.RenameViewModel

/** Mass PNG rename: pick a folder, tick files, review the preview, confirm. Names only: no images are decoded or shown. */
@Composable
fun RenameScreen(modifier: Modifier = Modifier, onBack: () -> Unit, vm: RenameViewModel = viewModel()) {
    val ui by vm.ui.collectAsState()
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let(vm::openTree) }
    KeepScreenOn(ui.running)
    BackHandler { if (ui.running) Unit else if (ui.preview != null) vm.cancelPreview() else onBack() }

    Column(modifier.fillMaxSize().safeDrawingPadding()) {
        BackBar("Mass PNG Rename", onBack)
        val preview = ui.preview
        when {
            !ui.hasFolder -> Column(
                Modifier.weight(1f).fillMaxWidth().padding(24.dp),
                verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Choose the folder that contains your PNG files.", style = MaterialTheme.typography.bodyLarge)
                Text(
                    "Files named like 001-008 (1).png are renamed in place to 001.png, 002.png, … in order of their first number. " +
                        "Only the file name changes; the image is never opened or re-saved. You see a preview and must confirm before anything is renamed.",
                    style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp)
                )
                Button(onClick = { pick.launch(null) }, enabled = !ui.loading) { Text(if (ui.loading) "Opening…" else "Select PNG Folder") }
            }
            preview != null -> PreviewPane(
                preview, ui.running, Modifier.weight(1f),
                onBack = vm::cancelPreview, onConfirm = vm::confirm
            )
            else -> {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${ui.folderLabel}: ${ui.selectedCount} of ${ui.files.size} selected", fontSize = 13.sp, maxLines = 1, modifier = Modifier.weight(1f))
                    BarAction("All", vm::selectAll)
                    BarAction("None", vm::clearSelection)
                    BarAction("Folder", { pick.launch(null) })
                }
                if (ui.files.isEmpty()) {
                    Text("No PNG files in this folder.", modifier = Modifier.padding(24.dp))
                }
                LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                    items(ui.files, key = { it.name }) { row ->
                        Row(
                            Modifier.fillMaxWidth().clickable { vm.toggle(row.name) }.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(checked = row.selected, onCheckedChange = null)
                            Text(row.name, modifier = Modifier.padding(start = 12.dp), maxLines = 2)
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.End) {
                    ActionButton("Preview rename (${ui.selectedCount})", vm::showPreview, enabled = ui.selectedCount > 0 && !ui.running)
                }
            }
        }
    }
    MessageDialog(ui.message, ui.messageIsError, vm::dismissMessage)
}

@Composable
private fun PreviewPane(p: RenamePreviewUi, running: Boolean, modifier: Modifier, onBack: () -> Unit, onConfirm: () -> Unit) {
    Column(modifier.fillMaxWidth()) {
        Text(
            "${p.items.size} to rename · ${p.skipped.size} skipped · nothing is renamed until you confirm",
            fontSize = 13.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            if (p.conflicts.isNotEmpty()) {
                item { SectionTitle("Cannot rename: these names already exist in the folder", error = true) }
                items(p.conflicts) { c -> Text("${c.newName}  (needed for ${c.originalName})", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 12.dp, vertical = 3.dp), fontSize = 13.sp) }
            }
            if (p.duplicateNotes.isNotEmpty()) {
                item { SectionTitle("Notes", error = false) }
                items(p.duplicateNotes) { n -> Text(n, modifier = Modifier.padding(horizontal = 12.dp, vertical = 3.dp), fontSize = 12.sp) }
            }
            item { SectionTitle("Will rename (${p.items.size})", error = false) }
            items(p.items) { item ->
                Column(Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
                    Text(item.originalName, fontSize = 13.sp, maxLines = 2)
                    Text("→ ${item.newName}", fontSize = 13.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                }
            }
            if (p.skipped.isNotEmpty()) {
                item { SectionTitle("Skipped, left unchanged (${p.skipped.size})", error = false) }
                items(p.skipped) { s -> Text("${s.name}  (${s.reason})", modifier = Modifier.padding(horizontal = 12.dp, vertical = 3.dp), fontSize = 13.sp) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
            if (running) Text("Renaming…", modifier = Modifier.padding(end = 12.dp), fontSize = 13.sp)
            ActionButton("Back", onBack, enabled = !running, filled = false)
            ActionButton("Rename ${p.items.size} file(s)", onConfirm, enabled = p.canExecute && !running)
        }
    }
}

@Composable
private fun SectionTitle(text: String, error: Boolean) {
    Text(
        text, fontSize = 13.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        color = if (error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.padding(horizontal = 12.dp).padding(top = 10.dp, bottom = 2.dp)
    )
}
