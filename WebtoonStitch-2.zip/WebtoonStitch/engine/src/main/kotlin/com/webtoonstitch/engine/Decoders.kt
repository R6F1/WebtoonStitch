package com.webtoonstitch.engine

/** What a file really is, decided from its first bytes only (never from the file name). */
enum class DetectedFormat { PNG, TIFF, JPEG, UNKNOWN }

/**
 * Format sniffing by signature. PNG and TIFF are decoded exactly. JPEG is decoded by the engine's own decoder
 * ([JpegRowSource]); the PNG written from it contains the decoded pixel values.
 */
object ImageDecoders {
    fun detect(head: ByteArray, n: Int): DetectedFormat = when {
        n == 4 && head[0] == 0x89.toByte() && head[1] == 'P'.code.toByte() -> DetectedFormat.PNG   // same test as before JPEG support, so PNG handling is unchanged
        n >= 3 && head[0] == 0xFF.toByte() && head[1] == 0xD8.toByte() && head[2] == 0xFF.toByte() -> DetectedFormat.JPEG
        n >= 4 && ((head[0] == 'I'.code.toByte() && head[1] == 'I'.code.toByte() && head[2].toInt() == 42) ||
            (head[0] == 'M'.code.toByte() && head[1] == 'M'.code.toByte() && head[3].toInt() == 42)) -> DetectedFormat.TIFF
        n >= 4 && (head[2].toInt() == 43 || head[3].toInt() == 43) && head[0] == head[1] && (head[0] == 'I'.code.toByte() || head[0] == 'M'.code.toByte()) -> DetectedFormat.TIFF
        else -> DetectedFormat.UNKNOWN
    }

    /** Reads the first bytes of [input] and classifies it. IO problems are reported like in [open]. */
    fun detect(input: ImageInput): DetectedFormat {
        val head = ByteArray(4)
        val n = try {
            input.openStream().use { s -> var k = 0; while (k < 4) { val r = s.read(head, k, 4 - k); if (r < 0) break; k += r }; k }
        } catch (e: java.io.IOException) {
            throw unreadable(input.name, "could not be opened. It may have been deleted, moved, or is not accessible.", e)
        } catch (e: SecurityException) {
            throw unreadable(input.name, "access to this file was denied.", e)
        }
        return detect(head, n)
    }

    /** Picker label for formats that deserve one; null for plain PNG/TIFF. */
    fun label(format: DetectedFormat, fileName: String): String? = when (format) {
        DetectedFormat.JPEG -> if (fileName.endsWith(".jpg", true) || fileName.endsWith(".jpeg", true)) "JPEG" else "JPEG (saved as ${fileName.substringAfterLast('.', "").let { if (it.isEmpty()) "no extension" else ".${it.lowercase()}" }})"
        DetectedFormat.UNKNOWN -> "Unsupported format"
        else -> null
    }

    fun open(input: ImageInput): RowSource {
        return when (detect(input)) {
            DetectedFormat.PNG -> PngReader.open(openStreamSafely(input), input.name)
            DetectedFormat.TIFF -> Tiff.open(input)
            DetectedFormat.JPEG -> JpegRowSource.open(openStreamSafely(input), input.name)
            DetectedFormat.UNKNOWN -> throw unsupported(input.name, "unsupported or unrecognised image format. Only PNG, TIFF and JPEG can be processed.")
        }
    }

    /** Header-only inspection; never decodes pixel data. */
    fun inspect(input: ImageInput): RasterInfo = open(input).use { it.info }

    internal fun openStreamSafely(input: ImageInput): java.io.InputStream = try {
        input.openStream()
    } catch (e: java.io.IOException) {
        throw unreadable(input.name, "could not be opened. It may have been deleted, moved, or is not accessible.", e)
    }
}
