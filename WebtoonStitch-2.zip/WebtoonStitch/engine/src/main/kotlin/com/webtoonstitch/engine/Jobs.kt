package com.webtoonstitch.engine

import java.io.BufferedOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/** Suffix of every in-progress output file. A name containing it is never a finished image. */
const val TEMP_SUFFIX = ".webtoonstitch.part"

/**
 * A file being produced in the user's chosen output location.
 *
 * It is created under a TEMPORARY name ([TEMP_SUFFIX]); the final name only appears after the content has been
 * completely written AND verified, via [commit] (a rename, which is atomic on a normal file system).
 * If the process is killed at any point, at worst a `*.webtoonstitch.part` file is left behind - never a
 * truncated file that looks like a finished PNG.
 */
interface OutputFile {
    fun openOutput(): OutputStream
    fun openInput(): InputStream
    /**
     * Publishes the file under [finalName] by renaming it. [finalName] does not exist (the caller checked).
     * Must fail with an exception (never fall back to copying) if an atomic rename is not possible.
     */
    fun commit(finalName: String)
    /** Removes the (partial) temporary file. Must never throw. Not called after a successful [commit]. */
    fun delete()
}

/** The user's chosen output location. The Android layer implements this over the Storage Access Framework. */
interface OutputFolder {
    fun exists(name: String): Boolean
    /** Creates a NEW temporary file for the output that will eventually be named [finalNameHint]. */
    fun createTemporary(finalNameHint: String): OutputFile
    /** Best-effort removal of `*`[TEMP_SUFFIX] leftovers from an earlier run that was killed. Must never throw. */
    fun removeStaleTemporaries()
}

sealed class JobOutcome {
    abstract val inputName: String
    data class Success(override val inputName: String, val outputName: String, val width: Int, val height: Int, val format: String, val sourceCount: Int = 1) : JobOutcome()
    data class Failure(override val inputName: String, val code: ErrorCode, val message: String) : JobOutcome()
}

/**
 * High-level operations used by the app. Each one: validates -> streams the output -> re-reads and verifies it
 * pixel by pixel -> deletes the output if anything at all went wrong. A file that did not verify is never left behind.
 */
object Jobs {
    /** Progress is reported as 0..1000 per operation for the generation + verification phases. */
    class Progress(val phase: Phase, val fileIndex: Int, val fileCount: Int, val fileName: String, val fraction: Float)
    enum class Phase { PLANNING, WRITING, VERIFYING }

    fun stitch(
        inputs: List<ImageInput>, folder: OutputFolder,
        onProgress: (Progress) -> Unit = {}, cancel: CancelCheck = CancelCheck.NONE,
        verify: Boolean = true
    ): JobOutcome.Success {
        onProgress(Progress(Phase.PLANNING, 0, 1, "", 0f))
        cleanStale(folder)
        val plan = Stitcher.plan(inputs)
        val name = OutputNaming.uniqueName(plan.outputName) { folder.exists(it) }
        return writeVerified(folder, name, cancel) { file ->
            file.openOutput().buffered(1 shl 16).use { out ->
                Stitcher.stitch(plan, out, { d, t -> onProgress(Progress(Phase.WRITING, 0, 1, name, d.toFloat() / t)) }, cancel)
            }
            if (verify) Stitcher.verify(plan, { file.openInput().buffered(1 shl 16) }, { d, t -> onProgress(Progress(Phase.VERIFYING, 0, 1, name, d.toFloat() / t)) }, cancel)
            JobOutcome.Success(plan.inputs.first().name, name, plan.width, plan.totalHeight, plan.outputInfo.formatLabel, plan.inputs.size)
        }
    }

    /** Converts every TIFF independently. A failing file is reported and the batch continues. Cancellation aborts the batch. */
    fun convertTiffs(
        inputs: List<ImageInput>, folder: OutputFolder,
        onProgress: (Progress) -> Unit = {}, onFileDone: (JobOutcome) -> Unit = {},
        cancel: CancelCheck = CancelCheck.NONE
    ): List<JobOutcome> {
        val results = ArrayList<JobOutcome>()
        val reserved = HashSet<String>()
        cleanStale(folder)
        for ((i, input) in inputs.withIndex()) {
            cancel.check()
            val outcome: JobOutcome = try {
                TiffConverter.inspect(input)   // fail fast on unsupported / multi-page, before anything is written
                val desired = OutputNaming.tiffToPngName(input.name)
                val name = OutputNaming.uniqueName(desired) { folder.exists(it) || it in reserved }
                reserved += name
                val done = writeVerified(folder, name, cancel) { file ->
                    val info = file.openOutput().buffered(1 shl 16).use { out ->
                        TiffConverter.convert(input, out, { d, t -> onProgress(Progress(Phase.WRITING, i, inputs.size, input.name, d.toFloat() / t)) }, cancel)
                    }
                    TiffConverter.verify(input, { file.openInput().buffered(1 shl 16) }, cancel)
                    onProgress(Progress(Phase.VERIFYING, i, inputs.size, input.name, 1f))
                    JobOutcome.Success(input.name, name, info.width, info.height, info.formatLabel)
                }
                reserved += done.outputName   // the committed name (may differ from the hint if it was taken meanwhile)
                done
            } catch (e: EngineException) {
                JobOutcome.Failure(input.name, e.code, e.message ?: "Conversion failed.")
            }
            results += outcome
            onFileDone(outcome)
        }
        return results
    }

    private fun cleanStale(folder: OutputFolder) {
        try { folder.removeStaleTemporaries() } catch (_: Exception) { /* best effort: never blocks a job */ }
    }

    /**
     * Temp file -> write -> verify -> (last cancel point) -> pick a still-free final name -> rename.
     * Anything that fails or is cancelled before the rename removes the temporary file.
     */
    private fun writeVerified(folder: OutputFolder, nameHint: String, cancel: CancelCheck, body: (OutputFile) -> JobOutcome.Success): JobOutcome.Success {
        val file = try { folder.createTemporary(nameHint) } catch (e: IOException) {
            throw EngineException(ErrorCode.IO_WRITE, "Could not create a temporary file in the output folder: ${e.message ?: "not writable"}", e)
        } catch (e: SecurityException) {
            throw EngineException(ErrorCode.IO_WRITE, "Permission to write to the output folder was lost. Please choose the folder again.", e)
        }
        var published = false
        try {
            val result = body(file)
            cancel.check()   // cancelling after verification but before publishing still leaves nothing behind
            // Re-check right before publishing: a file with that name may have appeared while we were working.
            val finalName = OutputNaming.uniqueName(nameHint) { folder.exists(it) }
            try {
                file.commit(finalName)
            } catch (e: IOException) {
                throw EngineException(ErrorCode.IO_WRITE, "The finished and verified image could not be saved under its final name \"$finalName\": ${e.message ?: "rename failed"}. Nothing was kept.", e)
            } catch (e: UnsupportedOperationException) {
                throw EngineException(ErrorCode.IO_WRITE, "The output folder's storage provider does not support renaming files, so a safe (all-or-nothing) save is not possible there. Choose a different output folder. Nothing was kept.", e)
            } catch (e: SecurityException) {
                throw EngineException(ErrorCode.IO_WRITE, "Permission to write to the output folder was lost. Please choose the folder again. Nothing was kept.", e)
            }
            published = true
            return result.copy(outputName = finalName)
        } catch (e: EngineException) {
            throw e
        } catch (e: IOException) {
            val full = (e.message ?: "").contains("space", ignoreCase = true) || (e.message ?: "").contains("ENOSPC")
            throw EngineException(
                ErrorCode.IO_WRITE,
                if (full) "Not enough free storage space to write \"$nameHint\". Free some space and try again."
                else "Could not write \"$nameHint\": ${e.message ?: "I/O error"}", e
            )
        } finally {
            if (!published) file.delete()    // failure, cancellation, OutOfMemoryError: the temporary file never survives
        }
    }
}
