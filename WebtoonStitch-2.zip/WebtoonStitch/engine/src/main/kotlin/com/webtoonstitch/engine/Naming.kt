package com.webtoonstitch.engine

/** Natural, deterministic filename ordering: "2.png" < "10.png", "001" < "02" < "3". */
object NaturalFilenameComparator : Comparator<String> {
    override fun compare(a: String, b: String): Int {
        var i = 0
        var j = 0
        while (i < a.length && j < b.length) {
            val ca = a[i]
            val cb = b[j]
            if (isDigit(ca) && isDigit(cb)) {
                var ie = i
                while (ie < a.length && isDigit(a[ie])) ie++
                var je = j
                while (je < b.length && isDigit(b[je])) je++
                // numeric comparison without overflow: strip leading zeros, compare length, then digits
                var is0 = i
                while (is0 < ie - 1 && a[is0] == '0') is0++
                var js0 = j
                while (js0 < je - 1 && b[js0] == '0') js0++
                val la = ie - is0
                val lb = je - js0
                if (la != lb) return la.compareTo(lb)
                for (k in 0 until la) {
                    val d = a[is0 + k].compareTo(b[js0 + k])
                    if (d != 0) return d
                }
                i = ie
                j = je
            } else {
                val la = ca.lowercaseChar()
                val lb = cb.lowercaseChar()
                if (la != lb) return la.compareTo(lb)
                i++
                j++
            }
        }
        if (i < a.length) return 1
        if (j < b.length) return -1
        // Tie-breakers keep the order total and deterministic: fewer leading zeros first, then exact text.
        val zerosA = a.count { it == '0' }
        val zerosB = b.count { it == '0' }
        if (zerosA != zerosB) return zerosA.compareTo(zerosB)
        return a.compareTo(b)
    }

    private fun isDigit(c: Char) = c in '0'..'9'
}

object OutputNaming {
    private val illegal = Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]")

    fun stem(fileName: String): String {
        val dot = fileName.lastIndexOf('.')
        return if (dot > 0) fileName.substring(0, dot) else fileName
    }

    private fun clean(s: String) = s.replace(illegal, "_").trim().ifEmpty { "image" }

    /** First-last convention on the *sorted* names, e.g. 001.png … 009.png -> "001-009.png". */
    fun stitchName(names: List<String>): String {
        require(names.isNotEmpty())
        val sorted = names.sortedWith(NaturalFilenameComparator)
        return clean(stem(sorted.first()) + "-" + stem(sorted.last())) + ".png"
    }

    fun tiffToPngName(tiffName: String) = clean(stem(tiffName)) + ".png"

    /** "a.png" -> "a.png" if free, else "a (1).png", "a (2).png", … Never returns an existing name. */
    fun uniqueName(desired: String, exists: (String) -> Boolean): String {
        if (!exists(desired)) return desired
        val dot = desired.lastIndexOf('.')
        val base = if (dot > 0) desired.substring(0, dot) else desired
        val ext = if (dot > 0) desired.substring(dot) else ""
        var n = 1
        while (true) {
            val candidate = "$base ($n)$ext"
            if (!exists(candidate)) return candidate
            n++
        }
    }
}
