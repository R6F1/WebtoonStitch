package com.webtoonstitch.engine

import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.DeflaterOutputStream
import java.util.zip.Inflater
import java.util.zip.InflaterInputStream

private val PNG_SIGNATURE = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)
private val COLOR_CHUNK_TYPES = setOf("iCCP", "sRGB", "gAMA", "cHRM", "cICP")

/** Streaming PNG decoder: holds one row (plus the previous one) in memory, never the whole image. */
class PngReader private constructor(
    private val name: String?,
    private val stream: DataInputStream,
    override val info: RasterInfo,
    firstIdatLength: Long
) : RowSource {
    private val inflater = Inflater()
    private val idat = IdatStream(stream, firstIdatLength)
    private val zin = InflaterInputStream(idat, inflater, 1 shl 16)
    private var cur = ByteArray(info.rowBytes)
    private var prev = ByteArray(info.rowBytes)
    private var row = 0

    override fun readRow(dst: ByteArray) {
        check(row < info.height) { "all rows already read" }
        try {
            val f = zin.read()
            if (f < 0 || !zin.readFullyOrFalse(cur, 0, info.rowBytes)) {
                throw unreadable(name, "PNG pixel data is truncated at row $row of ${info.height}.")
            }
            unfilter(f, cur, prev, info.filterBytesPerPixel, info.rowBytes)
        } catch (e: EngineException) {
            throw e
        } catch (e: IOException) {
            throw unreadable(name, "PNG data is corrupt or unreadable (row $row): ${e.message}", e)
        }
        System.arraycopy(cur, 0, dst, 0, info.rowBytes)
        val t = prev; prev = cur; cur = t
        row++
    }

    override fun close() {
        inflater.end()
        stream.close()
    }

    private class IdatStream(val inp: DataInputStream, var remaining: Long) : InputStream() {
        private val crc = CRC32().also { it.update(byteArrayOf('I'.code.toByte(), 'D'.code.toByte(), 'A'.code.toByte(), 'T'.code.toByte())) }
        private var finished = false
        override fun read(): Int {
            val b = ByteArray(1)
            return if (read(b, 0, 1) < 0) -1 else b[0].toInt() and 0xFF
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (len == 0) return 0
            while (remaining == 0L) {
                if (finished) return -1
                val expected = inp.readInt()
                if (expected != crc.value.toInt()) throw IOException("IDAT checksum mismatch")
                val nextLen = inp.readInt().toLong() and 0xFFFFFFFFL
                val type = ByteArray(4)
                inp.readFully(type)
                if (String(type, Charsets.ISO_8859_1) == "IDAT") {
                    remaining = nextLen; crc.reset(); crc.update(type)
                } else {
                    finished = true; return -1
                }
            }
            val n = inp.read(b, off, minOf(len.toLong(), remaining).toInt())
            if (n < 0) throw IOException("unexpected end of file inside IDAT")
            crc.update(b, off, n)
            remaining -= n
            return n
        }
    }

    companion object {
        /** Reads only the header chunks (never the pixel data). Cheap: used for dimension inspection. */
        fun readInfo(input: InputStream, name: String? = null): RasterInfo =
            open(input, name).use { it.info }

        fun open(input: InputStream, name: String? = null): PngReader {
            val din = DataInputStream(input.buffered(1 shl 16))
            try {
                val sig = ByteArray(8)
                if (!din.readFullyOrFalse(sig, 0, 8) || !sig.contentEquals(PNG_SIGNATURE)) {
                    throw unreadable(name, "not a PNG file.")
                }
                var ihdr: ByteArray? = null
                var palette: ByteArray? = null
                var trns: ByteArray? = null
                val color = ArrayList<PngChunk>()
                while (true) {
                    val len = din.readInt().toLong() and 0xFFFFFFFFL
                    val typeBytes = ByteArray(4)
                    din.readFully(typeBytes)
                    val type = String(typeBytes, Charsets.ISO_8859_1)
                    if (type == "IDAT") {
                        val h = ihdr ?: throw unreadable(name, "PNG has no IHDR before pixel data.")
                        val info = parseInfo(name, h, palette, trns, color)
                        return PngReader(name, din, info, len)
                    }
                    if (type == "IEND") throw unreadable(name, "PNG contains no pixel data.")
                    val keep = type == "IHDR" || type == "PLTE" || type == "tRNS" || type in COLOR_CHUNK_TYPES
                    if (!keep) {
                        skipFully(din, len + 4)
                        continue
                    }
                    if (len > 64L * 1024 * 1024) throw unreadable(name, "PNG chunk $type is implausibly large.")
                    val data = ByteArray(len.toInt())
                    din.readFully(data)
                    val crc = CRC32().also { it.update(typeBytes); it.update(data) }
                    if (din.readInt() != crc.value.toInt()) throw unreadable(name, "PNG chunk $type is corrupt (checksum mismatch).")
                    when (type) {
                        "IHDR" -> ihdr = data
                        "PLTE" -> palette = data
                        "tRNS" -> trns = data
                        else -> color.add(PngChunk(type, data))
                    }
                }
            } catch (e: EngineException) {
                input.close(); throw e
            } catch (e: IOException) {
                input.close(); throw unreadable(name, "PNG header is truncated or corrupt.", e)
            }
        }

        private fun skipFully(d: DataInputStream, n: Long) {
            var left = n
            while (left > 0) {
                val s = d.skip(left)
                if (s <= 0) { if (d.read() < 0) throw java.io.EOFException(); left-- } else left -= s
            }
        }

        private fun parseInfo(
            name: String?, h: ByteArray, palette: ByteArray?, trns: ByteArray?, color: List<PngChunk>
        ): RasterInfo {
            if (h.size != 13) throw unreadable(name, "PNG header is malformed.")
            fun u32(o: Int) = ((h[o].toLong() and 255) shl 24) or ((h[o + 1].toLong() and 255) shl 16) or
                ((h[o + 2].toLong() and 255) shl 8) or (h[o + 3].toLong() and 255)
            val w = u32(0); val ht = u32(4)
            val depth = h[8].toInt() and 255
            val ct = h[9].toInt() and 255
            if (w <= 0 || ht <= 0 || w > Int.MAX_VALUE / 16 || ht > Int.MAX_VALUE) throw unreadable(name, "PNG has invalid dimensions.")
            if (!RasterInfo.validCombination(ct, depth)) throw unreadable(name, "PNG has an invalid colour type / bit depth combination.")
            if (h[10].toInt() != 0 || h[11].toInt() != 0) throw unreadable(name, "PNG uses an unknown compression/filter method.")
            if (h[12].toInt() != 0) {
                throw unsupported(
                    name,
                    "interlaced (Adam7) PNG is not supported: it cannot be stitched row by row without " +
                        "buffering the whole image. Re-save it as a non-interlaced PNG."
                )
            }
            if (ct == 3 && palette == null) throw unreadable(name, "indexed PNG has no palette.")
            return RasterInfo(w.toInt(), ht.toInt(), ct, depth, palette, trns, color)
        }

        internal fun unfilter(type: Int, cur: ByteArray, prev: ByteArray, bpp: Int, n: Int) {
            when (type) {
                0 -> {}
                1 -> for (i in bpp until n) cur[i] = (cur[i] + cur[i - bpp]).toByte()
                2 -> for (i in 0 until n) cur[i] = (cur[i] + prev[i]).toByte()
                3 -> for (i in 0 until n) {
                    val a = if (i >= bpp) cur[i - bpp].toInt() and 255 else 0
                    cur[i] = (cur[i] + ((a + (prev[i].toInt() and 255)) shr 1)).toByte()
                }
                4 -> for (i in 0 until n) {
                    val a = if (i >= bpp) cur[i - bpp].toInt() and 255 else 0
                    val b = prev[i].toInt() and 255
                    val c = if (i >= bpp) prev[i - bpp].toInt() and 255 else 0
                    cur[i] = (cur[i] + paeth(a, b, c)).toByte()
                }
                else -> throw IOException("invalid PNG filter type $type")
            }
        }

        internal fun paeth(a: Int, b: Int, c: Int): Int {
            val p = a + b - c
            val pa = Math.abs(p - a); val pb = Math.abs(p - b); val pc = Math.abs(p - c)
            return if (pa <= pb && pa <= pc) a else if (pb <= pc) b else c
        }
    }
}

/**
 * Streaming lossless PNG encoder (non-interlaced, adaptive row filters, zlib deflate).
 * Never quantises, never reduces depth, never touches sample values.
 */
class PngWriter(
    private val out: OutputStream,
    val info: RasterInfo,
    compressionLevel: Int = 6
) : java.io.Closeable {
    private val deflater = Deflater(compressionLevel)
    private val idatChunks = IdatChunker(out)
    private val zout = DeflaterOutputStream(idatChunks, deflater, 1 shl 16)
    private val n = info.rowBytes
    private val bpp = info.filterBytesPerPixel
    private var prev = ByteArray(n)
    private val cand = Array(5) { ByteArray(n + 1) }
    private var rows = 0
    private var finished = false
    private val adaptive = info.bitDepth >= 8

    init {
        out.write(PNG_SIGNATURE)
        val h = ByteArrayOutputStream(13)
        fun u32(v: Int) { h.write(v ushr 24); h.write(v ushr 16); h.write(v ushr 8); h.write(v) }
        u32(info.width); u32(info.height)
        h.write(info.bitDepth); h.write(info.colorType); h.write(0); h.write(0); h.write(0)
        writeChunk(out, "IHDR", h.toByteArray())
        for (c in info.colorChunks) writeChunk(out, c.type, c.data)
        info.palette?.let { writeChunk(out, "PLTE", it) }
        info.transparency?.let { writeChunk(out, "tRNS", it) }
    }

    fun writeRow(row: ByteArray) {
        check(rows < info.height) { "too many rows" }
        if (!adaptive) {
            cand[0][0] = 0
            System.arraycopy(row, 0, cand[0], 1, n)
            zout.write(cand[0], 0, n + 1)
        } else {
            var best = 0
            var bestScore = Long.MAX_VALUE
            for (f in 0..4) {
                val c = cand[f]
                c[0] = f.toByte()
                var score = 0L
                for (i in 0 until n) {
                    val x = row[i].toInt() and 255
                    val a = if (i >= bpp) row[i - bpp].toInt() and 255 else 0
                    val b = prev[i].toInt() and 255
                    val cc = if (i >= bpp) prev[i - bpp].toInt() and 255 else 0
                    val p = when (f) {
                        0 -> 0
                        1 -> a
                        2 -> b
                        3 -> (a + b) shr 1
                        else -> PngReader.paeth(a, b, cc)
                    }
                    val v = (x - p).toByte()
                    c[i + 1] = v
                    score += Math.abs(v.toInt())
                }
                if (score < bestScore) { bestScore = score; best = f }
            }
            zout.write(cand[best], 0, n + 1)
            System.arraycopy(row, 0, prev, 0, n)
        }
        rows++
    }

    /** Completes the file. Fails if the number of rows written differs from the declared height. */
    fun finish() {
        if (finished) return
        finished = true
        if (rows != info.height) throw IllegalStateException("wrote $rows rows, expected ${info.height}")
        zout.finish()
        idatChunks.flushChunk()
        writeChunk(out, "IEND", ByteArray(0))
        out.flush()
        deflater.end()
    }

    override fun close() {
        if (!finished) deflater.end()
    }

    private class IdatChunker(val out: OutputStream) : OutputStream() {
        private val buf = ByteArray(1 shl 16)
        private var len = 0
        override fun write(b: Int) { write(byteArrayOf(b.toByte()), 0, 1) }
        override fun write(b: ByteArray, off: Int, l: Int) {
            var o = off; var left = l
            while (left > 0) {
                val c = minOf(left, buf.size - len)
                System.arraycopy(b, o, buf, len, c)
                len += c; o += c; left -= c
                if (len == buf.size) flushChunk()
            }
        }
        fun flushChunk() {
            if (len > 0) { writeChunk(out, "IDAT", buf.copyOf(len)); len = 0 }
        }
    }

    companion object {
        internal fun writeChunk(o: OutputStream, type: String, data: ByteArray) {
            val t = type.toByteArray(Charsets.ISO_8859_1)
            val len = data.size
            o.write(len ushr 24); o.write(len ushr 16); o.write(len ushr 8); o.write(len)
            o.write(t); o.write(data)
            val crc = CRC32().also { it.update(t); it.update(data) }.value.toInt()
            o.write(crc ushr 24); o.write(crc ushr 16); o.write(crc ushr 8); o.write(crc)
        }
    }
}
