package com.webtoonstitch.engine

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.util.zip.Deflater
import java.util.zip.Inflater
import java.util.zip.InflaterInputStream

/**
 * Streaming TIFF -> PNG-layout row decoder.
 *
 * Supported (exact, no value changes): single-page, classic (non-Big) TIFF, striped, chunky (planar=1),
 * little/big endian; grayscale 1/2/4/8/16-bit (BlackIsZero, and WhiteIsZero by exact bit inversion),
 * RGB 8/16-bit, palette 1/2/4/8-bit (when the 16-bit colour map is exactly representable in 8-bit),
 * one unassociated alpha channel (gray+alpha, RGB+alpha); compression None, LZW, Deflate (both codes),
 * PackBits; horizontal-differencing predictor for 8/16-bit; embedded ICC profile (-> iCCP);
 * every Orientation value (1 streams, 2-8 are applied exactly in memory for 8/16-bit images).
 *
 * Everything else is rejected with an explanation (see [Tiff.open]) instead of being approximated.
 *
 * MEMORY LIMITATION - TIFF Orientation 2..8
 * -----------------------------------------
 * Orientation 1 (top-left, the normal case) is fully streamed: memory use is about one row, whatever the image size.
 * Orientations 2-8 (mirrored / rotated) cannot be applied row by row, because the first output row depends on pixels
 * from the LAST input rows (and 90-degree rotations swap rows and columns). They are therefore applied EXACTLY, with no
 * resampling, by holding the complete decoded raster in memory:
 *
 *     required memory  ~=  width x height x bytes-per-pixel   (+ one row)
 *     examples:  690 x 12000 RGB 8-bit  =  ~25 MB      4096 x 12000 RGB 16-bit  =  ~281 MB
 *
 * If that does not fit in the app's heap (see [orientationMemoryBudget]) the file is REJECTED when it is opened - before any
 * output is created - with an error that states the needed and available memory. There is deliberately no downsampling, tiling
 * trade-off or lossy fallback. Orientation 2-8 is also rejected for samples below 8 bits (bit-level moves are not supported).
 * Workaround for such files: re-save the TIFF with Orientation = 1 (top-left) in an editor, or use a device with more memory.
 */
object Tiff {
    /** Share of the maximum heap that an in-memory orientation may use. Replaceable in tests. */
    internal var orientationMemoryBudget: () -> Long = { (Runtime.getRuntime().maxMemory() * 0.7).toLong() }

    private const val T_WIDTH = 256; private const val T_HEIGHT = 257; private const val T_BPS = 258
    private const val T_COMPRESSION = 259; private const val T_PHOTOMETRIC = 262; private const val T_FILLORDER = 266
    private const val T_STRIP_OFFSETS = 273; private const val T_ORIENTATION = 274; private const val T_SPP = 277
    private const val T_ROWS_PER_STRIP = 278; private const val T_STRIP_COUNTS = 279; private const val T_PLANAR = 284
    private const val T_PREDICTOR = 317; private const val T_COLORMAP = 320; private const val T_TILE_W = 322
    private const val T_TILE_L = 323; private const val T_EXTRA = 338; private const val T_SAMPLEFORMAT = 339
    private const val T_ICC = 34675

    /** Opens [input] and returns a row source whose [RowSource.info] is the exact PNG representation. */
    fun open(input: ImageInput): RowSource {
        val ra = try {
            input.openRandomAccess()
        } catch (e: java.io.IOException) {
            throw unreadable(input.name, "could not be opened. It may have been deleted, moved, or is not accessible.", e)
        } catch (e: SecurityException) {
            throw unreadable(input.name, "access to this file was denied.", e)
        }
        try {
            return TiffParser(ra, input.name).build()
        } catch (e: Throwable) {
            try { ra.close() } catch (_: Throwable) {}
            if (e is OutOfMemoryError) throw EngineException(ErrorCode.OUT_OF_MEMORY, "${input.name}: not enough memory to open this TIFF.", e)
            throw e
        }
    }

    private fun mb(bytes: Long) = maxOf(1L, (bytes + 1024 * 1024 - 1) / (1024 * 1024))

    private class Entry(val tag: Int, val type: Int, val count: Long, val raw: ByteArray)

    private class TiffParser(val ra: RandomAccess, val name: String) {
        var le = false

        fun u16(b: ByteArray, o: Int): Int =
            if (le) (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8)
            else ((b[o].toInt() and 255) shl 8) or (b[o + 1].toInt() and 255)

        fun u32(b: ByteArray, o: Int): Long =
            if (le) (u16(b, o).toLong()) or (u16(b, o + 2).toLong() shl 16)
            else (u16(b, o).toLong() shl 16) or u16(b, o + 2).toLong()

        fun readAt(pos: Long, len: Int): ByteArray {
            if (pos < 0 || pos + len > ra.length) throw unreadable(name, "TIFF structure points outside the file (truncated or corrupt).")
            val b = ByteArray(len)
            var n = 0
            while (n < len) {
                val r = ra.readAt(pos + n, b, n, len - n)
                if (r <= 0) throw unreadable(name, "TIFF file ended unexpectedly.")
                n += r
            }
            return b
        }

        fun readIfd(offset: Long): Pair<Map<Int, Entry>, Long> {
            val cnt = u16(readAt(offset, 2), 0)
            if (cnt == 0 || cnt > 4096) throw unreadable(name, "TIFF directory is malformed.")
            val b = readAt(offset + 2, cnt * 12 + 4)
            val m = HashMap<Int, Entry>()
            for (i in 0 until cnt) {
                val o = i * 12
                m[u16(b, o)] = Entry(u16(b, o), u16(b, o + 2), u32(b, o + 4), b.copyOfRange(o + 8, o + 12))
            }
            return m to u32(b, cnt * 12)
        }

        private fun typeSize(t: Int) = when (t) { 1, 2, 6, 7 -> 1; 3, 8 -> 2; 4, 9, 11 -> 4; 5, 10, 12 -> 8; else -> 0 }

        fun bytesOf(e: Entry): ByteArray {
            val sz = typeSize(e.type).toLong() * e.count
            if (sz <= 0 || sz > 64L * 1024 * 1024) throw unreadable(name, "TIFF tag ${e.tag} has an invalid size.")
            return if (sz <= 4) e.raw.copyOf(sz.toInt()) else readAt(u32(e.raw, 0), sz.toInt())
        }

        fun longs(e: Entry?): LongArray? {
            e ?: return null
            val b = bytesOf(e)
            return when (e.type) {
                1, 7 -> LongArray(b.size) { (b[it].toLong() and 255) }
                3 -> LongArray(b.size / 2) { u16(b, it * 2).toLong() }
                4 -> LongArray(b.size / 4) { u32(b, it * 4) }
                else -> throw unsupported(name, "TIFF tag ${e.tag} has an unexpected data type ${e.type}.")
            }
        }

        fun build(): RowSource {
            val h = readAt(0, 8)
            le = when {
                h[0] == 'I'.code.toByte() && h[1] == 'I'.code.toByte() -> true
                h[0] == 'M'.code.toByte() && h[1] == 'M'.code.toByte() -> false
                else -> throw unreadable(name, "not a TIFF file.")
            }
            val magic = u16(h, 2)
            if (magic == 43) throw unsupported(name, "BigTIFF is not supported.")
            if (magic != 42) throw unreadable(name, "not a TIFF file.")
            val first = u32(h, 4)

            val (tags, next) = readIfd(first)
            if (next != 0L) {
                var pages = 2
                var n = next
                val seen = HashSet<Long>().apply { add(first); add(next) }
                while (pages < 64) {
                    val (_, nn) = try { readIfd(n) } catch (_: EngineException) { break }
                    if (nn == 0L || !seen.add(nn)) break
                    n = nn; pages++
                }
                throw EngineException(
                    ErrorCode.MULTI_PAGE,
                    "$name: multi-page TIFF (${if (pages >= 64) "64+" else pages.toString()} pages) is not supported. Only single-page TIFF files can be converted."
                )
            }

            fun one(tag: Int, def: Long? = null): Long =
                longs(tags[tag])?.firstOrNull() ?: def ?: throw unreadable(name, "TIFF is missing required tag $tag.")

            if (tags.containsKey(T_TILE_W) || tags.containsKey(T_TILE_L)) throw unsupported(name, "tiled TIFF is not supported (only striped TIFF).")
            val width = one(T_WIDTH); val height = one(T_HEIGHT)
            if (width <= 0 || height <= 0 || width > Int.MAX_VALUE / 16 || height > Int.MAX_VALUE) throw unreadable(name, "TIFF has invalid dimensions.")
            val spp = one(T_SPP, 1).toInt()
            val bps = longs(tags[T_BPS]) ?: longArrayOf(1)
            if (bps.size < spp && bps.size != 1) throw unreadable(name, "TIFF BitsPerSample count does not match SamplesPerPixel.")
            val depth = bps[0].toInt()
            if (bps.any { it.toInt() != depth }) throw unsupported(name, "mixed per-channel bit depths (${bps.joinToString("/")}) cannot be stored in PNG.")
            val compression = one(T_COMPRESSION, 1).toInt()
            val photometric = one(T_PHOTOMETRIC).toInt()
            if (one(T_FILLORDER, 1) != 1L) throw unsupported(name, "reversed bit FillOrder is not supported.")
            if (one(T_PLANAR, 1) != 1L) throw unsupported(name, "planar (separate-plane) TIFF is not supported.")
            val sf = longs(tags[T_SAMPLEFORMAT])
            if (sf != null && sf.any { it != 1L }) throw unsupported(name, "only unsigned-integer samples are supported (found signed/float sample format).")
            val predictor = one(T_PREDICTOR, 1).toInt()
            if (predictor != 1 && predictor != 2) throw unsupported(name, "predictor $predictor (floating-point) is not supported.")
            if (predictor == 2 && depth != 8 && depth != 16) throw unsupported(name, "the horizontal predictor is only supported for 8 and 16-bit samples.")
            if (compression !in intArrayOf(1, 5, 8, 32946, 32773)) {
                val cname = when (compression) { 7, 6 -> "JPEG"; 2, 3, 4 -> "CCITT fax"; 34712 -> "JPEG 2000"; 34925 -> "LZMA"; 50000 -> "ZSTD"; else -> "code $compression" }
                throw unsupported(name, "compression $cname is not supported. Supported: none, LZW, Deflate, PackBits.")
            }
            val orientation = one(T_ORIENTATION, 1).toInt()
            if (orientation !in 1..8) throw unreadable(name, "TIFF has an invalid Orientation value $orientation.")

            val extra = longs(tags[T_EXTRA])
            val baseChannels: Int
            var colorType: Int
            var palette: ByteArray? = null
            when (photometric) {
                0, 1 -> { baseChannels = 1; colorType = 0 }
                2 -> { baseChannels = 3; colorType = 2 }
                3 -> { baseChannels = 1; colorType = 3 }
                5 -> throw unsupported(name, "CMYK TIFF cannot be represented in PNG without a colour conversion.")
                6 -> throw unsupported(name, "YCbCr TIFF cannot be represented in PNG without a colour conversion.")
                8, 9, 10 -> throw unsupported(name, "CIE Lab TIFF cannot be represented in PNG without a colour conversion.")
                4 -> throw unsupported(name, "transparency-mask TIFF is not supported.")
                else -> throw unsupported(name, "unsupported PhotometricInterpretation $photometric.")
            }
            val extraCount = spp - baseChannels
            if (extraCount < 0) throw unreadable(name, "TIFF SamplesPerPixel ($spp) is too small for its colour model.")
            if (extraCount > 1 || (extraCount == 1 && (colorType == 3))) throw unsupported(name, "$extraCount extra channel(s) cannot be stored in PNG.")
            if (extraCount == 1) {
                when (extra?.firstOrNull()) {
                    2L -> colorType += 4
                    1L -> throw unsupported(name, "associated (premultiplied) alpha cannot be stored in PNG without altering pixel values.")
                    else -> throw unsupported(name, "the extra channel is not marked as alpha (ExtraSamples=${extra?.firstOrNull() ?: "missing"}), so it cannot be preserved safely.")
                }
            }
            val depthOk = when (colorType) { 0 -> depth in intArrayOf(1, 2, 4, 8, 16); 3 -> depth in intArrayOf(1, 2, 4, 8); else -> depth == 8 || depth == 16 }
            if (!depthOk) throw unsupported(name, "$depth bits per sample is not supported for this colour model (PNG supports 1/2/4/8/16).")

            if (colorType == 3) {
                val cm = longs(tags[T_COLORMAP]) ?: throw unreadable(name, "palette TIFF has no ColorMap.")
                val n = 1 shl depth
                if (cm.size < 3 * n) throw unreadable(name, "TIFF ColorMap is too short.")
                palette = ByteArray(3 * n)
                for (i in 0 until n) for (c in 0..2) {
                    val v = cm[c * n + i].toInt()
                    if (v % 257 != 0) throw unsupported(name, "palette colours are 16-bit and cannot be stored exactly in a PNG palette (PNG palettes are 8-bit).")
                    palette[i * 3 + c] = (v / 257).toByte()
                }
            }

            val chunks = ArrayList<PngChunk>()
            tags[T_ICC]?.let { e ->
                chunks.add(buildIccp(bytesOf(e), colorType))
            }
            val swap = orientation in 5..8
            val outW = if (swap) height.toInt() else width.toInt()
            val outH = if (swap) width.toInt() else height.toInt()
            val info = RasterInfo(outW, outH, colorType, depth, palette, null, chunks)

            // strips
            val srcInfo = RasterInfo(width.toInt(), height.toInt(), colorType, depth)
            val rps = minOf(one(T_ROWS_PER_STRIP, height), height).coerceAtLeast(1)
            val nStrips = ((height + rps - 1) / rps).toInt()
            val offsets = longs(tags[T_STRIP_OFFSETS]) ?: throw unreadable(name, "TIFF has no strip offsets.")
            var counts = longs(tags[T_STRIP_COUNTS])
            if (offsets.size < nStrips) throw unreadable(name, "TIFF strip table is incomplete.")
            if (counts == null) {
                if (compression != 1) throw unreadable(name, "TIFF has no strip byte counts.")
                counts = LongArray(nStrips) { i -> minOf(rps, height - i * rps) * srcInfo.rowBytes }
            }
            if (counts.size < nStrips) throw unreadable(name, "TIFF strip table is incomplete.")
            for (i in 0 until nStrips) if (offsets[i] + counts[i] > ra.length || counts[i] <= 0) {
                throw unreadable(name, "TIFF strip $i lies outside the file (file is truncated or corrupt).")
            }
            if (orientation != 1 && depth < 8) throw unsupported(name, "Orientation $orientation with $depth-bit samples is not supported (only 8/16-bit images can be re-oriented exactly).")
            if (orientation != 1) {
                val need = srcInfo.rowBytes.toLong() * height + srcInfo.rowBytes
                val budget = orientationMemoryBudget()
                if (need > budget) {
                    throw EngineException(
                        ErrorCode.OUT_OF_MEMORY,
                        "$name: this TIFF has Orientation $orientation (rotated/mirrored). Applying it exactly needs the whole image in memory: " +
                            "about ${mb(need)} MB, but only about ${mb(budget)} MB is available to the app. " +
                            "The image is never downscaled or approximated, so it cannot be converted. " +
                            "Re-save it with the normal (top-left) orientation, or use a device with more memory."
                    )
                }
            }

            val strips = StripRows(
                ra, name, srcInfo, le, compression, predictor, photometric == 0, offsets, counts, rps, nStrips, colorType == 4 || colorType == 6
            )
            return if (orientation == 1) TiffRowSource(info, strips, ra) else OrientedRowSource(info, strips, ra, orientation, srcInfo)
        }

        private fun buildIccp(profile: ByteArray, colorType: Int): PngChunk {
            if (profile.size < 132 || String(profile, 36, 4, Charsets.ISO_8859_1) != "acsp") {
                throw unsupported(name, "the embedded ICC profile is invalid, so it cannot be preserved.")
            }
            val space = String(profile, 16, 4, Charsets.ISO_8859_1)
            val gray = colorType == 0 || colorType == 4
            if ((gray && space != "GRAY") || (!gray && space != "RGB ")) {
                throw unsupported(name, "the embedded ICC profile ($space) does not match the image colour model; PNG cannot store this combination.")
            }
            val d = Deflater(9)
            val bos = ByteArrayOutputStream()
            bos.write("ICC Profile".toByteArray(Charsets.ISO_8859_1)); bos.write(0); bos.write(0)
            d.setInput(profile); d.finish()
            val tmp = ByteArray(8192)
            while (!d.finished()) bos.write(tmp, 0, d.deflate(tmp))
            d.end()
            return PngChunk("iCCP", bos.toByteArray())
        }
    }

    /** Decodes strips on demand; one row of memory plus the codec's own window. */
    private class StripRows(
        val ra: RandomAccess, val name: String, val src: RasterInfo, val le: Boolean, val compression: Int,
        val predictor: Int, val whiteIsZero: Boolean, val offsets: LongArray, val counts: LongArray,
        val rps: Long, val nStrips: Int, val hasAlpha: Boolean
    ) {
        private var strip = -1
        private var rowsLeft = 0L
        private var stream: InputStream? = null
        private var inflater: Inflater? = null
        private var rowIndex = 0

        private fun openStrip() {
            closeStrip()
            strip++
            if (strip >= nStrips) throw IllegalStateException("no more strips")
            rowsLeft = minOf(rps, src.height - strip.toLong() * rps)
            val raw = BoundedStream(ra, offsets[strip], counts[strip])
            stream = when (compression) {
                1 -> raw
                5 -> TiffLzwInputStream(raw)
                32773 -> PackBitsInputStream(raw)
                else -> { val i = Inflater(); inflater = i; InflaterInputStream(raw, i, 1 shl 15) }
            }
        }

        private fun closeStrip() { inflater?.end(); inflater = null; stream = null }

        fun close() = closeStrip()

        fun readRow(dst: ByteArray) {
            if (rowsLeft == 0L) openStrip()
            val s = stream!!
            val n = src.rowBytes
            try {
                var got = 0
                while (got < n) {
                    val r = s.read(dst, got, n - got)
                    if (r < 0) throw unreadable(name, "TIFF strip $strip is truncated (row ${rowIndex}).")
                    got += r
                }
            } catch (e: EngineException) {
                throw e
            } catch (e: IOException) {
                throw unreadable(name, "TIFF pixel data is corrupt (strip $strip, row $rowIndex): ${e.message}", e)
            }
            rowsLeft--; rowIndex++
            postProcess(dst)
        }

        private fun postProcess(row: ByteArray) {
            val ch = src.channels
            val n = src.rowBytes
            if (predictor == 2) {
                if (src.bitDepth == 8) {
                    for (i in ch until n) row[i] = (row[i] + row[i - ch]).toByte()
                } else {
                    val samples = src.width * ch
                    for (i in ch until samples) {
                        val a = i * 2; val b = (i - ch) * 2
                        val v = (get16(row, a) + get16(row, b)) and 0xFFFF
                        put16(row, a, v)
                    }
                }
            }
            if (src.bitDepth == 16 && le) {
                var i = 0
                while (i < n) { val t = row[i]; row[i] = row[i + 1]; row[i + 1] = t; i += 2 }
            }
            if (whiteIsZero) invert(row)
            if (src.bitDepth < 8) {
                val used = src.width * src.bitsPerPixel
                if (used % 8 != 0) row[n - 1] = (row[n - 1].toInt() and (0xFF shl (8 - used % 8))).toByte()
            }
        }

        private fun get16(b: ByteArray, o: Int) =
            if (le) (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8) else ((b[o].toInt() and 255) shl 8) or (b[o + 1].toInt() and 255)

        private fun put16(b: ByteArray, o: Int, v: Int) {
            if (le) { b[o] = v.toByte(); b[o + 1] = (v shr 8).toByte() } else { b[o] = (v shr 8).toByte(); b[o + 1] = v.toByte() }
        }

        /** WhiteIsZero -> PNG's BlackIsZero: exact bijection (max - v), leaving any alpha channel untouched. */
        private fun invert(row: ByteArray) {
            val bytesPerSample = if (src.bitDepth == 16) 2 else 1
            if (src.bitDepth < 8 || !hasAlpha) {
                val n = src.rowBytes
                for (i in 0 until n) row[i] = (row[i].toInt() xor 0xFF).toByte()
            } else {
                val px = 2 * bytesPerSample
                var i = 0
                while (i < src.rowBytes) { for (k in 0 until bytesPerSample) row[i + k] = (row[i + k].toInt() xor 0xFF).toByte(); i += px }
            }
        }
    }

    private class TiffRowSource(override val info: RasterInfo, val strips: StripRows, val ra: RandomAccess) : RowSource {
        override fun readRow(dst: ByteArray) = strips.readRow(dst)
        override fun close() { strips.close(); ra.close() }
    }

    /** Applies Orientation 2..8 exactly. Needs the whole raster in memory (width*height*bytes/pixel). */
    private class OrientedRowSource(
        override val info: RasterInfo, val strips: StripRows, val ra: RandomAccess, val orientation: Int, val src: RasterInfo
    ) : RowSource {
        private var data: ByteArray? = null
        private var y = 0

        private fun load(): ByteArray {
            val total = src.rowBytes.toLong() * src.height
            if (total > 1_500_000_000L) throw EngineException(ErrorCode.OUT_OF_MEMORY, "${"TIFF"} orientation $orientation needs ${total / (1024 * 1024)} MB in memory, which is too much.")
            try {
                val d = ByteArray(total.toInt())
                val row = ByteArray(src.rowBytes)
                for (r in 0 until src.height) { strips.readRow(row); System.arraycopy(row, 0, d, r * src.rowBytes, src.rowBytes) }
                return d
            } catch (e: OutOfMemoryError) {
                throw EngineException(ErrorCode.OUT_OF_MEMORY, "Not enough memory to apply TIFF orientation $orientation to a ${src.width}x${src.height} image.", e)
            }
        }

        override fun readRow(dst: ByteArray) {
            val d = data ?: load().also { data = it }
            val w = src.width; val h = src.height
            val pb = src.bitsPerPixel / 8
            val ow = info.width
            for (x in 0 until ow) {
                val sx: Int; val sy: Int
                when (orientation) {
                    2 -> { sx = w - 1 - x; sy = y }
                    3 -> { sx = w - 1 - x; sy = h - 1 - y }
                    4 -> { sx = x; sy = h - 1 - y }
                    5 -> { sx = y; sy = x }
                    6 -> { sx = y; sy = h - 1 - x }
                    7 -> { sx = w - 1 - y; sy = h - 1 - x }
                    else -> { sx = w - 1 - y; sy = x }
                }
                System.arraycopy(d, sy * src.rowBytes + sx * pb, dst, x * pb, pb)
            }
            y++
        }

        override fun close() { data = null; strips.close(); ra.close() }
    }
}
