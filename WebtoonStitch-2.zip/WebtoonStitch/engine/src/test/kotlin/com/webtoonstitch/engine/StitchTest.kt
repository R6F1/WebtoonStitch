package com.webtoonstitch.engine

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.awt.color.ColorSpace
import java.awt.image.*
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.CancellationException
import javax.imageio.ImageIO

class StitchTest {
    @get:Rule val tmp = TemporaryFolder()

    /** Pattern that identifies image [k], row y, column x, channel c. */
    private fun sample(k: Int, x: Int, y: Int, c: Int, max: Int) = (((k + 1) * 7919 + x * 31 + y * 17 + c * 101) xor (y * y)) and max

    private fun make(kind: String, w: Int, h: Int, k: Int): BufferedImage {
        val (bands, max, type) = when (kind) {
            "rgba8" -> Triple(4, 255, DataBuffer.TYPE_BYTE)
            "gray16" -> Triple(1, 65535, DataBuffer.TYPE_USHORT)
            "rgb16" -> Triple(3, 65535, DataBuffer.TYPE_USHORT)
            "rgba16" -> Triple(4, 65535, DataBuffer.TYPE_USHORT)
            "rgb8" -> Triple(3, 255, DataBuffer.TYPE_BYTE)
            else -> throw IllegalArgumentException(kind)
        }
        val bits = if (type == DataBuffer.TYPE_BYTE) 8 else 16
        val cs = ColorSpace.getInstance(if (bands == 1) ColorSpace.CS_GRAY else ColorSpace.CS_sRGB)
        val alpha = bands == 4
        val cm = ComponentColorModel(cs, IntArray(bands) { bits }, alpha, false,
            if (alpha) java.awt.Transparency.TRANSLUCENT else java.awt.Transparency.OPAQUE, type)
        val ras = Raster.createInterleavedRaster(type, w, h, w * bands, bands, IntArray(bands) { it }, null)
        return BufferedImage(cm, ras, false, null).also { b ->
            for (y in 0 until h) for (x in 0 until w) for (c in 0 until bands) b.raster.setSample(x, y, c, sample(k, x, y, c, max))
        }
    }

    private fun save(name: String, img: BufferedImage): FileImageInput {
        val f = File(tmp.root, name); assertTrue(ImageIO.write(img, "png", f)); return FileImageInput(f)
    }

    private fun stitchBytes(plan: StitchPlan): ByteArray = ByteArrayOutputStream().also { Stitcher.stitch(plan, it) }.toByteArray()

    private fun assertStitched(sources: List<BufferedImage>, out: BufferedImage, label: String) {
        assertEquals("$label width", sources[0].width, out.width)
        assertEquals("$label height", sources.sumOf { it.height }, out.height)
        assertEquals("$label bands", sources[0].raster.numBands, out.raster.numBands)
        assertEquals("$label data type", sources[0].raster.dataBuffer.dataType, out.raster.dataBuffer.dataType)
        var off = 0; var diffs = 0L
        for ((k, s) in sources.withIndex()) {
            for (y in 0 until s.height) for (x in 0 until s.width) for (c in 0 until s.raster.numBands) {
                if (s.raster.getSample(x, y, c) != out.raster.getSample(x, off + y, c)) diffs++
            }
            off += s.height
        }
        assertEquals("$label pixel differences", 0L, diffs)
    }

    @Test fun specExample690x12000InNaturalOrderNotCreationOrder() {
        val hs = listOf(4000, 3500, 4500)
        val imgs = hs.mapIndexed { i, h -> make("rgba8", 690, h, i) }                // content index = true order
        // files are *created* and *passed* in scrambled order and named so that natural sort restores the true order
        val inputs = listOf(save("003.png", imgs[2]), save("001.png", imgs[0]), save("002.png", imgs[1]))
        val plan = Stitcher.plan(inputs)
        assertEquals(listOf("001.png", "002.png", "003.png"), plan.inputs.map { it.name })
        assertEquals("001-003.png", plan.outputName)
        assertEquals(690, plan.width); assertEquals(12_000, plan.totalHeight)
        val bytes = stitchBytes(plan)
        val out = ImageIO.read(ByteArrayInputStream(bytes))
        assertStitched(imgs, out, "spec example")
        // rows 0-3999 = image 1, 4000-7499 = image 2, 7500-11999 = image 3 (spot-check boundaries explicitly)
        assertEquals(imgs[0].raster.getSample(5, 3999, 2), out.raster.getSample(5, 3999, 2))
        assertEquals(imgs[1].raster.getSample(5, 0, 2), out.raster.getSample(5, 4000, 2))
        assertEquals(imgs[1].raster.getSample(5, 3499, 2), out.raster.getSample(5, 7499, 2))
        assertEquals(imgs[2].raster.getSample(5, 0, 2), out.raster.getSample(5, 7500, 2))
        assertEquals(imgs[2].raster.getSample(5, 4499, 2), out.raster.getSample(5, 11999, 2))
        Stitcher.verify(plan, { ByteArrayInputStream(bytes) })
    }

    @Test fun sixteenBitAndAlphaFormatsStayExactlyAsTheyWere() {
        for (kind in listOf("gray16", "rgb16", "rgba16", "rgba8", "rgb8")) {
            val imgs = listOf(make(kind, 97, 61, 0), make(kind, 97, 17, 1), make(kind, 97, 123, 2))
            val inputs = imgs.mapIndexed { i, im -> save("${kind}_${i + 1}.png", im) }
            val plan = Stitcher.plan(inputs)
            val bytes = stitchBytes(plan)
            val (info, _) = TestUtil.decodePng(bytes)
            assertEquals(kind, if (kind.endsWith("16")) 16 else 8, info.bitDepth)
            assertStitched(imgs, ImageIO.read(ByteArrayInputStream(bytes)), kind)
            Stitcher.verify(plan, { ByteArrayInputStream(bytes) })
        }
    }

    @Test fun naturalOrderingFromTheSpec() {
        val names = listOf("020.png", "003.png", "011.png", "001.png", "010.png", "002.png")
        val imgs = HashMap<String, BufferedImage>()
        val inputs = names.map { n -> make("rgb8", 20, 10, n.take(3).toInt()).also { imgs[n] = it }.let { save(n, it) } }
        val plan = Stitcher.plan(inputs)
        assertEquals(listOf("001.png", "002.png", "003.png", "010.png", "011.png", "020.png"), plan.inputs.map { it.name })
        val out = ImageIO.read(ByteArrayInputStream(stitchBytes(plan)))
        assertStitched(plan.inputs.map { imgs[it.name]!! }, out, "natural")
    }

    @Test fun widthMismatchIsRejectedWithBothNamesAndWidths() {
        val inputs = listOf(save("001.png", make("rgb8", 690, 40, 0)), save("002.png", make("rgb8", 720, 35, 1)))
        val e = try { Stitcher.plan(inputs); null } catch (x: EngineException) { x }!!
        assertEquals(ErrorCode.WIDTH_MISMATCH, e.code)
        assertTrue(e.message!!.contains("Image width mismatch. All selected images must have the same width."))
        assertTrue(e.message!!.contains("001.png: 690 px")); assertTrue(e.message!!.contains("002.png: 720 px"))
    }

    @Test fun heightLimitIsCumulativeAndExactlyTwelveThousandIsAllowed() {
        val a = save("1.png", make("gray16", 8, 6000, 0)); val b = save("2.png", make("gray16", 8, 6000, 1)); val c = save("3.png", make("gray16", 8, 1, 2))
        assertEquals(12_000, Stitcher.plan(listOf(a, b)).totalHeight)
        val e = try { Stitcher.plan(listOf(a, b, c)); null } catch (x: EngineException) { x }!!
        assertEquals(ErrorCode.HEIGHT_LIMIT, e.code)
        assertTrue(e.message!!.startsWith("Selection limit exceeded. Maximum combined image height is 12,000 px."))
    }

    @Test fun differentBitDepthOrColourTypeIsRefusedNotConverted() {
        val a = save("1.png", make("rgb8", 10, 10, 0)); val b = save("2.png", make("rgb16", 10, 10, 1)); val c = save("3.png", make("rgba8", 10, 10, 2))
        assertEquals(ErrorCode.FORMAT_MISMATCH, try { Stitcher.plan(listOf(a, b)); null } catch (x: EngineException) { x }!!.code)
        assertEquals(ErrorCode.FORMAT_MISMATCH, try { Stitcher.plan(listOf(a, c)); null } catch (x: EngineException) { x }!!.code)
    }

    @Test fun planningInspectsHeadersOnlyAndNeverDecodesPixels() {
        // a valid 690x12000 PNG whose pixel stream is then destroyed: planning must still succeed (headers only)
        val info = RasterInfo(690, 12_000, 2, 8)
        val bytes = TestUtil.encodePng(info, List(12_000) { ByteArray(info.rowBytes) })
        for (i in 100 until minOf(bytes.size - 20, 400)) bytes[i] = (bytes[i].toInt() xor 0x5A).toByte()
        val f = File(tmp.root, "huge.png").apply { writeBytes(bytes) }
        val plan = Stitcher.plan(listOf(FileImageInput(f)))
        assertEquals(12_000, plan.totalHeight)
        try { Stitcher.stitch(plan, ByteArrayOutputStream()); fail("corrupt pixel data must be reported") } catch (e: EngineException) { assertEquals(ErrorCode.UNREADABLE, e.code) }
    }

    @Test fun cancellationStopsPromptlyAndPropagates() {
        val plan = Stitcher.plan(listOf(save("1.png", make("rgb8", 50, 500, 0))))
        var rows = 0
        try {
            Stitcher.stitch(plan, ByteArrayOutputStream(), cancel = { if (++rows == 100) throw CancellationException("user") })
            fail()
        } catch (e: CancellationException) { assertEquals(100, rows) }
    }

    @Test fun verifyDetectsOneChangedSampleAndMissingRows() {
        val plan = Stitcher.plan(listOf(save("1.png", make("rgb16", 30, 20, 0)), save("2.png", make("rgb16", 30, 20, 1))))
        val good = stitchBytes(plan)
        Stitcher.verify(plan, { ByteArrayInputStream(good) })
        val (info, rows) = TestUtil.decodePng(good)
        val bad = rows.map { it.copyOf() }; bad[25][7] = (bad[25][7] + 1).toByte()
        val e = try { Stitcher.verify(plan, { ByteArrayInputStream(TestUtil.encodePng(info, bad)) }); null } catch (x: EngineException) { x }!!
        assertEquals(ErrorCode.VERIFICATION_FAILED, e.code); assertTrue(e.message!!, e.message!!.contains("2.png at its row 5"))
        // duplicated row (one dropped, one repeated)
        val dup = rows.toMutableList().also { it[21] = it[20] }
        assertEquals(ErrorCode.VERIFICATION_FAILED, try { Stitcher.verify(plan, { ByteArrayInputStream(TestUtil.encodePng(info, dup)) }); null } catch (x: EngineException) { x }!!.code)
        // missing row
        val short = RasterInfo(30, 39, info.colorType, info.bitDepth)
        assertEquals(ErrorCode.VERIFICATION_FAILED, try { Stitcher.verify(plan, { ByteArrayInputStream(TestUtil.encodePng(short, rows.dropLast(1))) }); null } catch (x: EngineException) { x }!!.code)
    }

    @Test fun pngAndTiffInputsCanBeMixedWhenFormatsMatchExactly() {
        val rowsT = TestUtil.randomRows(RasterInfo(24, 15, 2, 16), 5)
        val tiff = TiffTestUtil.input("002.tif", TiffTestUtil.write(TiffSpec(24, 15, 3, 16, 2, compression = 8, predictor = 2, le = true), rowsT), tmp.root)
        val rowsP = TestUtil.randomRows(RasterInfo(24, 9, 2, 16), 6)
        val pf = File(tmp.root, "001.png").apply { writeBytes(TestUtil.encodePng(RasterInfo(24, 9, 2, 16), rowsP)) }
        val plan = Stitcher.plan(listOf(tiff, FileImageInput(pf)))
        assertEquals("001-002.png", plan.outputName)
        val (_, got) = TestUtil.decodePng(stitchBytes(plan))
        TestUtil.assertRowsEqual(rowsP + rowsT, got, "mixed")
    }

    @Test fun iccProfileSurvivesStitchingAndDifferingProfilesAreRefused() {
        fun png(name: String, icc: Byte, seed: Long): FileImageInput {
            val i = RasterInfo(12, 8, 2, 8, colorChunks = listOf(PngChunk("iCCP", byteArrayOf(65, 0, 0, icc, icc))))
            return FileImageInput(File(tmp.root, name).apply { writeBytes(TestUtil.encodePng(i, TestUtil.randomRows(i, seed))) })
        }
        val plan = Stitcher.plan(listOf(png("1.png", 9, 1), png("2.png", 9, 2)))
        val (info, _) = TestUtil.decodePng(stitchBytes(plan))
        assertEquals(listOf(PngChunk("iCCP", byteArrayOf(65, 0, 0, 9, 9))), info.colorChunks)
        assertEquals(ErrorCode.FORMAT_MISMATCH, try { Stitcher.plan(listOf(png("3.png", 9, 1), png("4.png", 8, 2))); null } catch (x: EngineException) { x }!!.code)
    }

    @Test fun outputNameCollisionsNeverOverwrite() {
        val existing = setOf("001-003.png", "001-003 (1).png")
        assertEquals("001-003 (2).png", OutputNaming.uniqueName("001-003.png") { it in existing })
    }

    @Test fun nothingSelectedAndUnreadableInputs() {
        assertEquals(ErrorCode.NO_INPUT, try { Stitcher.plan(emptyList()); null } catch (x: EngineException) { x }!!.code)
        val junk = FileImageInput(File(tmp.root, "x.png").apply { writeBytes(ByteArray(50)) })
        assertEquals(ErrorCode.UNSUPPORTED, try { Stitcher.plan(listOf(junk)); null } catch (x: EngineException) { x }!!.code)
        // A format that is not supported (here: a WebP header) is still rejected as unsupported.
        val webp = FileImageInput(File(tmp.root, "y.png").apply { writeBytes("RIFF\u0000\u0000\u0000\u0000WEBPVP8 ".toByteArray(Charsets.ISO_8859_1)) })
        val e = try { Stitcher.plan(listOf(webp)); null } catch (x: EngineException) { x }!!
        assertEquals(ErrorCode.UNSUPPORTED, e.code); assertTrue(e.message!!.contains("PNG, TIFF and JPEG"))
        // JPEG is supported now (JpegTest); a JPEG whose header is cut off is reported as unreadable, never half-decoded.
        val cut = FileImageInput(File(tmp.root, "z.png").apply { writeBytes(byteArrayOf(-1, -40, -1, -32, 0, 16, 74, 70)) })
        assertEquals(ErrorCode.UNREADABLE, try { Stitcher.plan(listOf(cut)); null } catch (x: EngineException) { x }!!.code)
    }

    @Test fun pickerLevelKeyDetectsColourProfileDifferencesBeforeTheJobStarts() {
        val plain = RasterInfo(10, 10, 2, 8)
        val srgb = RasterInfo(10, 10, 2, 8, colorChunks = listOf(PngChunk("sRGB", byteArrayOf(0))))
        val other = RasterInfo(10, 10, 2, 8, colorChunks = listOf(PngChunk("gAMA", byteArrayOf(0, 1, -122, -96))))
        assertEquals("2/8", plain.formatKey)
        assertNotEquals(plain.formatKey, srgb.formatKey); assertNotEquals(srgb.formatKey, other.formatKey)
        assertEquals(srgb.formatKey, RasterInfo(99, 5, 2, 8, colorChunks = listOf(PngChunk("sRGB", byteArrayOf(0)))).formatKey)
        val sel = StitchSelection()
        assertEquals(AddResult.Accepted, sel.tryAdd(Candidate("a", "a.png", 10, 10, plain.formatKey)))
        val r = sel.tryAdd(Candidate("b", "b.png", 10, 10, srgb.formatKey)) as AddResult.Rejected
        assertEquals(RejectReason.FORMAT_MISMATCH, r.reason); assertTrue(r.message.contains("colour profile"))
    }
}
