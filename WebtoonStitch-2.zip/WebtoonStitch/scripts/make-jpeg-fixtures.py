#!/usr/bin/env python3
"""Generates the JPEG test fixtures in engine/src/test/resources/jpeg and the golden checksums.

The files are produced by Pillow's libjpeg(-turbo) ENCODER and the checksums by Pillow's libjpeg(-turbo) DECODER, i.e. by
software that is independent of the engine's decoder. The engine tests additionally compare against the JDK's ImageIO.
Run:  python3 scripts/make-jpeg-fixtures.py   (needs Pillow + numpy; only needed to REGENERATE, the outputs are committed)
"""
import hashlib, io, os, struct, zlib
import numpy as np
from PIL import Image, ImageCms

OUT = os.path.join(os.path.dirname(__file__), "..", "engine", "src", "test", "resources")
J = os.path.join(OUT, "jpeg")
os.makedirs(J, exist_ok=True)

def pattern(w, h, seed, mode="RGB"):
    rs = np.random.RandomState(seed)
    y, x = np.mgrid[0:h, 0:w]
    base = np.stack([(x * 255 // max(w - 1, 1)), (y * 255 // max(h - 1, 1)), ((x + y) * 255 // max(w + h - 2, 1))], -1).astype(float)
    edges = ((x // 5 + y // 7) % 2)[..., None] * 90.0           # hard edges stress chroma upsampling + high-frequency DCT terms
    noise = rs.randint(-25, 26, (h, w, 3))
    a = np.clip(base * 0.6 + edges + noise, 0, 255).astype(np.uint8)
    im = Image.fromarray(a, "RGB")
    return im.convert("L") if mode == "L" else im

gold = []
def emit(name, im, **kw):
    b = io.BytesIO(); im.save(b, "JPEG", **kw); data = b.getvalue()
    open(os.path.join(J, name), "wb").write(data)
    d = Image.open(io.BytesIO(data)); d.load()
    gold.append((name, d.mode, d.width, d.height, hashlib.sha256(d.tobytes()).hexdigest()))
    return data

for (w, h) in [(1, 1), (2, 2), (3, 5), (15, 17), (16, 16), (17, 33), (64, 48), (101, 67)]:
    im = pattern(w, h, w * 1000 + h)
    emit(f"s420_{w}x{h}.jpg", im, quality=90, subsampling=2)
    emit(f"s422_{w}x{h}.jpg", im, quality=90, subsampling=1)
    emit(f"s444_{w}x{h}.jpg", im, quality=90, subsampling=0)
    emit(f"gray_{w}x{h}.jpg", im.convert("L"), quality=90)
im = pattern(130, 90, 7)
emit("q100_420.jpg", im, quality=100, subsampling=2)
emit("q5_420.jpg", im, quality=5, subsampling=2)
emit("optimized_420.jpg", im, quality=85, subsampling=2, optimize=True)
emit("restart_420.jpg", im, quality=85, subsampling=2, restart_marker_blocks=3)
emit("restart_444.jpg", im, quality=85, subsampling=0, restart_marker_rows=1)

# --- files that must be REJECTED (not decoded) -------------------------------------------------------------------
open(os.path.join(J, "reject_progressive.jpg"), "wb").write(
    (lambda b: (im.save(b, "JPEG", quality=85, progressive=True), b.getvalue())[1])(io.BytesIO()))
open(os.path.join(J, "reject_cmyk.jpg"), "wb").write(
    (lambda b: (im.convert("CMYK").save(b, "JPEG", quality=85), b.getvalue())[1])(io.BytesIO()))
exif = Image.Exif(); exif[0x0112] = 6
open(os.path.join(J, "reject_exif_orientation6.jpg"), "wb").write(
    (lambda b: (im.save(b, "JPEG", quality=85, exif=exif), b.getvalue())[1])(io.BytesIO()))
# a file whose EXIF says "normal" must still be accepted:
exif1 = Image.Exif(); exif1[0x0112] = 1
emit("exif_orientation1_420.jpg", im, quality=85, subsampling=2, exif=exif1)

# --- embedded ICC profile (Pillow's built-in sRGB profile) -----------------------------------------------------
prof = ImageCms.ImageCmsProfile(ImageCms.createProfile("sRGB")).tobytes()
open(os.path.join(J, "profile.icc"), "wb").write(prof)
emit("icc_srgb_420.jpg", im, quality=85, subsampling=2, icc_profile=prof)

with open(os.path.join(J, "golden.txt"), "w") as f:
    f.write("# name  PIL-mode  width  height  sha256(raw samples decoded by Pillow/libjpeg-turbo)\n")
    for g in gold: f.write(" ".join(map(str, g)) + "\n")
print(len(gold), "fixtures written to", J)

# --- golden checksums of the two user-provided sample files (engine/src/test/resources/samples) -------------------
S = os.path.join(OUT, "samples")
if os.path.exists(os.path.join(S, "doesnt_load.png")):
    with open(os.path.join(S, "golden.txt"), "w") as f:
        f.write("# name  PIL-mode  width  height  sha256(raw samples decoded by Pillow)\n")
        for n in ("itloads.png", "doesnt_load.png"):
            d = Image.open(os.path.join(S, n)); d.load(); d = d.convert("RGB")
            f.write(f"{n} RGB {d.width} {d.height} {hashlib.sha256(d.tobytes()).hexdigest()}\n")
    print(open(os.path.join(S, "golden.txt")).read())
