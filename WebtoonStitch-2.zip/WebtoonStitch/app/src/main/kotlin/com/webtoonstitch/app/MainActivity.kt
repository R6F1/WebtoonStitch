package com.webtoonstitch.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.webtoonstitch.app.ui.AppTheme
import com.webtoonstitch.app.ui.HomeScreen
import com.webtoonstitch.app.ui.StitchScreen
import com.webtoonstitch.app.ui.TiffScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Remove spool files that a killed process may have left behind (only used for providers without seekable descriptors).
        cacheDir.listFiles { f -> f.name.startsWith("tiff") && f.name.endsWith(".tmp") }?.forEach { it.delete() }
        setContent {
            AppTheme {
                Surface(Modifier.fillMaxSize()) {
                    App(Modifier.safeDrawingPadding())
                }
            }
        }
    }
}

@Composable
private fun App(modifier: Modifier) {
    var screen by rememberSaveable { mutableStateOf("home") }
    when (screen) {
        "stitch" -> StitchScreen(modifier = modifier, onBack = { screen = "home" })
        "tiff" -> TiffScreen(modifier = modifier, onBack = { screen = "home" })
        else -> HomeScreen(modifier = modifier, onStitch = { screen = "stitch" }, onTiff = { screen = "tiff" })
    }
}
