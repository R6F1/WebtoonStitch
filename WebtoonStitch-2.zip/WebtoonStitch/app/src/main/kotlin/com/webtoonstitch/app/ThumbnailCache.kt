package com.webtoonstitch.app

import android.graphics.Bitmap
import android.util.LruCache
import com.webtoonstitch.engine.ImageDecoders
import com.webtoonstitch.engine.ImageInput
import com.webtoonstitch.engine.Thumbnails
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/**
 * Display-only previews. They are rendered by the engine's streaming sampler (never by decoding a full Bitmap)
 * and are never used to produce an output file.
 */
object ThumbnailCache {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    private val gate = Semaphore(2)   // at most two previews decode at once -> bounded CPU and memory

    suspend fun get(key: String, input: ImageInput): Bitmap? {
        cache.get(key)?.let { return it }
        return withContext(Dispatchers.IO) {
            gate.withPermit {
                cache.get(key) ?: try {
                    val t = ImageDecoders.open(input).use { Thumbnails.render(it, 256) }
                    Bitmap.createBitmap(t.argb, t.width, t.height, Bitmap.Config.ARGB_8888).also { cache.put(key, it) }
                } catch (e: Exception) {
                    null   // a preview failure never blocks selection; the real error is reported when the file is inspected
                }
            }
        }
    }
}
