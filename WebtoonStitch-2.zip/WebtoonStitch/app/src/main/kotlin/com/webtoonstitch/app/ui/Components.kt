package com.webtoonstitch.app.ui

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.webtoonstitch.app.ThumbnailCache
import com.webtoonstitch.engine.ImageInput

/** What the grid needs to draw one cell, independent of which tool is showing it. */
data class CellModel(
    val key: String,
    val name: String,
    val isDir: Boolean,
    val selected: Boolean,
    val subtitle: String?,
    val status: String?,
    val statusIsError: Boolean,
    val input: ImageInput?
)

@Composable
fun KeepScreenOn(on: Boolean) {
    val view = LocalView.current
    DisposableEffect(on) {
        view.keepScreenOn = on
        onDispose { view.keepScreenOn = false }
    }
}

@Composable
fun BackBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text("‹ Back") }
        Text(title, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun Thumb(cellKey: String, input: ImageInput?, modifier: Modifier = Modifier) {
    val bitmap: State<Bitmap?> = produceState<Bitmap?>(null, cellKey) {
        value = if (input != null) ThumbnailCache.get(cellKey, input) else null
    }
    val bmp = bitmap.value
    if (bmp != null) {
        Image(bitmap = bmp.asImageBitmap(), contentDescription = null, modifier = modifier, contentScale = ContentScale.Fit)
    }
}

@Composable
fun PickerGrid(cells: List<CellModel>, onClick: (CellModel) -> Unit, modifier: Modifier = Modifier) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(140.dp),
        modifier = modifier,
        contentPadding = androidx.compose.foundation.layout.PaddingValues(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(cells, key = { it.key }) { cell -> PickerCell(cell, onClick = { onClick(cell) }) }
    }
}

@Composable
private fun PickerCell(cell: CellModel, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        border = if (cell.selected) BorderStroke(3.dp, MaterialTheme.colorScheme.primary) else null
    ) {
        Box(
            Modifier.fillMaxWidth().height(150.dp).background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            if (cell.isDir) {
                Text("FOLDER", style = MaterialTheme.typography.labelLarge)
            } else {
                Thumb(cell.key, cell.input, Modifier.fillMaxSize())
                Checkbox(checked = cell.selected, onCheckedChange = null, modifier = Modifier.align(Alignment.TopEnd))
            }
        }
        Column(Modifier.padding(8.dp)) {
            Text(cell.name, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
            cell.subtitle?.let { Text(it, style = MaterialTheme.typography.labelSmall) }
            cell.status?.let {
                Text(
                    it, style = MaterialTheme.typography.labelSmall, maxLines = 4, overflow = TextOverflow.Ellipsis,
                    color = if (cell.statusIsError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
fun MessageDialog(message: String?, isError: Boolean, onDismiss: () -> Unit) {
    if (message == null) return
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isError) "Can't continue" else "Done") },
        text = { Text(message) },
        confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } }
    )
}
